import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  doc,
  setDoc,
  updateDoc,
  getDoc,
  serverTimestamp,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { UserProfile } from '../types';

// Initialize Firebase App safely
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore with custom database ID if provided
export const db =
  firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== '(default)'
    ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
    : getFirestore(app);

/**
 * Normalizes provider strings to support any case variations (e.g. 'Google', 'google', 'GOOGLE', 'Phone', 'phone', etc.)
 */
export function normalizeProvider(provider?: string): {
  id: 'google' | 'facebook' | 'phone' | 'email' | 'guest';
  displayName: string;
  original: string;
} {
  if (!provider) {
    return { id: 'google', displayName: 'Google', original: 'Google' };
  }

  const raw = provider.toString().trim();
  const lower = raw.toLowerCase();

  if (lower.includes('google')) {
    return { id: 'google', displayName: 'Google', original: raw };
  }
  if (lower.includes('facebook') || lower.includes('fb')) {
    return { id: 'facebook', displayName: 'Facebook', original: raw };
  }
  if (lower.includes('phone') || lower.includes('mobile') || lower.includes('هاتف')) {
    return { id: 'phone', displayName: 'رقم الهاتف', original: raw };
  }
  if (lower.includes('email') || lower.includes('mail') || lower.includes('بريد')) {
    return { id: 'email', displayName: 'البريد الإلكتروني', original: raw };
  }

  return { id: 'guest', displayName: 'زائر', original: raw };
}

/**
 * Saves or updates a user profile in Firebase Firestore.
 * Performs strict validation on user.id before attempting to save.
 */
export async function saveUserToFirebase(user: Partial<UserProfile> & { id?: string }) {
  // CRITICAL CHECK: Verify that user and user.id exist before saving to Firebase
  if (!user || !user.id || typeof user.id !== 'string' || user.id.trim() === '') {
    console.warn('⚠️ [Firebase] Cannot save user: user or user.id is missing or invalid:', user);
    return false;
  }

  const normalizedProv = normalizeProvider(user.provider);

  const userData = {
    id: user.id,
    name: user.name || 'مستخدم جديد',
    avatar: user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    coins: typeof user.coins === 'number' ? user.coins : 500,
    diamonds: typeof user.diamonds === 'number' ? user.diamonds : 100,
    provider: normalizedProv.id, // case-normalized e.g., 'google', 'facebook', 'phone', 'email', 'guest'
    providerOriginal: normalizedProv.original, // preserves exact case input
    providerDisplayName: normalizedProv.displayName,
    isOnline: true,
    isLoggedIn: true,
    hasActiveRoom: Boolean(user.hasActiveRoom),
    roomName: user.roomName || '',
    createdRoomId: user.createdRoomId || '',
    levelStatus: user.levelStatus || 'ليفل 1',
    role: user.role || 'عضو VIP',
    gender: user.gender || 'أنثى',
    country: user.country || 'السعودية 🇸🇦',
    bio: user.bio || 'أهلاً بك في ملفي الشخصي في تطبيق SALEEM!',
    lastSeen: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  try {
    const userRef = doc(db, 'users', user.id);
    await setDoc(userRef, userData, { merge: true });
    console.log(`✅ [Firebase] User ${user.id} saved successfully to Firestore!`);
    return true;
  } catch (error) {
    console.error('❌ [Firebase] Error saving user to Firestore:', error);
    return false;
  }
}

/**
 * Updates user online status in Firebase upon logging out or closing session.
 * CRITICAL CHECK: Always verifies user.id existence before executing logout update.
 */
export async function updateUserLogoutStatusInFirebase(user?: Partial<UserProfile> & { id?: string }) {
  // CRITICAL CHECK: Check existence of user and user.id before updating status on logout
  if (!user || !user.id || typeof user.id !== 'string' || user.id.trim() === '') {
    console.warn('⚠️ [Firebase] Cannot update logout status: user or user.id is missing.');
    return false;
  }

  try {
    const userRef = doc(db, 'users', user.id);
    await updateDoc(userRef, {
      isOnline: false,
      isLoggedIn: false,
      lastSeen: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    console.log(`👋 [Firebase] User ${user.id} status updated to offline on logout.`);
    return true;
  } catch (error) {
    console.error('❌ [Firebase] Error updating logout status in Firestore:', error);
    return false;
  }
}

/**
 * Fetches user profile from Firebase Firestore if available.
 */
export async function getUserFromFirebase(userId: string): Promise<Partial<UserProfile> | null> {
  if (!userId) return null;
  try {
    const userRef = doc(db, 'users', userId);
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      return snap.data() as Partial<UserProfile>;
    }
  } catch (error) {
    console.error('❌ [Firebase] Error fetching user from Firestore:', error);
  }
  return null;
}
