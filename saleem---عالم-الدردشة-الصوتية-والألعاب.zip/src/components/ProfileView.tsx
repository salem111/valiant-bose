import React, { useState } from 'react';
import { UserProfile } from '../types';
import { updateUserLogoutStatusInFirebase } from '../lib/firebase';
import {
  Crown,
  Wallet,
  Shield,
  DollarSign,
  Settings,
  Camera,
  BadgeCheck,
  Plus,
  User,
  ShieldCheck,
  Award,
  Gift,
  HelpCircle,
  Info,
  LogOut,
  ChevronLeft,
  X,
  Copy,
  Check,
  Smartphone,
  Key,
  Globe,
  Sparkles,
  Flame,
  Car,
  Image as ImageIcon,
  Clock,
  ArrowRight
} from 'lucide-react';

interface ProfileViewProps {
  user: UserProfile;
  onOpenCoinStore: () => void;
  onOpenVipModal: () => void;
  onOpenAdminPanel: () => void;
  onOpenWithdrawalModal: () => void;
  onUpdateUser?: (updatedProps: Partial<UserProfile>) => void;
  onBack?: () => void;
  onLogout?: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  onOpenCoinStore,
  onOpenVipModal,
  onOpenAdminPanel,
  onOpenWithdrawalModal,
  onUpdateUser,
  onBack,
  onLogout
}) => {
  // Active sub-modals state
  const [activeModal, setActiveModal] = useState<
    | 'settings'
    | 'personal_info'
    | 'security'
    | 'wallet_inventory'
    | 'level_achievements'
    | 'gifts_history'
    | 'support'
    | 'about'
    | 'logout_confirm'
    | null
  >(null);

  // Settings form state
  const [editName, setEditName] = useState(user.name);
  const [editBio, setEditBio] = useState(user.bio || 'صوتي عالمي.. هدفي إسعادكم 💜');
  const [editAge, setEditAge] = useState('24');
  const [copiedId, setCopiedId] = useState(false);

  // Toast notification inside profile
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleCopyId = () => {
    navigator.clipboard?.writeText(user.id);
    setCopiedId(true);
    showToast(`تم نسخ المعرف الرقمي ID: ${user.id}`);
    setTimeout(() => setCopiedId(false), 2000);
  };

  // Avatar upload mock handler
  const handleAvatarUpload = () => {
    const avatars = [
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80'
    ];
    const newAvatar = avatars[Math.floor(Math.random() * avatars.length)];
    if (onUpdateUser) {
      onUpdateUser({ avatar: newAvatar });
    }
    showToast('تم تحديث الصورة الشخصية للأفاتار بنجاح! 📸');
  };

  // Inventory equips state
  const [equippedFrame, setEquippedFrame] = useState<string>('golden_imperial');
  const [equippedRide, setEquippedRide] = useState<string>('lambo');
  const [equippedBadges, setEquippedBadges] = useState<string[]>(['star_badge', 'svip_badge']);
  const [activeInventoryTab, setActiveInventoryTab] = useState<'frames' | 'rides' | 'badges' | 'wallpapers'>('frames');

  // Support ticket form
  const [supportMessage, setSupportMessage] = useState('');

  return (
    <div id="saleem-profile-page" className="space-y-4 text-right dir-rtl pb-6 max-w-2xl mx-auto">
      
      {/* 1. TOP HEADER CONTROL BAR (شريط التحكم العلوي) */}
      <div className="bg-slate-900/90 border border-purple-900/50 rounded-2xl p-3 flex items-center justify-between backdrop-blur-md shadow-lg sticky top-0 z-20">
        {/* Back Button (<) on the Right (RTL) */}
        <button
          onClick={onBack}
          className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 transition-all active:scale-95 cursor-pointer flex items-center gap-1"
          title="الرجوع إلى القائمة الرئيسية"
        >
          <ArrowRight className="w-5 h-5" />
        </button>

        {/* Centered Page Title */}
        <div className="text-center">
          <h1 className="font-black text-base sm:text-lg text-white">حسابي</h1>
          <span className="text-[10px] text-amber-400 font-mono">الإدارة الشاملة للحساب</span>
        </div>

        {/* Gear Settings Button (⚙️) on the Left */}
        <button
          onClick={() => setActiveModal('settings')}
          className="p-2.5 rounded-xl bg-purple-900/60 hover:bg-purple-800 border border-purple-500/40 text-purple-200 transition-all active:scale-95 cursor-pointer"
          title="إعدادات الحساب المتقدمة"
        >
          <Settings className="w-5 h-5 text-amber-300 animate-spin-slow" />
        </button>
      </div>

      {/* 2. PERSONAL IDENTITY CARD (بطاقة الهوية الشخصية) */}
      <div className="relative bg-gradient-to-br from-purple-950 via-slate-900 to-slate-950 border-2 border-purple-500/40 rounded-3xl p-5 shadow-2xl space-y-4 overflow-hidden">
        {/* Background Glowing Watermark */}
        <div className="absolute -left-10 -top-10 w-40 h-40 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-right">
          {/* Avatar Container with Glowing Ring & Camera Overlay */}
          <div className="relative shrink-0">
            <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full p-1 bg-gradient-to-tr from-amber-400 via-purple-500 to-indigo-500 shadow-[0_0_20px_rgba(168,85,247,0.4)]">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-full h-full rounded-full object-cover border-2 border-slate-950"
              />
            </div>

            {/* Camera Icon Floating Button */}
            <button
              onClick={handleAvatarUpload}
              className="absolute bottom-0 left-0 bg-purple-600 hover:bg-purple-500 border-2 border-slate-950 text-white p-2 rounded-full shadow-lg transition-transform active:scale-90 cursor-pointer"
              title="تغيير الصورة الشخصية"
            >
              <Camera className="w-4 h-4" />
            </button>
          </div>

          {/* User Meta Information */}
          <div className="flex-1 space-y-1.5">
            {/* Display Name & Verified Badge */}
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <h2 className="font-black text-xl text-white tracking-wide">{user.name}</h2>
              <span className="p-0.5 rounded-full bg-purple-500/20 text-purple-400 border border-purple-400/40" title="حساب موثق رسمياً">
                <BadgeCheck className="w-5 h-5 text-purple-400 fill-purple-400/30" />
              </span>
              <button
                onClick={onOpenVipModal}
                className="bg-amber-400/20 hover:bg-amber-400/30 text-amber-300 text-xs px-2.5 py-0.5 rounded-full font-bold border border-amber-400/40 flex items-center gap-1 cursor-pointer transition-transform active:scale-95"
              >
                <Crown className="w-3.5 h-3.5 text-amber-300" />
                <span>{user.vipRank}</span>
              </button>
            </div>

            {/* Digital ID & Hexagonal Level Badge Row */}
            <div className="flex items-center justify-center sm:justify-start gap-2.5 text-xs">
              {/* ID Badge with Copy Button */}
              <div
                onClick={handleCopyId}
                className="flex items-center gap-1.5 bg-slate-950/80 border border-slate-700/80 hover:border-amber-400 px-3 py-1 rounded-full text-slate-300 font-mono text-[11px] cursor-pointer transition-colors"
                title="انقر لنسخ المعرف الرقمي"
              >
                <span className="text-amber-400 font-bold">ID:</span>
                <span>{user.id}</span>
                {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              </div>

              {/* Hexagonal Level Badge */}
              <div className="flex items-center gap-1.5 bg-purple-900/80 border border-purple-500/60 px-3 py-1 rounded-full text-purple-200 font-black text-[11px] shadow">
                <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
                <span>المستوى 42</span>
              </div>
            </div>

            {/* Personal Status / Bio */}
            <p className="text-xs text-purple-200/90 italic pt-0.5 font-medium">
              "{user.bio || 'صوتي عالمي.. هدفي إسعادكم 💜'}"
            </p>
          </div>
        </div>

        {/* Follow Stats Summary Row */}
        <div className="grid grid-cols-2 gap-2 pt-3 border-t border-purple-900/40 text-center text-xs">
          <div className="bg-slate-950/60 p-2 rounded-2xl border border-slate-800">
            <span className="text-slate-400 text-[10px] block">المتابعين</span>
            <span className="font-black text-amber-300 font-mono text-sm">{user.followersCount.toLocaleString()}</span>
          </div>
          <div className="bg-slate-950/60 p-2 rounded-2xl border border-slate-800">
            <span className="text-slate-400 text-[10px] block">يتابع</span>
            <span className="font-black text-amber-300 font-mono text-sm">{user.followingCount.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* 3. QUICK BALANCE WALLET CARD (محفظة الرصيد السريع) */}
      <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-purple-950/80 border-2 border-amber-500/50 p-4 rounded-3xl shadow-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center text-amber-300 font-black text-2xl shadow">
            🪙
          </div>
          <div>
            <span className="text-[11px] text-amber-200 font-bold block">عداد العملات الصفراء</span>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-2xl text-amber-300 font-mono">{user.coins.toLocaleString()}</span>
              <span className="text-xs text-amber-400 font-bold">عملة صفراء</span>
            </div>
          </div>
        </div>

        {/* Recharge Button (+) */}
        <button
          onClick={onOpenCoinStore}
          className="flex items-center gap-1.5 px-4 py-2.5 bg-gradient-to-r from-purple-600 to-amber-500 hover:from-purple-500 hover:to-amber-400 text-white font-black text-xs rounded-2xl shadow-lg transition-transform active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>شحن الرصيد</span>
        </button>
      </div>

      {/* PROMINENT CASH WITHDRAWAL & DIAMONDS CARD */}
      <div
        onClick={onOpenWithdrawalModal}
        className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 p-4 rounded-3xl border-2 border-emerald-500/60 shadow-xl flex items-center justify-between cursor-pointer hover:border-emerald-400 transition-all active:scale-98"
      >
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black shadow-lg">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-black text-xs sm:text-sm text-emerald-300">سحب الأرباح وتحويل الألماس لكاش 💎💵</h3>
            <p className="text-[10px] sm:text-[11px] text-slate-300">
              رصيد الألماس: <span className="font-bold text-cyan-300">{user.diamonds.toLocaleString()} ألماسة</span> (تساوي حوالي <span className="font-bold text-emerald-400">${(user.diamonds / 5000).toFixed(2)} USD</span>)
            </p>
          </div>
        </div>

        <button className="px-3 py-1.5 bg-emerald-500 text-slate-950 font-black text-xs rounded-xl shadow-md hover:bg-emerald-400 cursor-pointer whitespace-nowrap">
          سحب / استبدال
        </button>
      </div>

      {/* 4. MAIN OPTIONS LIST (قائمة الخيارات والإدارة الرئيسية) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-2 space-y-1.5 shadow-xl">
        <h3 className="px-3 pt-2 text-xs font-black text-purple-300">خيارات إدارة الحساب والأدوات</h3>

        {/* 1. معلومات الشخصية */}
        <button
          onClick={() => setActiveModal('personal_info')}
          className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 hover:bg-slate-800/80 border border-slate-800/80 transition-all cursor-pointer group"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-500/20 border border-blue-400/40 flex items-center justify-center text-blue-300">
              <User className="w-5 h-5" />
            </div>
            <div className="text-right">
              <span className="font-bold text-xs text-white block group-hover:text-amber-300 transition-colors">معلومات الشخصية</span>
              <span className="text-[10px] text-slate-400">البريد، رقم الهاتف، والبلد</span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-slate-500 group-hover:text-amber-400 transition-colors" />
        </button>

        {/* 2. الأمان والخصوصية */}
        <button
          onClick={() => setActiveModal('security')}
          className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 hover:bg-slate-800/80 border border-slate-800/80 transition-all cursor-pointer group"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="text-right">
              <span className="font-bold text-xs text-white block group-hover:text-amber-300 transition-colors">الأمان والخصوصية</span>
              <span className="text-[10px] text-slate-400">التحقق بخطوتين والأجهزة المتصلة</span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-slate-500 group-hover:text-amber-400 transition-colors" />
        </button>

        {/* 3. محفظتي الشاملة (رصيد + مقتنيات وأدوات) */}
        <button
          onClick={() => setActiveModal('wallet_inventory')}
          className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/60 to-slate-950/80 hover:bg-slate-800/80 border border-purple-500/40 transition-all cursor-pointer group shadow"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-400/40 flex items-center justify-center text-purple-300">
              <Wallet className="w-5 h-5" />
            </div>
            <div className="text-right">
              <span className="font-bold text-xs text-purple-200 block group-hover:text-amber-300 transition-colors">محفظتي ومستودع المقتنيات 🧰</span>
              <span className="text-[10px] text-slate-400">الرصيد، الإطارات، المركبات، والشارات</span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-purple-400 group-hover:text-amber-400 transition-colors" />
        </button>

        {/* 4. المستوى والإنجازات */}
        <button
          onClick={() => setActiveModal('level_achievements')}
          className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 hover:bg-slate-800/80 border border-slate-800/80 transition-all cursor-pointer group"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
              <Award className="w-5 h-5" />
            </div>
            <div className="text-right">
              <span className="font-bold text-xs text-white block group-hover:text-amber-300 transition-colors">المستوى والإنجازات</span>
              <span className="text-[10px] text-slate-400">نقاط الخبرة XP والمهام اليومية والكؤوس</span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-slate-500 group-hover:text-amber-400 transition-colors" />
        </button>

        {/* 5. الهدايا */}
        <button
          onClick={() => setActiveModal('gifts_history')}
          className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 hover:bg-slate-800/80 border border-slate-800/80 transition-all cursor-pointer group"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-pink-500/20 border border-pink-400/40 flex items-center justify-center text-pink-300">
              <Gift className="w-5 h-5" />
            </div>
            <div className="text-right">
              <span className="font-bold text-xs text-white block group-hover:text-amber-300 transition-colors">الهدايا والدعم</span>
              <span className="text-[10px] text-slate-400">سجل الهدايا المرسلة والمستلمة وترتيب كبار الداعمين</span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-slate-500 group-hover:text-amber-400 transition-colors" />
        </button>

        {/* 6. الدعم والمساعدة */}
        <button
          onClick={() => setActiveModal('support')}
          className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 hover:bg-slate-800/80 border border-slate-800/80 transition-all cursor-pointer group"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div className="text-right">
              <span className="font-bold text-xs text-white block group-hover:text-amber-300 transition-colors">الدعم والمساعدة</span>
              <span className="text-[10px] text-slate-400">الأسئلة الشائعة وفتح تذكرة دعم للإدارة</span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-slate-500 group-hover:text-amber-400 transition-colors" />
        </button>

        {/* 7. عن التطبيق */}
        <button
          onClick={() => setActiveModal('about')}
          className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/70 hover:bg-slate-800/80 border border-slate-800/80 transition-all cursor-pointer group"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/20 border border-indigo-400/40 flex items-center justify-center text-indigo-300">
              <Info className="w-5 h-5" />
            </div>
            <div className="text-right">
              <span className="font-bold text-xs text-white block group-hover:text-amber-300 transition-colors">عن التطبيق</span>
              <span className="text-[10px] text-slate-400">الإصدار v3.8.5 والشروط وسياسة الخصوصية</span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-slate-500 group-hover:text-amber-400 transition-colors" />
        </button>

        {/* Option for Admin Control Panel */}
        <button
          onClick={onOpenAdminPanel}
          className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-red-950/30 hover:bg-red-900/40 border border-red-500/30 transition-all cursor-pointer group mt-2"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-red-500/20 border border-red-400/40 flex items-center justify-center text-red-400">
              <Shield className="w-5 h-5" />
            </div>
            <div className="text-right">
              <span className="font-bold text-xs text-red-300 block">لوحة تحكم الإدارة (Admin Panel)</span>
              <span className="text-[10px] text-red-200/70">مراقبة المعاملات وصلاحيات الغرف</span>
            </div>
          </div>
          <ChevronLeft className="w-5 h-5 text-red-400" />
        </button>
      </div>

      {/* 5. BOTTOM EDGE LOGOUT BUTTON (زر تسجيل الخروج) */}
      <div className="pt-2">
        <button
          onClick={() => setActiveModal('logout_confirm')}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-500 text-white font-black text-sm shadow-xl flex items-center justify-center gap-2 transition-transform active:scale-98 cursor-pointer border border-red-400/40"
        >
          <LogOut className="w-5 h-5" />
          <span>تسجيل الخروج من الحساب</span>
        </button>
      </div>

      {/* ==================== SUB-MODALS ==================== */}

      {/* 1. SETTINGS MODAL (⚙️) */}
      {activeModal === 'settings' && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 dir-rtl">
          <div className="bg-gradient-to-b from-slate-900 to-purple-950 border-2 border-purple-500/60 rounded-3xl p-5 max-w-md w-full space-y-4 shadow-2xl text-right animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto no-scrollbar">
            <div className="flex items-center justify-between border-b border-purple-500/30 pb-3">
              <div className="flex items-center gap-2 text-purple-300 font-black text-sm">
                <Settings className="w-5 h-5 text-amber-300" />
                <span>إعدادات الحساب المتقدمة</span>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-slate-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">اسم العرض (Name):</label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full bg-slate-950 border border-purple-500/40 rounded-xl px-3 py-2 text-white font-bold focus:border-amber-400 outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">الحالة الشخصية (Bio):</label>
                <input
                  type="text"
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  className="w-full bg-slate-950 border border-purple-500/40 rounded-xl px-3 py-2 text-white font-bold focus:border-amber-400 outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">تعديل العمر / تاريخ الميلاد:</label>
                <input
                  type="number"
                  value={editAge}
                  onChange={(e) => setEditAge(e.target.value)}
                  className="w-full bg-slate-950 border border-purple-500/40 rounded-xl px-3 py-2 text-white font-bold focus:border-amber-400 outline-none"
                />
              </div>

              <div className="border-t border-purple-900/40 pt-3 space-y-2">
                <h4 className="font-bold text-amber-300">تغيير كلمة المرور والأمان</h4>
                <input
                  type="password"
                  placeholder="كلمة المرور الحالية"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white outline-none"
                />
                <input
                  type="password"
                  placeholder="كلمة المرور الجديدة"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white outline-none"
                />
              </div>
            </div>

            <button
              onClick={() => {
                if (onUpdateUser) {
                  onUpdateUser({ name: editName, bio: editBio });
                }
                showToast('تم حفظ إعدادات الحساب بنجاح! 💾');
                setActiveModal(null);
              }}
              className="w-full py-3 bg-gradient-to-r from-purple-600 to-amber-500 text-white font-black text-xs rounded-2xl shadow-lg hover:brightness-110 cursor-pointer active:scale-95 transition-all"
            >
              حفظ التغييرات
            </button>
          </div>
        </div>
      )}

      {/* 2. PERSONAL INFO MODAL */}
      {activeModal === 'personal_info' && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 dir-rtl">
          <div className="bg-slate-900 border-2 border-blue-500/50 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl text-right animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2 text-blue-300 font-black text-sm">
                <User className="w-5 h-5 text-blue-400" />
                <span>معلومات الشخصية المحمية</span>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-full bg-white/10 text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs font-mono">
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[10px] block">البريد الإلكتروني:</span>
                <span className="font-bold text-white">salemmemadd11@gmail.com</span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[10px] block">رقم الهاتف المرتبط:</span>
                <span className="font-bold text-emerald-400">+966 50 *** **67</span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[10px] block">تاريخ التسجيل:</span>
                <span className="font-bold text-amber-300">2026/01/15</span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[10px] block">الدولة:</span>
                <span className="font-bold text-white">المملكة العربية السعودية 🇸🇦</span>
              </div>
            </div>

            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-2.5 bg-blue-600 text-white font-black text-xs rounded-xl shadow cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}

      {/* 3. SECURITY MODAL */}
      {activeModal === 'security' && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 dir-rtl">
          <div className="bg-slate-900 border-2 border-emerald-500/50 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl text-right animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2 text-emerald-300 font-black text-sm">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <span>الأمان والخصوصية</span>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-full bg-white/10 text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div>
                  <span className="font-bold text-white block">التحقق بخطوتين (2FA)</span>
                  <span className="text-[10px] text-slate-400">حماية الحساب عبر رمز SMS</span>
                </div>
                <input type="checkbox" defaultChecked className="w-4 h-4 accent-emerald-500 cursor-pointer" />
              </div>

              <div className="flex items-center justify-between bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div>
                  <span className="font-bold text-white block">إخفاء حالة التواجد (Online)</span>
                  <span className="text-[10px] text-slate-400">عدم إظهارك متصلاً للأصدقاء</span>
                </div>
                <input type="checkbox" className="w-4 h-4 accent-emerald-500 cursor-pointer" />
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                <span className="font-bold text-amber-300 block text-[11px]">الأجهزة المتصلة حالياً:</span>
                <div className="flex items-center justify-between text-[10px] text-slate-300 pt-1">
                  <span>📱 Samsung Galaxy S24 Ultra</span>
                  <span className="text-emerald-400 font-bold">نشط الآن</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                showToast('تم حفظ تفضيلات الأمان بنجاح! 🔒');
                setActiveModal(null);
              }}
              className="w-full py-2.5 bg-emerald-600 text-white font-black text-xs rounded-xl shadow cursor-pointer"
            >
              حفظ وتطبيق
            </button>
          </div>
        </div>
      )}

      {/* 4. MY WALLET & INTEGRATED VIRTUAL INVENTORY MODAL (محفظتي الشاملة) */}
      {activeModal === 'wallet_inventory' && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 dir-rtl">
          <div className="bg-gradient-to-b from-slate-900 via-purple-950/80 to-slate-950 border-2 border-purple-500/60 rounded-3xl p-4 max-w-lg w-full space-y-4 shadow-2xl text-right animate-in zoom-in-95 duration-200 max-h-[92vh] overflow-y-auto no-scrollbar">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-purple-500/30 pb-2.5">
              <div className="flex items-center gap-2 text-purple-200 font-black text-base">
                <Wallet className="w-5 h-5 text-amber-300" />
                <span>محفظتي الشاملة ومستودع الأدوات</span>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-slate-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* UPPER FINANCIAL BALANCE CARDS */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-slate-950/80 border border-amber-500/40 p-3 rounded-2xl space-y-1">
                <span className="text-slate-400 text-[10px]">العملات الصفراء (Coins):</span>
                <p className="font-black text-lg text-amber-300 font-mono">{user.coins.toLocaleString()} 🪙</p>
                <button
                  onClick={() => {
                    setActiveModal(null);
                    onOpenCoinStore();
                  }}
                  className="w-full py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 font-bold rounded-lg text-[10px] mt-1 cursor-pointer"
                >
                  + شحن عبر المتجر
                </button>
              </div>

              <div className="bg-slate-950/80 border border-cyan-500/40 p-3 rounded-2xl space-y-1">
                <span className="text-slate-400 text-[10px]">الألماس (Diamonds):</span>
                <p className="font-black text-lg text-cyan-300 font-mono">{user.diamonds.toLocaleString()} 💎</p>
                <button
                  onClick={() => {
                    setActiveModal(null);
                    onOpenWithdrawalModal();
                  }}
                  className="w-full py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-400/40 font-bold rounded-lg text-[10px] mt-1 cursor-pointer"
                >
                  💵 سحب كاش / تحويل
                </button>
              </div>
            </div>

            {/* LOWER VIRTUAL INVENTORY / TOOLS TABS */}
            <div className="space-y-3 pt-2 border-t border-purple-900/50">
              <div className="flex items-center justify-between">
                <h4 className="font-black text-xs text-amber-300 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>مستودع المقتنيات والأدوات (Inventory)</span>
                </h4>
                <span className="text-[10px] text-slate-400">تجهيز لحظي بدون إعادة تحميل</span>
              </div>

              {/* Sub Category Filter Tabs */}
              <div className="grid grid-cols-4 gap-1 bg-slate-950 p-1 rounded-2xl border border-slate-800 text-[11px] font-bold">
                <button
                  onClick={() => setActiveInventoryTab('frames')}
                  className={`py-1.5 rounded-xl transition-all cursor-pointer ${
                    activeInventoryTab === 'frames' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  الإطارات
                </button>
                <button
                  onClick={() => setActiveInventoryTab('rides')}
                  className={`py-1.5 rounded-xl transition-all cursor-pointer ${
                    activeInventoryTab === 'rides' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  المركبات
                </button>
                <button
                  onClick={() => setActiveInventoryTab('badges')}
                  className={`py-1.5 rounded-xl transition-all cursor-pointer ${
                    activeInventoryTab === 'badges' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  الشارات
                </button>
                <button
                  onClick={() => setActiveInventoryTab('wallpapers')}
                  className={`py-1.5 rounded-xl transition-all cursor-pointer ${
                    activeInventoryTab === 'wallpapers' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  الخلفيات
                </button>
              </div>

              {/* TAB 1: AVATAR FRAMES */}
              {activeInventoryTab === 'frames' && (
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {/* Item 1 */}
                  <div className="bg-slate-950 border border-amber-500/50 p-3 rounded-2xl space-y-2 text-center relative overflow-hidden">
                    <span className="absolute top-2 right-2 bg-amber-500 text-slate-950 font-black text-[9px] px-1.5 rounded shadow">
                      SSR
                    </span>
                    <div className="w-14 h-14 mx-auto rounded-full border-2 border-amber-400 p-0.5 shadow-[0_0_15px_rgba(245,158,11,0.5)]">
                      <img src={user.avatar} className="w-full h-full rounded-full object-cover" />
                    </div>
                    <div>
                      <p className="font-bold text-white text-[11px]">إطار الإمبراطور الذهبي</p>
                      <p className="text-[9px] text-amber-300 flex items-center justify-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>الصلاحية: دائم</span>
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setEquippedFrame('golden_imperial');
                        showToast('تم تجهيز إطار الإمبراطور الذهبي بنجاح! 👑');
                      }}
                      className={`w-full py-1.5 rounded-xl font-black text-[10px] transition-all cursor-pointer ${
                        equippedFrame === 'golden_imperial'
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-purple-600 hover:bg-purple-500 text-white'
                      }`}
                    >
                      {equippedFrame === 'golden_imperial' ? 'مُجهّز ومُفعّل ✓' : 'تجهيز الإطار'}
                    </button>
                  </div>

                  {/* Item 2 */}
                  <div className="bg-slate-950 border border-slate-800 p-3 rounded-2xl space-y-2 text-center relative">
                    <span className="absolute top-2 right-2 bg-purple-500 text-white font-black text-[9px] px-1.5 rounded">
                      S
                    </span>
                    <div className="w-14 h-14 mx-auto rounded-full border-2 border-purple-500 p-0.5">
                      <img src={user.avatar} className="w-full h-full rounded-full object-cover" />
                    </div>
                    <div>
                      <p className="font-bold text-white text-[11px]">إطار الأجنحة النارية</p>
                      <p className="text-[9px] text-slate-400 flex items-center justify-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>متبقي 3 أيام</span>
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setEquippedFrame('wings_flame');
                        showToast('تم تجهيز إطار الأجنحة النارية! 🔥');
                      }}
                      className={`w-full py-1.5 rounded-xl font-black text-[10px] transition-all cursor-pointer ${
                        equippedFrame === 'wings_flame'
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-purple-600 hover:bg-purple-500 text-white'
                      }`}
                    >
                      {equippedFrame === 'wings_flame' ? 'مُجهّز ومُفعّل ✓' : 'تجهيز الإطار'}
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 2: ENTRY RIDES */}
              {activeInventoryTab === 'rides' && (
                <div className="space-y-2 text-xs">
                  <div className="bg-slate-950 border border-slate-800 p-3 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 text-xl">
                        🏎️
                      </div>
                      <div>
                        <p className="font-bold text-white text-[11px]">لامبورغيني الملكية الذهبية</p>
                        <p className="text-[9px] text-slate-400">تظهر بإعلان فاخر عند دخول الغرفة - متبقي 14 يوم</p>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        setEquippedRide('lambo');
                        showToast('تم تجهيز مركبة الدخول: لامبورغيني الذهبية 🏎️');
                      }}
                      className={`px-3 py-1.5 rounded-xl font-black text-[10px] cursor-pointer ${
                        equippedRide === 'lambo' ? 'bg-emerald-500 text-slate-950' : 'bg-purple-600 text-white'
                      }`}
                    >
                      {equippedRide === 'lambo' ? 'مفعلة' : 'تجهيز'}
                    </button>
                  </div>

                  <div className="bg-slate-950 border border-slate-800 p-3 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 text-xl">
                        🛩️
                      </div>
                      <div>
                        <p className="font-bold text-white text-[11px]">طائرة الرئاسة الفاخرة</p>
                        <p className="text-[9px] text-slate-400">الصلاحية: دائم</p>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        setEquippedRide('jet');
                        showToast('تم تجهيز طائرة الرئاسة الفاخرة! 🛩️');
                      }}
                      className={`px-3 py-1.5 rounded-xl font-black text-[10px] cursor-pointer ${
                        equippedRide === 'jet' ? 'bg-emerald-500 text-slate-950' : 'bg-purple-600 text-white'
                      }`}
                    >
                      {equippedRide === 'jet' ? 'مفعلة' : 'تجهيز'}
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 3: BADGES */}
              {activeInventoryTab === 'badges' && (
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-slate-950 border border-slate-800 p-2.5 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">🌟</span>
                      <div>
                        <p className="font-bold text-white text-[10px]">شارة نجم محظوظ</p>
                        <p className="text-[8px] text-amber-300">شارة دعم مميزة</p>
                      </div>
                    </div>
                    <input type="checkbox" defaultChecked className="w-4 h-4 accent-amber-500 cursor-pointer" />
                  </div>

                  <div className="bg-slate-950 border border-slate-800 p-2.5 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">💎</span>
                      <div>
                        <p className="font-bold text-white text-[10px]">وسام كبار الشخصيات</p>
                        <p className="text-[8px] text-purple-300">Crown SVIP</p>
                      </div>
                    </div>
                    <input type="checkbox" defaultChecked className="w-4 h-4 accent-amber-500 cursor-pointer" />
                  </div>
                </div>
              )}

              {/* TAB 4: ROOM WALLPAPERS */}
              {activeInventoryTab === 'wallpapers' && (
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-slate-950 border border-purple-500/50 p-2 rounded-2xl space-y-1 text-center">
                    <div className="h-16 rounded-xl bg-gradient-to-tr from-purple-900 to-indigo-900 border border-purple-400/40 flex items-center justify-center font-black text-[10px] text-amber-300">
                      خلفية البنفسج الملكي
                    </div>
                    <button
                      onClick={() => showToast('تم تفعيل خلفية البنفسج لغرفتك الخاصة! 🪐')}
                      className="w-full py-1 bg-purple-600 text-white font-bold rounded-lg text-[9px] cursor-pointer"
                    >
                      تطبيق على غرفتي
                    </button>
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-3 bg-gradient-to-r from-purple-600 to-amber-500 text-white font-black text-xs rounded-2xl shadow-lg hover:brightness-110 cursor-pointer"
            >
              حفظ الخيارات والإغلاق
            </button>
          </div>
        </div>
      )}

      {/* 5. LEVEL & ACHIEVEMENTS MODAL */}
      {activeModal === 'level_achievements' && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 dir-rtl">
          <div className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl text-right animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2 text-amber-300 font-black text-sm">
                <Award className="w-5 h-5 text-amber-400" />
                <span>المستوى والإنجازات (XP)</span>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-full bg-white/10 text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-slate-950 p-3 rounded-2xl border border-amber-500/30 space-y-1.5">
                <div className="flex justify-between font-bold">
                  <span className="text-white">المستوى الحالي: 42</span>
                  <span className="text-amber-300">4,200 / 5,000 XP</span>
                </div>
                <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full w-[84%]" />
                </div>
              </div>

              <div className="space-y-1.5">
                <h4 className="font-bold text-white text-[11px]">المهام اليومية وتحصيل المكافآت:</h4>
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
                  <div>
                    <p className="font-bold text-slate-200 text-[10px]">البقاء في الغرفة 15 دقيقة</p>
                    <p className="text-[8px] text-amber-400">+100 عملة صفراء</p>
                  </div>
                  <button
                    onClick={() => showToast('تم تحصيل مكافأة المهمة اليومية! +100 🪙')}
                    className="px-2.5 py-1 bg-amber-500 text-slate-950 font-black text-[9px] rounded-lg cursor-pointer"
                  >
                    استلام
                  </button>
                </div>
              </div>
            </div>

            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-2.5 bg-amber-500 text-slate-950 font-black text-xs rounded-xl shadow cursor-pointer"
            >
              حسناً
            </button>
          </div>
        </div>
      )}

      {/* 6. GIFTS HISTORY MODAL */}
      {activeModal === 'gifts_history' && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 dir-rtl">
          <div className="bg-slate-900 border-2 border-pink-500/50 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl text-right animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2 text-pink-300 font-black text-sm">
                <Gift className="w-5 h-5 text-pink-400" />
                <span>سجل الهدايا والدعم</span>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-full bg-white/10 text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <p className="font-bold text-white text-[11px]">هدية سيارة لامبورغيني 🏎️</p>
                  <p className="text-[9px] text-slate-400">أرسلت إلى: الشيخ خالد</p>
                </div>
                <span className="font-mono text-amber-300 font-bold text-[10px]">5,000 🪙</span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <p className="font-bold text-white text-[11px]">هدية تاج الملوك 👑</p>
                  <p className="text-[9px] text-slate-400">استلمتها من: النجم علي</p>
                </div>
                <span className="font-mono text-cyan-300 font-bold text-[10px]">10,000 💎</span>
              </div>
            </div>

            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-2.5 bg-pink-600 text-white font-black text-xs rounded-xl shadow cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}

      {/* 7. SUPPORT MODAL */}
      {activeModal === 'support' && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 dir-rtl">
          <div className="bg-slate-900 border-2 border-cyan-500/50 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl text-right animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2 text-cyan-300 font-black text-sm">
                <HelpCircle className="w-5 h-5 text-cyan-400" />
                <span>الدعم الفني والمساعدة</span>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1 rounded-full bg-white/10 text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-300 leading-relaxed text-[11px]">
                إذا واجهتك أي مشكلة في شحن الرصيد أو سحب الأرباح أو البث، يمكنك فتح تذكرة دعم مباشرة للإدارة:
              </p>

              <textarea
                value={supportMessage}
                onChange={(e) => setSupportMessage(e.target.value)}
                placeholder="اكتب تفاصيل المشكلة هنا..."
                className="w-full h-24 bg-slate-950 border border-slate-800 rounded-xl p-3 text-white text-xs outline-none focus:border-cyan-400"
              />
            </div>

            <button
              onClick={() => {
                if (!supportMessage.trim()) {
                  showToast('يرجى كتابة رسالة الدعم أولاً!');
                  return;
                }
                showToast('تم إرسال تذكرة الدعم للإدارة بنجاح! سيتم الرد قريباً 📩');
                setSupportMessage('');
                setActiveModal(null);
              }}
              className="w-full py-2.5 bg-cyan-600 text-white font-black text-xs rounded-xl shadow cursor-pointer"
            >
              إرسال التذكرة
            </button>
          </div>
        </div>
      )}

      {/* 8. ABOUT APP MODAL */}
      {activeModal === 'about' && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 dir-rtl">
          <div className="bg-slate-900 border-2 border-indigo-500/50 rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl text-right animate-in zoom-in-95 duration-200 text-center">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-tr from-purple-600 to-amber-500 border border-amber-300/50 flex items-center justify-center text-2xl shadow-xl">
              👑
            </div>

            <div>
              <h3 className="font-black text-base text-white">تطبيق SALEEM VOICE</h3>
              <p className="text-xs text-amber-300 font-mono">النسخة v3.8.5 - Build 2026</p>
              <p className="text-[10px] text-slate-400 mt-1">منصة الصوت والدردشة والبث المباشر الأولى عالمياً</p>
            </div>

            <div className="text-[10px] text-slate-300 space-y-1 border-t border-slate-800 pt-3">
              <p>شروط الاستخدام - سياسة الخصوصية الرسمية</p>
              <p className="text-slate-500">جميع الحقوق محفوظة © SALEEM App 2026</p>
            </div>

            <button
              onClick={() => setActiveModal(null)}
              className="w-full py-2.5 bg-indigo-600 text-white font-black text-xs rounded-xl shadow cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}

      {/* 9. LOGOUT CONFIRMATION DIALOG */}
      {activeModal === 'logout_confirm' && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 dir-rtl">
          <div className="bg-slate-900 border-2 border-red-500/70 rounded-3xl p-5 max-w-xs w-full space-y-4 shadow-2xl text-center animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 mx-auto rounded-full bg-red-500/20 border border-red-500/50 flex items-center justify-center text-red-400">
              <LogOut className="w-7 h-7" />
            </div>

            <div>
              <h3 className="font-black text-base text-white">تأكيد تسجيل الخروج</h3>
              <p className="text-xs text-slate-300 mt-1">هل أنت أصلًا متأكد من تسجيل الخروج وحفظ جلسة الحساب الآن؟</p>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => setActiveModal(null)}
                className="py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl cursor-pointer"
              >
                إلغاء
              </button>
              <button
                onClick={async () => {
                  setActiveModal(null);
                  if (user && user.id) {
                    await updateUserLogoutStatusInFirebase(user);
                  } else {
                    console.warn('⚠️ [ProfileView] user or user.id is missing on logout.');
                  }
                  if (onLogout) {
                    onLogout();
                  } else {
                    showToast('تم تسجيل الخروج بنجاح وتحديث الحالة في Firebase 👋');
                  }
                }}
                className="py-2.5 bg-red-600 hover:bg-red-500 text-white font-black text-xs rounded-xl shadow-lg cursor-pointer"
              >
                نعم، خروج
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Banner Alert */}
      {toast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[100] bg-purple-950/95 border border-amber-400/80 text-amber-200 font-black text-xs px-5 py-3 rounded-2xl shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-top-3 duration-200">
          {toast}
        </div>
      )}

    </div>
  );
};
