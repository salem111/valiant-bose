import React, { useState, useEffect } from 'react';
import { Sparkles, Radio, Gamepad2, Gift, Volume2, ShieldCheck, Play } from 'lucide-react';

interface BannerProps {
  onOpenGames: () => void;
  onOpenStore: () => void;
  onOpenVip: () => void;
}

const BANNER_SLIDES = [
  {
    id: 1,
    title: 'تطبيق SALEEM الأصلي 👑',
    slogan: 'عالم الدردشة الصوتية والألعاب التفاعلية',
    tagline: 'أنشئ غرفتك الصوتية، تنافس في ألعاب الشدة والرهان، واكسب آلاف الهدايا!',
    badge: 'عرض خاص 💥',
    gradient: 'from-amber-600 via-purple-900 to-slate-950',
    icon: Volume2,
    actionText: 'شحن العملات الآن',
    actionType: 'store',
  },
  {
    id: 2,
    title: 'بطولات الشدة والرهان الحماسي 🃏🔥',
    slogan: 'ألعاب الطرنيب، الصاروخ، ومنجم الألماس',
    tagline: 'تحدّى أصدقاءك في طاولات الرهان اليومية مع ضمان الأرباح الفورية 🪙',
    badge: 'بطولة كبرى 🏆',
    gradient: 'from-emerald-700 via-slate-900 to-indigo-950',
    icon: Gamepad2,
    actionText: 'العب الآن',
    actionType: 'games',
  },
  {
    id: 3,
    title: 'عضوية VIP الأسطورية 💎',
    slogan: 'مميزات استثنائية وهدايا ملكية متحركة',
    tagline: 'احصل على إطار التاج المضيء، ودخول مميز للغرف الصوتية، ومكافآت يومية',
    badge: 'خصم VIP 👑',
    gradient: 'from-rose-700 via-amber-950 to-slate-950',
    icon: Gift,
    actionText: 'استكشف رتب VIP',
    actionType: 'vip',
  },
];

export const Banner: React.FC<BannerProps> = ({ onOpenGames, onOpenStore, onOpenVip }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % BANNER_SLIDES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const slide = BANNER_SLIDES[currentIndex];

  const handleAction = (type: string) => {
    if (type === 'store') onOpenStore();
    else if (type === 'games') onOpenGames();
    else if (type === 'vip') onOpenVip();
  };

  return (
    <div id="saleem-top-banner" className="relative w-full overflow-hidden rounded-2xl my-3 shadow-2xl border border-amber-500/30">
      <div
        className={`w-full bg-gradient-to-r ${slide.gradient} p-4 sm:p-6 transition-all duration-700 relative flex flex-col md:flex-row items-center justify-between gap-4`}
      >
        {/* Background glow effects */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Content */}
        <div className="relative z-10 space-y-2 text-right w-full md:w-3/4">
          <div className="flex items-center gap-2 justify-start flex-wrap">
            <span className="bg-amber-400 text-slate-950 font-black text-xs px-2.5 py-0.5 rounded-full shadow-md animate-pulse">
              {slide.badge}
            </span>
            <span className="flex items-center gap-1 bg-slate-900/60 text-amber-300 text-xs px-2 py-0.5 rounded-full border border-amber-400/20">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>مضمون عبر Google Play</span>
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-white tracking-wide flex items-center gap-2">
            <span>{slide.title}</span>
          </h2>

          <p className="text-amber-200 font-bold text-sm sm:text-base">
            ✨ {slide.slogan}
          </p>

          <p className="text-slate-300 text-xs sm:text-sm font-normal leading-relaxed max-w-xl">
            {slide.tagline}
          </p>
        </div>

        {/* Interactive Button & Visual Icon */}
        <div className="relative z-10 flex flex-col items-center gap-2 w-full md:w-auto">
          <button
            onClick={() => handleAction(slide.actionType)}
            className="w-full md:w-auto flex items-center justify-center gap-2 bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 text-slate-950 font-black text-sm px-6 py-3 rounded-xl shadow-lg hover:brightness-110 active:scale-95 transition-all border border-amber-200/50"
          >
            <slide.icon className="w-5 h-5 text-slate-950" />
            <span>{slide.actionText}</span>
          </button>

          {/* Slide Indicator Dots */}
          <div className="flex items-center gap-1.5 mt-1">
            {BANNER_SLIDES.map((s, idx) => (
              <button
                key={s.id}
                onClick={() => setCurrentIndex(idx)}
                className={`h-2 rounded-full transition-all ${
                  idx === currentIndex ? 'w-6 bg-amber-400' : 'w-2 bg-slate-600 hover:bg-slate-400'
                }`}
                title={`شريحة ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
