import React, { useState, useEffect, useRef } from 'react';
import { UserProfile } from '../../types';
import {
  Rocket,
  Flame,
  Coins,
  Zap,
  ShieldAlert,
  Trophy,
  Volume2,
  VolumeX,
  HelpCircle,
  ArrowLeft,
  Clock,
  BarChart3,
  CheckCircle2,
  AlertCircle,
  X,
  History,
  Sparkles,
} from 'lucide-react';

interface RocketGameProps {
  user: UserProfile;
  onUpdateCoins: (delta: number) => void;
  onBack?: () => void;
}

// Player Bet in Current Round
interface PlayerBet {
  id: string;
  name: string;
  avatar: string;
  bet: number;
  cashedOutMultiplier?: number;
}

export const RocketGame: React.FC<RocketGameProps> = ({ user, onUpdateCoins, onBack }) => {
  // Game loop phases: COOLDOWN (5s countdown) -> FLYING -> CRASHED
  const [phase, setPhase] = useState<'COOLDOWN' | 'FLYING' | 'CRASHED'>('COOLDOWN');
  const [countdown, setCountdown] = useState<number>(5);
  const [multiplier, setMultiplier] = useState<number>(1.00);
  const [crashTarget, setCrashTarget] = useState<number>(2.45);
  const [roundNumber, setRoundNumber] = useState<number>(389426);
  const [ping, setPing] = useState<number>(184);

  // User Bet state
  const [selectedBetChip, setSelectedBetChip] = useState<number>(100);
  const [isBetPlaced, setIsBetPlaced] = useState<boolean>(false);
  const [hasCashedOut, setHasCashedOut] = useState<boolean>(false);
  const [cashedOutMultiplier, setCashedOutMultiplier] = useState<number>(1.00);
  const [wonCoins, setWonCoins] = useState<number>(0);

  // Auto Cashout setting
  const [autoCashoutEnabled, setAutoCashoutEnabled] = useState<boolean>(false);
  const [autoCashoutTarget, setAutoCashoutTarget] = useState<number>(1.22);

  // Sound and Modals
  const [soundMuted, setSoundMuted] = useState<boolean>(false);
  const [showStatsModal, setShowStatsModal] = useState<boolean>(false);
  const [showRulesModal, setShowRulesModal] = useState<boolean>(false);

  // Round Multipliers History (last 50)
  const [history, setHistory] = useState<number[]>([
    1.45, 1.65, 1.05, 13.75, 3.74, 18.72, 289.5, 1.00, 3.34, 1.26, 5.39, 3.19, 1.26,
    3.10, 1.05, 1.18, 4.75, 19.29, 31.65, 1.42, 1.03, 1.26, 5.56, 3.09, 2.60, 4.22,
    1.49, 1.11, 12.45, 1.13, 1.02, 1.79, 1.55, 1.24, 2.99, 3.02, 2.34, 1.79, 7.97,
    1.00, 2.09, 13.10, 4.15, 1.49, 12.88, 3.12, 3.71, 2.20, 1.22, 1.20,
  ]);

  // Active Players ONLY in current round (empty if no one joined, grows if people bet)
  const [livePlayers, setLivePlayers] = useState<PlayerBet[]>([]);

  // Canvas Reference for 3D/2D Diagonal Physics Engine
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<Array<{ x: number; y: number; vx: number; vy: number; life: number; color: string; size: number }>>([]);
  const starsRef = useRef<Array<{ x: number; y: number; speed: number; size: number; opacity: number }>>([]);

  // Synthesizer Web Audio API for sound FX
  const playSound = (type: 'beep' | 'launch' | 'cashout' | 'crash') => {
    if (soundMuted) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'beep') {
        osc.frequency.setValueAtTime(600, ctx.currentTime);
        gain.gain.setValueAtTime(0.08, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.08);
      } else if (type === 'launch') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(150, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(650, ctx.currentTime + 0.5);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.5);
      } else if (type === 'cashout') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, ctx.currentTime);
        osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.1);
        osc.frequency.setValueAtTime(783.99, ctx.currentTime + 0.2);
        gain.gain.setValueAtTime(0.18, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.35);
      } else if (type === 'crash') {
        osc.type = 'square';
        osc.frequency.setValueAtTime(120, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(30, ctx.currentTime + 0.5);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.5);
      }
    } catch (e) {
      // Fallback
    }
  };

  // Ping fluctuation simulation
  useEffect(() => {
    const pingInterval = setInterval(() => {
      setPing(Math.floor(170 + Math.random() * 40));
    }, 3000);
    return () => clearInterval(pingInterval);
  }, []);

  // Secure RNG Server Crash Point Generator
  const generateServerCrashPoint = (): number => {
    const rand = Math.random();
    if (rand < 0.05) return 1.00; // 5% house instant crash
    const crash = 0.95 / (1 - rand);
    return parseFloat(Math.min(crash, 500.0).toFixed(2));
  };

  // Initialize Canvas Background Stars
  useEffect(() => {
    const starList: Array<{ x: number; y: number; speed: number; size: number; opacity: number }> = [];
    for (let i = 0; i < 60; i++) {
      starList.push({
        x: Math.random() * 500,
        y: Math.random() * 300,
        speed: 0.5 + Math.random() * 2,
        size: 1 + Math.random() * 2,
        opacity: 0.3 + Math.random() * 0.7,
      });
    }
    starsRef.current = starList;
  }, []);

  // MAIN GAME LOOP ENGINE
  useEffect(() => {
    let timer: any;

    if (phase === 'COOLDOWN') {
      // Reset variables for new round
      setMultiplier(1.00);
      setIsBetPlaced(false);
      setHasCashedOut(false);
      setWonCoins(0);

      // Reset live players list (ONLY users who placed a bet in this round)
      // Simulate 1 to 3 active players joining during cooldown
      const numSimulated = Math.floor(1 + Math.random() * 3);
      const simulatedPlayersList: PlayerBet[] = [
        { id: 'p1', name: 'سالم', avatar: '🐱', bet: Math.floor(100 + Math.random() * 1000) },
        { id: 'p2', name: 'خالد الملك', avatar: '👑', bet: Math.floor(500 + Math.random() * 2000) },
        { id: 'p3', name: 'أحمد', avatar: '🐉', bet: Math.floor(100 + Math.random() * 500) },
      ].slice(0, numSimulated);

      setLivePlayers(simulatedPlayersList);

      // Generate secret server crash target
      const newTarget = generateServerCrashPoint();
      setCrashTarget(newTarget);

      // Cooldown timer (5 seconds)
      setCountdown(5);
      timer = setInterval(() => {
        setCountdown((prev) => {
          playSound('beep');
          if (prev <= 1) {
            clearInterval(timer);
            setPhase('FLYING');
            playSound('launch');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (phase === 'FLYING') {
      // Flight loop: Multiplier ticks up smoothly
      const startTime = Date.now();
      timer = setInterval(() => {
        const elapsedSec = (Date.now() - startTime) / 1000;
        const currentMult = parseFloat((1.00 + Math.pow(elapsedSec * 0.45, 1.4)).toFixed(2));

        if (currentMult >= crashTarget) {
          // CRASH HIT!
          setMultiplier(crashTarget);
          setPhase('CRASHED');
          playSound('crash');
          setHistory((prev) => [crashTarget, ...prev.slice(0, 49)]);
          setRoundNumber((r) => r + 1);
          clearInterval(timer);
        } else {
          setMultiplier(currentMult);

          // Simulate live players cashing out randomly at different points
          setLivePlayers((prev) =>
            prev.map((p) => {
              if (!p.cashedOutMultiplier && currentMult > 1.15 && Math.random() < 0.08) {
                return { ...p, cashedOutMultiplier: currentMult };
              }
              return p;
            })
          );
        }
      }, 80);
    } else if (phase === 'CRASHED') {
      // Wait 2.5 seconds at Crash screen then loop back to Cooldown
      timer = setTimeout(() => {
        setPhase('COOLDOWN');
      }, 2500);
    }

    return () => {
      if (timer) clearInterval(timer);
      if (typeof timer === 'number') clearTimeout(timer);
    };
  }, [phase]);

  // Auto Cashout check during flight
  useEffect(() => {
    if (
      phase === 'FLYING' &&
      isBetPlaced &&
      !hasCashedOut &&
      autoCashoutEnabled &&
      multiplier >= autoCashoutTarget
    ) {
      triggerCashout();
    }
  }, [phase, isBetPlaced, hasCashedOut, autoCashoutEnabled, multiplier, autoCashoutTarget]);

  // Handle Place Bet (User Joins Active Players)
  const handlePlaceBet = () => {
    if (phase !== 'COOLDOWN') return;
    if (user.coins < selectedBetChip) {
      alert('رصيد العملات لديك غير كافٍ لهذا الرهان! يرجى الشحن أولاً.');
      return;
    }
    onUpdateCoins(-selectedBetChip);
    setIsBetPlaced(true);
    playSound('beep');

    // Add current user to active players list
    const userBetObj: PlayerBet = {
      id: user.id || 'user',
      name: user.name || 'أنت',
      avatar: user.avatar || '👤',
      bet: selectedBetChip,
    };

    setLivePlayers((prev) => [userBetObj, ...prev.filter((p) => p.id !== userBetObj.id)]);
  };

  // Handle Cashout Action
  const triggerCashout = () => {
    if (phase !== 'FLYING' || !isBetPlaced || hasCashedOut) return;
    const currentMult = multiplier;
    const winnings = Math.floor(selectedBetChip * currentMult);

    setHasCashedOut(true);
    setCashedOutMultiplier(currentMult);
    setWonCoins(winnings);
    onUpdateCoins(winnings);
    playSound('cashout');

    // Update user's cashed out multiplier in live players list
    setLivePlayers((prev) =>
      prev.map((p) =>
        p.id === (user.id || 'user') ? { ...p, cashedOutMultiplier: currentMult } : p
      )
    );
  };

  // CANVAS RENDER ANIMATION LOOP (3D/2D Diagonal Takeoff Curve & Physics)
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let time = 0;

    const render = () => {
      time += 0.03;
      const width = canvas.width;
      const height = canvas.height;

      // 1. Clear & Render Deep Space Gradient Background
      const bgGradient = ctx.createLinearGradient(0, 0, width, height);
      bgGradient.addColorStop(0, '#020617');
      bgGradient.addColorStop(0.5, '#0f172a');
      bgGradient.addColorStop(1, '#030712');
      ctx.fillStyle = bgGradient;
      ctx.fillRect(0, 0, width, height);

      // 2. Parallax Stars & Celestial Planets Background Movement (Infinite Space Scroll)
      const flightSpeed = phase === 'FLYING' ? Math.min(24, 2.5 + (multiplier - 1) * 4) : 0.5;
      
      // Draw Distant Glowing Planets in Parallax Background
      const planetY = (time * flightSpeed * 10) % (height + 200) - 100;
      ctx.save();
      // Saturn Ring Planet
      ctx.fillStyle = 'rgba(245, 158, 11, 0.15)';
      ctx.beginPath();
      ctx.arc(width * 0.8, planetY, 28, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = 'rgba(251, 191, 36, 0.25)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.ellipse(width * 0.8, planetY, 45, 10, -Math.PI / 6, 0, Math.PI * 2);
      ctx.stroke();

      // Red Mars Planet
      const marsY = ((time * flightSpeed * 6) + 150) % (height + 200) - 100;
      ctx.fillStyle = 'rgba(239, 68, 68, 0.12)';
      ctx.beginPath();
      ctx.arc(width * 0.2, marsY, 20, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      ctx.fillStyle = '#ffffff';

      starsRef.current.forEach((star) => {
        if (phase === 'FLYING') {
          // Move stars downwards and leftwards at high speed
          star.x -= flightSpeed * 1.8;
          star.y += flightSpeed * 1.5;
          if (star.x < 0) star.x = width;
          if (star.y > height) star.y = 0;
        }

        ctx.globalAlpha = Math.max(0, Math.min(1, star.opacity * (0.6 + Math.sin(time * 3 + star.x) * 0.4)));
        ctx.beginPath();
        ctx.arc(star.x, star.y, Math.max(0, star.size), 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.globalAlpha = 1.0;

      // 3. Grid Lines Overlay (Perspective Space Grid)
      ctx.strokeStyle = 'rgba(99, 102, 241, 0.12)';
      ctx.lineWidth = 1;
      const gridOffset = (time * 25 * flightSpeed) % 30;

      for (let x = -30; x < width + 30; x += 30) {
        ctx.beginPath();
        ctx.moveTo(x - gridOffset, 0);
        ctx.lineTo(x - gridOffset, height);
        ctx.stroke();
      }
      for (let y = -30; y < height + 30; y += 30) {
        ctx.beginPath();
        ctx.moveTo(0, y + gridOffset);
        ctx.lineTo(width, y + gridOffset);
        ctx.stroke();
      }

      // 4. Calculate Rocket Position (Diagonal Takeoff Trajectory locked at Screen Center)
      // Bottom-Left (50, H-40) to Screen Center (W*0.5, H*0.45)
      const startX = 50;
      const startY = height - 40;
      const targetX = width * 0.50; // Locked in exact center of phone screen
      const targetY = height * 0.45; // Locked in exact center height

      let rx = startX;
      let ry = startY;

      if (phase === 'FLYING') {
        // Clamp takeoff progress to reach screen center smoothly at 1.4x multiplier
        const progress = Math.min(1.0, (multiplier - 1.0) / 0.4);
        rx = startX + (targetX - startX) * progress;
        ry = startY - (startY - targetY) * progress;

        // Sine wave hovering wave effect & vibration (float & wave effect in center)
        const sineHover = Math.sin(time * 7) * 4;
        rx += Math.cos(time * 5) * 2;
        ry += sineHover;
      } else if (phase === 'CRASHED') {
        rx = targetX;
        ry = targetY;
      }

      // 5. Draw Particle Flame & Smoke Exhaust Trail (Particles System)
      if (phase === 'FLYING') {
        // Emit new fire/smoke particles from rocket rear
        const colors = ['#f59e0b', '#ef4444', '#f97316', '#fbbf24', '#ffffff'];
        for (let i = 0; i < 3; i++) {
          particlesRef.current.push({
            x: rx - 15 + (Math.random() * 6 - 3),
            y: ry + 15 + (Math.random() * 6 - 3),
            vx: -2 - Math.random() * 3,
            vy: 2 + Math.random() * 3,
            life: 1.0,
            color: colors[Math.floor(Math.random() * colors.length)],
            size: 3 + Math.random() * 4,
          });
        }
      }

      // Update and Draw Particles
      particlesRef.current = particlesRef.current.filter((p) => p.life > 0);
      particlesRef.current.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.04;

        const pRadius = Math.max(0, p.size * p.life);
        if (pRadius > 0) {
          ctx.fillStyle = p.color;
          ctx.globalAlpha = Math.max(0, Math.min(1, p.life));
          ctx.beginPath();
          ctx.arc(p.x, p.y, pRadius, 0, Math.PI * 2);
          ctx.fill();
        }
      });
      ctx.globalAlpha = 1.0;

      // 6. Draw Flight Path Trail Line
      if (phase === 'FLYING' || phase === 'CRASHED') {
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.quadraticCurveTo(
          startX + (rx - startX) * 0.5,
          startY,
          rx,
          ry
        );
        ctx.strokeStyle = phase === 'CRASHED' ? '#ef4444' : '#f59e0b';
        ctx.lineWidth = 3;
        ctx.setLineDash([6, 4]);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // 7. Draw Rocket Graphic (Diagonal Angle ~45 degrees + Sine Tilt)
      ctx.save();
      ctx.translate(rx, ry);

      if (phase === 'CRASHED') {
        // Explosion graphics
        ctx.fillStyle = '#ef4444';
        ctx.font = '28px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('💥', 0, 10);
      } else {
        // Rocket angle tilt: -45 deg diagonal flight + sine oscillation pitch
        const pitchTilt = phase === 'FLYING' ? Math.sin(time * 6) * 0.08 : 0;
        ctx.rotate(-Math.PI / 4 + pitchTilt);

        // Rocket Body
        ctx.fillStyle = '#f8fafc';
        ctx.beginPath();
        ctx.ellipse(0, 0, 10, 22, 0, 0, Math.PI * 2);
        ctx.fill();

        // Rocket Nosecone (Cyan)
        ctx.fillStyle = '#06b6d4';
        ctx.beginPath();
        ctx.moveTo(-10, -5);
        ctx.lineTo(0, -26);
        ctx.lineTo(10, -5);
        ctx.closePath();
        ctx.fill();

        // Rocket Fins (Red)
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(-14, 10, 5, 12);
        ctx.fillRect(9, 10, 5, 12);

        // Window (Amber Glass)
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(0, -5, 4, 0, Math.PI * 2);
        ctx.fill();

        // Main Thruster Engine Flame
        if (phase === 'FLYING') {
          ctx.fillStyle = '#f97316';
          ctx.beginPath();
          ctx.moveTo(-6, 22);
          ctx.lineTo(0, 38 + Math.sin(time * 20) * 6);
          ctx.lineTo(6, 22);
          ctx.closePath();
          ctx.fill();
        }
      }

      ctx.restore();

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [phase, multiplier]);

  return (
    <div className="w-full max-w-md mx-auto bg-slate-950 text-white rounded-3xl border border-slate-800 shadow-2xl overflow-hidden font-sans select-none flex flex-col dir-rtl">
      {/* 1. TOP GAME NAVIGATION HEADER */}
      <div className="bg-slate-900/90 border-b border-slate-800 p-3 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              onClick={onBack}
              className="p-1 rounded-full bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <span className="font-black text-amber-300 text-sm flex items-center gap-1">
            <Rocket className="w-4 h-4 text-amber-400" />
            صاروخ
          </span>
          <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-0.5 bg-emerald-950/60 px-1.5 py-0.5 rounded-full border border-emerald-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            {ping}ms
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* User Coins Balance */}
          <div className="bg-slate-950 px-2.5 py-1 rounded-full border border-amber-500/40 text-amber-300 font-mono font-black flex items-center gap-1 text-[11px]">
            <span>{user.coins.toLocaleString()}</span>
            <span className="text-xs">🪙</span>
          </div>

          <span className="text-[10px] text-slate-400 font-mono">الجولة {roundNumber}</span>

          {/* Mute Sound Button */}
          <button
            onClick={() => setSoundMuted(!soundMuted)}
            className="p-1.5 rounded-full bg-slate-800 text-slate-300 hover:text-amber-300 cursor-pointer"
          >
            {soundMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-amber-400" />}
          </button>

          {/* Rules button */}
          <button
            onClick={() => setShowRulesModal(true)}
            className="p-1.5 rounded-full bg-slate-800 text-slate-300 hover:text-white cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 2. ROCKET ARENA CANVAS & FLIGHT ARENA */}
      <div className="relative h-64 sm:h-72 bg-slate-950 overflow-hidden border-b border-slate-800">
        {/* Interactive Physics HTML5 Canvas */}
        <canvas
          ref={canvasRef}
          width={400}
          height={280}
          className="w-full h-full block"
        />

        {/* Right Side Multiplier Grid Ticks */}
        <div className="absolute right-2 top-4 bottom-4 flex flex-col justify-between text-[9px] font-mono font-bold text-slate-500 pointer-events-none z-10">
          <span>2.0x</span>
          <span>1.8x</span>
          <span>1.6x</span>
          <span>1.4x</span>
          <span>1.2x</span>
        </div>

        {/* Left Side Overlay: ACTIVE PLAYERS IN CURRENT ROUND ONLY */}
        <div className="absolute left-2 top-3 space-y-1.5 z-20 max-w-[180px] pointer-events-none">
          {livePlayers.length === 0 ? (
            <div className="bg-slate-900/60 backdrop-blur-sm border border-slate-800 px-2.5 py-1 rounded-xl text-[9px] text-slate-400 font-bold">
              لا يوجد لاعبين في هذه الجولة بعد
            </div>
          ) : (
            livePlayers.map((p) => (
              <div
                key={p.id}
                className={`backdrop-blur-md px-2.5 py-1 rounded-2xl flex items-center justify-between gap-1.5 text-[10px] font-mono shadow-lg transition-all ${
                  p.cashedOutMultiplier
                    ? 'bg-emerald-950/90 border border-emerald-500/70 text-emerald-300 animate-in fade-in'
                    : 'bg-slate-900/90 border border-slate-700 text-slate-200'
                }`}
              >
                {/* Landing Point Display (e.g. 1.63x or Bet) */}
                <span
                  className={`font-black tracking-tight shrink-0 ${
                    p.cashedOutMultiplier ? 'text-emerald-400 text-xs' : 'text-amber-300'
                  }`}
                >
                  {p.cashedOutMultiplier ? `${p.cashedOutMultiplier.toFixed(2)}x` : `${p.bet}🪙`}
                </span>

                <div className="flex items-center gap-1 truncate text-slate-200 font-bold min-w-0">
                  <span className="truncate font-sans text-[11px]">{p.name}</span>
                  <span className="shrink-0">{p.avatar}</span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Center Multiplier / Cooldown Badge */}
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-start pt-4 pointer-events-none">
          {phase === 'COOLDOWN' && (
            <div className="space-y-1 text-center animate-in zoom-in duration-200">
              <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-600 p-0.5 shadow-2xl flex items-center justify-center">
                <div className="w-full h-full rounded-full bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center">
                  <span className="text-2xl font-black font-mono text-amber-300">{countdown}</span>
                </div>
              </div>
              <span className="font-black text-amber-300 text-xs block">وقت التبريد</span>
              <span className="text-[9px] text-slate-300 block bg-slate-950/60 backdrop-blur-sm px-2 py-0.5 rounded-full border border-slate-800/80">
                حدد رهانك واضغط تأكيد للانطلاق
              </span>
            </div>
          )}

          {phase === 'FLYING' && (
            <div className="space-y-0.5 text-center animate-in zoom-in duration-100">
              <div className="inline-block px-3.5 py-1 rounded-2xl bg-slate-950/40 border border-amber-400/50 shadow-lg backdrop-blur-md">
                <span className="text-2xl sm:text-3xl font-black font-mono text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400 tracking-tight">
                  {multiplier.toFixed(2)}x
                </span>
              </div>
              <span className="font-bold text-amber-300/90 text-[10px] block drop-shadow">ارتفاع الرحلة</span>
            </div>
          )}

          {phase === 'CRASHED' && (
            <div className="space-y-0.5 text-center animate-in zoom-in duration-150">
              <div className="inline-block px-3.5 py-1 rounded-2xl bg-rose-950/40 border border-rose-500/60 shadow-lg backdrop-blur-md animate-bounce">
                <span className="text-xl sm:text-2xl font-black font-mono text-rose-400">
                  💥 {multiplier.toFixed(2)}x
                </span>
              </div>
              <span className="font-bold text-rose-400/90 text-[10px] block">نقطة الانفجار!</span>
            </div>
          )}
        </div>
      </div>

      {/* 3. HISTORY TICKER BAR (سجل نقطة الانفجار) */}
      <div className="bg-slate-900 border-b border-slate-800 p-2 flex items-center justify-between gap-2">
        <button
          onClick={() => setShowStatsModal(true)}
          className="px-2.5 py-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-xl text-[10px] font-black text-amber-300 flex items-center gap-1 shrink-0 cursor-pointer"
        >
          <BarChart3 className="w-3.5 h-3.5 text-amber-400" />
          <span>الجميع / الإحصائيات</span>
        </button>

        {/* Scrollable multiplier history badges */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {history.slice(0, 8).map((val, idx) => (
            <span
              key={idx}
              className={`px-2 py-0.5 rounded-lg text-[10px] font-mono font-black border shrink-0 ${
                val < 2.0
                  ? 'bg-cyan-950/80 text-cyan-300 border-cyan-500/30'
                  : val < 10.0
                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/30'
                  : 'bg-amber-950/80 text-amber-300 border-amber-500/40'
              }`}
            >
              {val.toFixed(2)}x
            </span>
          ))}
        </div>
      </div>

      {/* 4. BETTING CONTROLS & FUEL CHIP SELECTION */}
      <div className="p-3 bg-slate-950 space-y-3">
        {/* Fuel / Coin Bet Chips Selector (Initially neutral white, turns colorful when selected) */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-[11px] text-slate-300 font-bold">
            <span>اختر كمية الوقود (الرهان):</span>
            <span className="text-amber-400 font-mono font-black">{selectedBetChip} 🪙</span>
          </div>

          <div className="grid grid-cols-4 gap-2">
            {[
              { amt: 100, activeStyle: 'bg-emerald-500 text-slate-950 border-emerald-300 shadow-emerald-500/40' },
              { amt: 500, activeStyle: 'bg-lime-400 text-slate-950 border-lime-200 shadow-lime-400/40' },
              { amt: 1000, activeStyle: 'bg-cyan-400 text-slate-950 border-cyan-200 shadow-cyan-400/40' },
              { amt: 10000, activeStyle: 'bg-rose-500 text-white border-rose-300 shadow-rose-500/40' },
            ].map(({ amt, activeStyle }) => {
              const isSelected = selectedBetChip === amt;
              return (
                <button
                  key={amt}
                  type="button"
                  disabled={phase === 'FLYING' || isBetPlaced}
                  onClick={() => setSelectedBetChip(amt)}
                  className={`p-2.5 rounded-2xl border-2 text-center transition-all cursor-pointer font-black ${
                    isSelected
                      ? `${activeStyle} shadow-lg scale-105 border-2`
                      : 'bg-white/10 text-white border-white/20 hover:bg-white/20'
                  }`}
                >
                  <div className="text-xs font-mono font-black">
                    {amt >= 1000 ? `${amt / 1000}K` : amt}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Auto Cashout Toggle */}
        <div className="bg-slate-900 p-2.5 rounded-2xl border border-slate-800 flex items-center justify-between text-xs">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={autoCashoutEnabled}
              onChange={(e) => setAutoCashoutEnabled(e.target.checked)}
              className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
            />
            <span className="font-bold text-slate-200">الهروب تلقائياً</span>
          </label>

          <div className="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-400">عند:</span>
            <input
              type="number"
              step="0.05"
              min="1.05"
              max="100"
              value={autoCashoutTarget}
              onChange={(e) => setAutoCashoutTarget(parseFloat(e.target.value) || 1.1)}
              className="w-14 bg-transparent text-center font-mono font-black text-amber-300 text-xs focus:outline-none"
            />
            <span className="font-mono text-amber-400 font-black text-xs">x</span>
          </div>
        </div>

        {/* Dynamic Main Action Button */}
        <div>
          {phase === 'COOLDOWN' && (
            <button
              type="button"
              onClick={handlePlaceBet}
              disabled={isBetPlaced}
              className={`w-full py-3.5 rounded-2xl font-black text-sm shadow-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
                isBetPlaced
                  ? 'bg-slate-800 border border-emerald-500/40 text-emerald-400'
                  : 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 hover:brightness-110 active:scale-98'
              }`}
            >
              {isBetPlaced ? (
                <>
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <span>تم تأكيد الرهان بـ ({selectedBetChip} 🪙) - انتظر الإطلاق</span>
                </>
              ) : (
                <>
                  <Flame className="w-5 h-5 text-slate-950" />
                  <span>تأكيد الرهان ({selectedBetChip} 🪙)</span>
                </>
              )}
            </button>
          )}

          {phase === 'FLYING' && (
            <div>
              {isBetPlaced && !hasCashedOut ? (
                <button
                  type="button"
                  onClick={triggerCashout}
                  className="w-full py-4 bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 text-slate-950 font-black text-base rounded-2xl shadow-2xl hover:brightness-110 active:scale-95 animate-pulse flex items-center justify-center gap-2 cursor-pointer border-2 border-white/50"
                >
                  <span>الهروب وسحب الأرباح 🏃‍♂️</span>
                  <span className="font-mono font-black text-lg">
                    ({Math.floor(selectedBetChip * multiplier).toLocaleString()} 🪙)
                  </span>
                </button>
              ) : hasCashedOut ? (
                <div className="bg-emerald-950/80 border border-emerald-500 p-3 rounded-2xl text-center space-y-1">
                  <span className="font-black text-emerald-300 text-xs block">
                    مبروك! تم الهروب عند {cashedOutMultiplier.toFixed(2)}x 🎉
                  </span>
                  <span className="font-mono font-black text-emerald-400 text-sm block">
                    الربح: +{wonCoins.toLocaleString()} 🪙
                  </span>
                </div>
              ) : (
                /* Hazard Striped Bar for non-bettors during Flight */
                <div className="bg-amber-950/80 border-2 border-amber-500/60 p-3.5 rounded-2xl text-center relative overflow-hidden shadow-lg">
                  <div className="absolute inset-0 opacity-10 bg-[repeating-linear-gradient(45deg,#000,#000_10px,#f59e0b_10px,#f59e0b_20px)]" />
                  <span className="font-black text-amber-300 text-xs relative z-10">
                    🚫 انتظر الجولة القادمة
                  </span>
                </div>
              )}
            </div>
          )}

          {phase === 'CRASHED' && (
            <div className="bg-rose-950/80 border-2 border-rose-500 p-3.5 rounded-2xl text-center shadow-lg">
              <span className="font-black text-rose-300 text-xs block">
                انفجر الصاروخ! جاري التجهيز للجولة القادمة... 🚀
              </span>
            </div>
          )}
        </div>
      </div>

      {/* FULL STATS & CRASH POINT HISTORY MODAL */}
      {showStatsModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 font-sans dir-rtl">
          <div className="w-full max-w-md bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-4 space-y-4 text-right max-h-[90vh] overflow-y-auto animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="font-black text-sm text-amber-300 flex items-center gap-1.5">
                <BarChart3 className="w-4 h-4 text-amber-400" />
                <span>نقطة الانفجار والإحصائيات</span>
              </h3>
              <button
                onClick={() => setShowStatsModal(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Past 50 Rounds Grid */}
            <div className="space-y-2">
              <span className="font-black text-xs text-slate-300 block">نقطة الانفجار (آخر 50 جولة):</span>
              <div className="grid grid-cols-5 gap-1.5 max-h-48 overflow-y-auto p-2 bg-slate-950 rounded-2xl border border-slate-800 text-[10px] font-mono font-bold">
                {history.map((val, i) => (
                  <div
                    key={i}
                    className={`p-1.5 rounded-xl text-center border ${
                      val < 2.0
                        ? 'bg-cyan-950/80 text-cyan-300 border-cyan-500/30'
                        : val < 10.0
                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/30'
                        : 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                    }`}
                  >
                    <span>{val.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Breakdown Table (إحصائيات نقطة الانفجار) */}
            <div className="space-y-2">
              <span className="font-black text-xs text-slate-300 block">إحصائيات نقطة الانفجار:</span>
              <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden text-[11px]">
                <table className="w-full text-center">
                  <thead className="bg-slate-900 text-slate-400 text-[10px]">
                    <tr>
                      <th className="p-2 text-right">ارتفاع</th>
                      <th className="p-2">آخر 10</th>
                      <th className="p-2">آخر 20</th>
                      <th className="p-2">آخر 30</th>
                      <th className="p-2">آخر 50</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 font-mono text-slate-200">
                    <tr>
                      <td className="p-2 text-right font-black text-amber-300">&gt; 1x</td>
                      <td className="p-2">10</td>
                      <td className="p-2">20</td>
                      <td className="p-2">29</td>
                      <td className="p-2">48</td>
                    </tr>
                    <tr>
                      <td className="p-2 text-right font-black text-amber-300">&gt; 2x</td>
                      <td className="p-2">4</td>
                      <td className="p-2">8</td>
                      <td className="p-2">13</td>
                      <td className="p-2">22</td>
                    </tr>
                    <tr>
                      <td className="p-2 text-right font-black text-amber-300">&gt; 3x</td>
                      <td className="p-2">2</td>
                      <td className="p-2">5</td>
                      <td className="p-2">8</td>
                      <td className="p-2">14</td>
                    </tr>
                    <tr>
                      <td className="p-2 text-right font-black text-amber-300">&gt; 5x</td>
                      <td className="p-2">1</td>
                      <td className="p-2">2</td>
                      <td className="p-2">4</td>
                      <td className="p-2">7</td>
                    </tr>
                    <tr>
                      <td className="p-2 text-right font-black text-amber-300">&gt; 10x</td>
                      <td className="p-2">1</td>
                      <td className="p-2">2</td>
                      <td className="p-2">3</td>
                      <td className="p-2">5</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* GAME RULES MODAL */}
      {showRulesModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 font-sans dir-rtl">
          <div className="w-full max-w-sm bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-4 space-y-3 text-right">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="font-black text-sm text-amber-300">تعليمات لعبة الصاروخ 🚀</h3>
              <button onClick={() => setShowRulesModal(false)} className="text-slate-400 hover:text-white p-1 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-2 text-xs text-slate-300 leading-relaxed">
              <p>1. اختر قيمة الرهان خلال وقت التبريد (5 ثوانٍ) واضغط تأكيد.</p>
              <p>2. عند الانطلاق، يبدأ العداد في الارتفاع تلقائياً من 1.00x للأعلى.</p>
              <p>3. اضغط زر [الهروب وسحب الأرباح] قبل أن ينفجر الصاروخ لتربح رصيدك مضروباً في مضاعف الارتفاع.</p>
              <p>4. يمكنك تفعيل ميزة "الهروب تلقائياً" لتحديد رقم هرب ثابت وتجنب بطء الإنترنت.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
