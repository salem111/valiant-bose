import React, { useState, useEffect, useRef } from 'react';
import { UserProfile } from '../../types';
import {
  RotateCw,
  Zap,
  Volume2,
  VolumeX,
  Plus,
  HelpCircle,
  X,
  Trophy,
  Settings,
  Sparkles,
  Info,
  ChevronRight,
  ArrowLeft,
} from 'lucide-react';

interface WheelGameProps {
  user: UserProfile;
  onUpdateCoins: (delta: number) => void;
  onBack?: () => void;
}

// Wheel sectors definition
const WHEEL_SECTORS = [
  { id: 1, label: '1K', value: 1000, color: '#0284c7' }, // Cyan
  { id: 2, label: '750', value: 750, color: '#16a34a' }, // Green
  { id: 3, label: '50K', value: 50000, color: '#9333ea' }, // Purple
  { id: 4, label: '5K', value: 5000, color: '#ca8a04' }, // Yellow/Gold
  { id: 5, label: '150', value: 150, color: '#ea580c' }, // Orange
  { id: 6, label: '2.5K', value: 2500, color: '#2563eb' }, // Blue
  { id: 7, label: '10K', value: 10000, color: '#dc2626' }, // Red
  { id: 8, label: '500', value: 500, color: '#059669' }, // Emerald
];

// Slot Symbol Definitions
type SymbolType = 'WILD' | 'RUBY' | 'SAPPHIRE' | 'EMERALD';
type SpecialSymbolType = '1x' | '2x' | '5x' | '10x' | 'WHEEL';

interface SymbolDef {
  id: SymbolType;
  name: string;
  payout: number;
}

const SYMBOLS: SymbolDef[] = [
  { id: 'WILD', name: 'WILD', payout: 25 },
  { id: 'RUBY', name: 'جواهر حمراء', payout: 15 },
  { id: 'SAPPHIRE', name: 'جواهر زرقاء', payout: 10 },
  { id: 'EMERALD', name: 'جواهر خضراء', payout: 5 },
];

const SPECIAL_SYMBOLS: SpecialSymbolType[] = ['1x', '2x', '5x', '10x', 'WHEEL'];

export const WheelGame: React.FC<WheelGameProps> = ({ user, onUpdateCoins, onBack }) => {
  // Game States
  const [bet, setBet] = useState<number>(50);
  const [winAmount, setWinAmount] = useState<number>(0);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [isWheelSpinning, setIsWheelSpinning] = useState<boolean>(false);
  const [isAutoSpin, setIsAutoSpin] = useState<boolean>(false);
  const [isTurbo, setIsTurbo] = useState<boolean>(false);
  const [soundMuted, setSoundMuted] = useState<boolean>(false);

  // Wheel rotation angle in degrees
  const [wheelRotation, setWheelRotation] = useState<number>(0);
  const [showPaytableModal, setShowPaytableModal] = useState<boolean>(false);
  const [showWinBanner, setShowWinBanner] = useState<boolean>(false);

  // Reel states (3 rows x 3 symbol reels + 1 special reel)
  const [reels, setReels] = useState<SymbolType[][]>([
    ['WILD', 'WILD', 'WILD'],
    ['RUBY', 'RUBY', 'RUBY'],
    ['SAPPHIRE', 'SAPPHIRE', 'SAPPHIRE'],
  ]);
  const [specialReel, setSpecialReel] = useState<SpecialSymbolType[]>(['5x', '10x', 'WHEEL']);

  // Ping timer simulation
  const [ping, setPing] = useState<number>(187);

  useEffect(() => {
    const pingInt = setInterval(() => {
      setPing(Math.floor(175 + Math.random() * 30));
    }, 4000);
    return () => clearInterval(pingInt);
  }, []);

  // Web Audio Sound FX Synthesizer
  const playSound = (type: 'spin' | 'wheel_spin' | 'win' | 'jackpot' | 'click') => {
    if (soundMuted) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'spin') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(200, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.3);
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.3);
      } else if (type === 'wheel_spin') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(400, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(900, ctx.currentTime + 0.5);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.5);
      } else if (type === 'win') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
        osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.1); // E5
        osc.frequency.setValueAtTime(783.99, ctx.currentTime + 0.2); // G5
        gain.gain.setValueAtTime(0.25, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.35);
      } else if (type === 'jackpot') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.8);
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.8);
      } else if (type === 'click') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, ctx.currentTime);
        gain.gain.setValueAtTime(0.08, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.05);
      }
    } catch (e) {
      // Audio fallback
    }
  };

  // Main Spin Engine
  const handleSpin = () => {
    if (isSpinning || isWheelSpinning) return;
    if (user.coins < bet) {
      alert('رصيدك غير كافٍ لهذا الرهان! يرجى الشحن أولاً.');
      setIsAutoSpin(false);
      return;
    }

    // Deduct bet coins
    onUpdateCoins(-bet);
    setIsSpinning(true);
    setShowWinBanner(false);
    setWinAmount(0);
    playSound('spin');

    const duration = isTurbo ? 600 : 1200;

    // Simulate Reel Spin Animation
    const interval = setInterval(() => {
      setReels([
        Array.from({ length: 3 }, () => SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)].id),
        Array.from({ length: 3 }, () => SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)].id),
        Array.from({ length: 3 }, () => SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)].id),
      ]);
      setSpecialReel([
        SPECIAL_SYMBOLS[Math.floor(Math.random() * SPECIAL_SYMBOLS.length)],
        SPECIAL_SYMBOLS[Math.floor(Math.random() * SPECIAL_SYMBOLS.length)],
        SPECIAL_SYMBOLS[Math.floor(Math.random() * SPECIAL_SYMBOLS.length)],
      ]);
    }, 80);

    setTimeout(() => {
      clearInterval(interval);

      // Final Reels Outcomes
      const finalReels: SymbolType[][] = [
        [
          Math.random() < 0.3 ? 'WILD' : SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)].id,
          Math.random() < 0.2 ? 'WILD' : 'RUBY',
          'WILD',
        ],
        [
          Math.random() < 0.4 ? 'RUBY' : 'SAPPHIRE',
          Math.random() < 0.4 ? 'RUBY' : 'SAPPHIRE',
          Math.random() < 0.4 ? 'RUBY' : 'SAPPHIRE',
        ],
        [
          Math.random() < 0.4 ? 'SAPPHIRE' : 'EMERALD',
          Math.random() < 0.4 ? 'SAPPHIRE' : 'EMERALD',
          Math.random() < 0.4 ? 'SAPPHIRE' : 'EMERALD',
        ],
      ];

      // Special 4th Reel Outcome
      const specialLanding: SpecialSymbolType =
        Math.random() < 0.28
          ? 'WHEEL'
          : SPECIAL_SYMBOLS[Math.floor(Math.random() * (SPECIAL_SYMBOLS.length - 1))];

      const finalSpecialReel: SpecialSymbolType[] = ['5x', specialLanding, '10x'];

      setReels(finalReels);
      setSpecialReel(finalSpecialReel);
      setIsSpinning(false);

      // Evaluate Line Wins
      let lineBaseWin = 0;
      // Check middle row match across 3 reels
      const r1 = finalReels[0][1];
      const r2 = finalReels[1][1];
      const r3 = finalReels[2][1];

      if (r1 === r2 && r2 === r3) {
        const sym = SYMBOLS.find((s) => s.id === r1);
        lineBaseWin = bet * (sym ? sym.payout : 5);
      } else if (r1 === 'WILD' || r2 === 'WILD' || r3 === 'WILD') {
        lineBaseWin = bet * 3;
      } else {
        lineBaseWin = bet * 1.5; // Frequent hit
      }

      // Check if SPECIAL WHEEL TRIGGERED
      if (specialLanding === 'WHEEL') {
        triggerSpecialWheelSpin(lineBaseWin);
      } else {
        // Multiplier applied
        let multVal = 1;
        if (specialLanding === '2x') multVal = 2;
        if (specialLanding === '5x') multVal = 5;
        if (specialLanding === '10x') multVal = 10;

        const totalWin = Math.floor(lineBaseWin * multVal);
        setWinAmount(totalWin);
        if (totalWin > 0) {
          onUpdateCoins(totalWin);
          setShowWinBanner(true);
          playSound('win');
        }
      }
    }, duration);
  };

  // Special Wheel Spin Trigger
  const triggerSpecialWheelSpin = (baseWin: number) => {
    setIsWheelSpinning(true);
    playSound('wheel_spin');

    // Random sector pick
    const chosenIndex = Math.floor(Math.random() * WHEEL_SECTORS.length);
    const chosenSector = WHEEL_SECTORS[chosenIndex];

    // Sector angle calculation (360 / 8 = 45 deg per sector)
    const sectorAngle = 360 / WHEEL_SECTORS.length;
    const targetSectorAngle = 360 - chosenIndex * sectorAngle;
    const fullRotations = 360 * 5; // 5 full turns
    const finalAngle = wheelRotation + fullRotations + targetSectorAngle;

    setWheelRotation(finalAngle);

    setTimeout(() => {
      setIsWheelSpinning(false);
      const wheelPrize = chosenSector.value + baseWin;
      const grandTotal = Math.floor(wheelPrize * (bet / 50));
      setWinAmount(grandTotal);
      onUpdateCoins(grandTotal);
      setShowWinBanner(true);
      playSound('jackpot');
    }, 3200);
  };

  // Auto Spin effect
  useEffect(() => {
    let timer: any;
    if (isAutoSpin && !isSpinning && !isWheelSpinning) {
      timer = setTimeout(() => {
        handleSpin();
      }, 1000);
    }
    return () => clearTimeout(timer);
  }, [isAutoSpin, isSpinning, isWheelSpinning]);

  return (
    <div className="w-full max-w-md mx-auto bg-[#100b1e] text-amber-100 rounded-3xl border-2 border-amber-600/60 shadow-2xl overflow-hidden font-sans select-none flex flex-col dir-rtl relative">
      {/* 1. TOP HEADER BAR */}
      <div className="bg-gradient-to-r from-amber-950 via-slate-950 to-amber-950 border-b border-amber-600/40 px-3 py-2 flex items-center justify-between text-xs z-20">
        <div className="flex items-center gap-2">
          {onBack && (
            <button
              onClick={onBack}
              className="p-1 rounded-xl bg-amber-900/40 border border-amber-500/40 text-amber-300 hover:text-white cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <span className="font-black text-amber-300 text-sm flex items-center gap-1 drop-shadow">
            💎 جواهر الحظ (FORTUNE GEMS)
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Trophy event badge */}
          <div className="bg-amber-950/80 border border-amber-500/50 px-2 py-0.5 rounded-full text-[10px] text-amber-300 font-mono font-black flex items-center gap-1 shadow">
            <Trophy className="w-3 h-3 text-yellow-400" />
            <span>20:49</span>
          </div>

          {/* Sound Mute */}
          <button
            onClick={() => {
              setSoundMuted(!soundMuted);
              playSound('click');
            }}
            className="p-1 rounded-full bg-slate-900 border border-amber-500/30 text-amber-300 hover:text-white cursor-pointer"
          >
            {soundMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>

          {/* Paytable / Info */}
          <button
            onClick={() => setShowPaytableModal(true)}
            className="p-1 rounded-full bg-slate-900 border border-amber-500/30 text-amber-300 hover:text-white cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 2. MAYAN TEMPLE & SPECIAL WHEEL SECTION */}
      <div className="relative bg-gradient-to-b from-amber-950 via-[#1c122c] to-[#120a1f] p-3 flex flex-col items-center justify-center border-b-2 border-amber-600/50 overflow-hidden min-h-[220px]">
        {/* Background Sunset Sky & Mayan Pyramid Graphic */}
        <div className="absolute inset-0 opacity-40 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-500 via-orange-950 to-transparent pointer-events-none" />

        {/* Golden Logo Header */}
        <div className="relative z-10 mb-1 text-center">
          <div className="inline-block px-4 py-0.5 rounded-full bg-gradient-to-r from-amber-600 via-yellow-400 to-amber-600 p-[1px] shadow-lg">
            <div className="bg-slate-950 px-3 py-0.5 rounded-full">
              <span className="font-black text-xs text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-400 tracking-wider">
                FORTUNE GEMS
              </span>
            </div>
          </div>
        </div>

        {/* Mayan Wheel Frame */}
        <div className="relative z-10 w-44 h-44 sm:w-48 sm:h-48 flex items-center justify-center my-1">
          {/* Outer Carved Golden Ring */}
          <div className="absolute inset-0 rounded-full border-4 border-amber-500 shadow-[0_0_25px_rgba(245,158,11,0.5)] bg-amber-950/80 flex items-center justify-center p-1">
            {/* Spinning Wheel */}
            <div
              className="w-full h-full rounded-full relative overflow-hidden transition-transform ease-out"
              style={{
                transform: `rotate(${wheelRotation}deg)`,
                transitionDuration: isWheelSpinning ? '3.2s' : '0s',
                background: 'conic-gradient(#0284c7 0deg 45deg, #16a34a 45deg 90deg, #9333ea 90deg 135deg, #ca8a04 135deg 180deg, #ea580c 180deg 225deg, #2563eb 225deg 270deg, #dc2626 270deg 315deg, #059669 315deg 360deg)',
              }}
            >
              {/* Wheel Sectors Labels */}
              {WHEEL_SECTORS.map((sec, idx) => {
                const angle = idx * 45 + 22.5;
                return (
                  <div
                    key={sec.id}
                    className="absolute inset-0 flex items-start justify-center pt-2 font-black text-[11px] text-white font-mono drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]"
                    style={{
                      transform: `rotate(${angle}deg)`,
                      transformOrigin: '50% 50%',
                    }}
                  >
                    <span>{sec.label}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Center Golden Aztec Emblem */}
          <div className="absolute w-12 h-12 rounded-full bg-gradient-to-tr from-yellow-600 via-amber-300 to-yellow-500 p-0.5 shadow-xl flex items-center justify-center z-20 border border-amber-200">
            <div className="w-full h-full rounded-full bg-amber-950 flex items-center justify-center border border-amber-600">
              <Sparkles className="w-5 h-5 text-yellow-300 animate-pulse" />
            </div>
          </div>

          {/* Pointer Stopper at Bottom Center */}
          <div className="absolute -bottom-2 z-30 flex flex-col items-center">
            <div className="w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-b-[18px] border-b-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.9)]" />
          </div>

          {/* EX ? Badge on Left */}
          <div className="absolute left-[-10px] top-1/2 -translate-y-1/2 bg-gradient-to-r from-amber-500 to-yellow-400 border border-amber-200 text-slate-950 font-black text-[9px] px-1.5 py-0.5 rounded-full shadow-lg z-30">
            EX ?
          </div>
        </div>
      </div>

      {/* 3. SLOT REELS & SPECIAL WHEEL REEL SECTION */}
      <div className="p-3 bg-gradient-to-b from-[#180e2b] via-[#120822] to-[#0c0418]">
        {/* Title Plaques Above Reels */}
        <div className="grid grid-cols-4 gap-1.5 mb-2 font-black text-[10px] text-center text-amber-300">
          <div className="col-span-3 bg-gradient-to-r from-amber-950 via-amber-900 to-amber-950 border border-amber-500/50 py-1 rounded-t-xl shadow text-amber-200 tracking-wider">
            FORTUNE GEMS
          </div>
          <div className="col-span-1 bg-gradient-to-r from-amber-800 to-yellow-600 border border-yellow-300/60 py-1 rounded-t-xl shadow text-slate-950 font-extrabold uppercase tracking-tighter">
            SPECIAL WHEEL
          </div>
        </div>

        {/* 4 REELS CONTAINER (Carved Mayan Stone Frames) */}
        <div className="grid grid-cols-4 gap-1.5 bg-[#080311] p-2 rounded-2xl border-2 border-amber-600/70 shadow-inner relative">
          {/* Reels 1, 2, 3 (Main Symbol Reels) */}
          {[0, 1, 2].map((reelIdx) => (
            <div
              key={reelIdx}
              className="bg-gradient-to-b from-slate-950 via-purple-950/40 to-slate-950 rounded-xl border border-amber-500/30 p-1 flex flex-col gap-1.5 items-center justify-around min-h-[160px] shadow-md"
            >
              {reels[reelIdx].map((sym, rowIdx) => (
                <div
                  key={rowIdx}
                  className={`w-full aspect-square rounded-xl flex flex-col items-center justify-center p-1 border shadow-md transition-transform ${
                    sym === 'WILD'
                      ? 'bg-gradient-to-br from-yellow-500 via-amber-600 to-yellow-700 border-yellow-300 text-slate-950'
                      : sym === 'RUBY'
                      ? 'bg-gradient-to-br from-rose-900 via-red-800 to-rose-950 border-rose-500/80 text-rose-300'
                      : 'bg-gradient-to-br from-blue-900 via-indigo-800 to-blue-950 border-blue-500/80 text-blue-300'
                  }`}
                >
                  {sym === 'WILD' && (
                    <div className="flex flex-col items-center">
                      <span className="text-xl sm:text-2xl drop-shadow">🗿</span>
                      <span className="text-[8px] font-black text-yellow-950 bg-amber-300 px-1 rounded -mt-0.5 uppercase">
                        WILD
                      </span>
                    </div>
                  )}

                  {sym === 'RUBY' && (
                    <div className="flex flex-col items-center">
                      <span className="text-xl sm:text-2xl drop-shadow-md">💎</span>
                    </div>
                  )}

                  {sym === 'SAPPHIRE' && (
                    <div className="flex flex-col items-center">
                      <span className="text-xl sm:text-2xl drop-shadow-md">🔹</span>
                    </div>
                  )}

                  {sym === 'EMERALD' && (
                    <div className="flex flex-col items-center">
                      <span className="text-xl sm:text-2xl drop-shadow-md">❇️</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ))}

          {/* Reel 4: SPECIAL WHEEL MULTIPLIER REEL */}
          <div className="bg-gradient-to-b from-amber-950/80 via-yellow-950/50 to-amber-950/80 rounded-xl border-2 border-yellow-500/70 p-1 flex flex-col gap-1.5 items-center justify-around min-h-[160px] shadow-lg">
            {specialReel.map((specSym, rowIdx) => (
              <div
                key={rowIdx}
                className={`w-full aspect-square rounded-xl flex flex-col items-center justify-center p-1 border-2 shadow-lg transition-transform ${
                  specSym === 'WHEEL'
                    ? 'bg-gradient-to-tr from-emerald-600 via-teal-500 to-emerald-400 border-emerald-200 text-white animate-pulse'
                    : 'bg-gradient-to-br from-amber-600 via-yellow-500 to-amber-700 border-yellow-200 text-slate-950'
                }`}
              >
                {specSym === 'WHEEL' ? (
                  <div className="flex flex-col items-center">
                    <span className="text-lg">🎡</span>
                    <span className="text-[7px] font-black uppercase text-emerald-950 bg-emerald-200 px-1 rounded">
                      WHEEL
                    </span>
                  </div>
                ) : (
                  <span className="text-sm sm:text-base font-black font-mono tracking-tight drop-shadow">
                    {specSym}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Win Banner Display */}
        <div className="mt-2 text-center h-8 flex items-center justify-center">
          {showWinBanner && (
            <div className="animate-bounce bg-gradient-to-r from-amber-500 via-yellow-300 to-amber-500 text-slate-950 font-black text-sm px-4 py-1 rounded-full border border-yellow-100 shadow-xl flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>فوز كبير! +{winAmount.toLocaleString()} 🪙</span>
            </div>
          )}
          {!showWinBanner && (
            <div className="text-amber-300/80 font-bold text-xs">
              الربح: <span className="font-mono text-white font-black">{winAmount}</span>
            </div>
          )}
        </div>
      </div>

      {/* 4. CONTROLS & BOTTOM HUD PANEL */}
      <div className="bg-gradient-to-b from-[#150b23] to-[#0a0314] p-3 border-t border-amber-600/40 space-y-3">
        {/* Bet Adjustment Pill & Spin Controls */}
        <div className="flex items-center justify-between gap-2">
          {/* Bet Capsule (-) [ 50 ] (+) */}
          <div className="bg-amber-950/80 border border-amber-500/50 rounded-2xl p-1 flex items-center gap-1 shadow">
            <button
              onClick={() => {
                setBet((b) => Math.max(10, b - 10));
                playSound('click');
              }}
              disabled={isSpinning || isWheelSpinning}
              className="w-7 h-7 rounded-xl bg-amber-900 border border-amber-500/40 text-amber-200 font-black text-sm flex items-center justify-center hover:bg-amber-800 disabled:opacity-50 cursor-pointer"
            >
              -
            </button>

            <div className="px-3 py-0.5 text-center">
              <span className="font-mono font-black text-amber-300 text-sm">{bet}</span>
            </div>

            <button
              onClick={() => {
                setBet((b) => b + 10);
                playSound('click');
              }}
              disabled={isSpinning || isWheelSpinning}
              className="w-7 h-7 rounded-xl bg-amber-900 border border-amber-500/40 text-amber-200 font-black text-sm flex items-center justify-center hover:bg-amber-800 disabled:opacity-50 cursor-pointer"
            >
              +
            </button>
          </div>

          {/* MAIN AZTEC SPIN BUTTON */}
          <button
            onClick={handleSpin}
            disabled={isSpinning || isWheelSpinning}
            className={`w-16 h-16 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-500 p-1 shadow-[0_0_20px_rgba(245,158,11,0.6)] hover:brightness-110 active:scale-95 disabled:opacity-60 cursor-pointer border-2 border-yellow-200 transition-transform ${
              isSpinning || isWheelSpinning ? 'animate-spin' : ''
            }`}
          >
            <div className="w-full h-full rounded-full bg-gradient-to-b from-yellow-400 to-amber-600 flex items-center justify-center border border-amber-800 shadow-inner">
              <RotateCw className="w-8 h-8 text-slate-950 font-black" />
            </div>
          </button>

          {/* Side Action Buttons: Auto, Turbo, Settings */}
          <div className="flex items-center gap-1.5">
            {/* Auto Spin Toggle */}
            <button
              onClick={() => {
                setIsAutoSpin(!isAutoSpin);
                playSound('click');
              }}
              className={`p-2 rounded-xl border text-xs font-black transition-all cursor-pointer ${
                isAutoSpin
                  ? 'bg-amber-500 border-amber-300 text-slate-950 shadow-lg'
                  : 'bg-slate-900 border-amber-500/30 text-amber-300 hover:bg-slate-800'
              }`}
            >
              <RotateCw className="w-4 h-4" />
            </button>

            {/* Turbo Toggle ⚡ */}
            <button
              onClick={() => {
                setIsTurbo(!isTurbo);
                playSound('click');
              }}
              className={`p-2 rounded-xl border text-xs font-black transition-all cursor-pointer ${
                isTurbo
                  ? 'bg-amber-500 border-amber-300 text-slate-950 shadow-lg'
                  : 'bg-slate-900 border-amber-500/30 text-amber-300 hover:bg-slate-800'
              }`}
            >
              <Zap className="w-4 h-4" />
            </button>

            {/* Settings */}
            <button
              onClick={() => setShowPaytableModal(true)}
              className="p-2 rounded-xl bg-slate-900 border border-amber-500/30 text-amber-300 hover:bg-slate-800 cursor-pointer"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Bottom Status Bar: Balance + Ping */}
        <div className="bg-slate-950/80 px-3 py-1.5 rounded-2xl border border-amber-500/30 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-1.5">
            <span className="text-amber-400 font-sans font-bold">الرصيد:</span>
            <div className="bg-amber-950/90 border border-amber-500/50 px-2 py-0.5 rounded-full flex items-center gap-1 font-black text-amber-300">
              <span>{user.coins.toLocaleString()}</span>
              <span className="text-xs">🪙</span>
              <button
                type="button"
                className="w-3.5 h-3.5 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center font-black text-[9px] cursor-pointer"
              >
                +
              </button>
            </div>
          </div>

          <div className="flex items-center gap-1 text-[10px] text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>{ping}ms</span>
          </div>
        </div>
      </div>

      {/* PAYTABLE / RULES MODAL */}
      {showPaytableModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 font-sans dir-rtl">
          <div className="w-full max-w-sm bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-4 space-y-3 text-right text-white">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="font-black text-sm text-amber-300">جدول الأرباح (FORTUNE GEMS) 💎</h3>
              <button
                onClick={() => setShowPaytableModal(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 text-xs text-slate-300">
              <p>• رمز 🗿 **WILD** يحل محل جميع الرموز ويمنح مضاعف x25.</p>
              <p>• الجوهرية الحمراء 💎 تمنح مضاعف x15.</p>
              <p>• الجوهرة الزرقاء 🔹 تمنح مضاعف x10.</p>
              <p>• البكرة الرابعة الخاصة تمنح مضاعفات (2x, 5x, 10x) أو تدور عجلة الحظ الكبرى 🎡 عند ظهور رمز WHEEL.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
