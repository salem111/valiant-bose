import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Crown, Bell, Shield, Wallet, Sparkles, CheckCircle2, ChevronDown, RefreshCw } from 'lucide-react';

interface HeaderProps {
  user: UserProfile;
  onOpenCoinStore: () => void;
  onOpenAdminPanel: () => void;
  onOpenVipModal: () => void;
  onOpenProfile: () => void;
  onOpenWithdrawalModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  onOpenCoinStore,
  onOpenAdminPanel,
  onOpenVipModal,
  onOpenProfile,
  onOpenWithdrawalModal,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState([
    { id: 1, text: '🎉 تم شحن 1,000 عملة بنجاح عبر Google Play', time: 'منذ 5 دقائق', unread: true },
    { id: 2, text: '👑 تم قبول طلب الترقية إلى رتبة VIP 5', time: 'منذ ساعة', unread: true },
    { id: 3, text: '🎮 انطلقت جولة لعبة الطرنيب في الغرفة العامة', time: 'منذ ساعتين', unread: false },
  ]);

  const markAllRead = () => {
    setNotifications(notifications.map(n => ({ ...n, unread: false })));
  };

  const unreadCount = notifications.filter(n => n.unread).length;

  return (
    <header id="saleem-main-header" className="sticky top-0 z-30 bg-slate-950/95 backdrop-blur-md border-b border-amber-500/30 px-3 py-2.5 text-white shadow-xl">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        {/* User Profile Digital Data Bar (شريط معلومات المستخدم الرقمي) */}
        <div className="flex items-center gap-3 bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 px-3 py-1.5 rounded-2xl shadow-inner">
          <div className="relative cursor-pointer group" onClick={onOpenProfile}>
            <img
              src={user.avatar}
              alt={user.name}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-400 p-0.5 shadow-md group-hover:scale-105 transition-transform"
            />
            {/* Membership Badge tied to dynamic level_status */}
            <span className="absolute -bottom-1 -right-1 bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-[9px] px-1.5 py-0.2 rounded-full shadow border border-slate-950 whitespace-nowrap">
              {user.levelStatus || 'ليفل 1'}
            </span>
          </div>

          <div className="flex flex-col text-right">
            <div className="flex items-center gap-2">
              <span className="font-black text-xs text-white tracking-wide">{user.name}</span>
              <span className="text-[10px] text-amber-400 font-mono bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                ID: {user.id}
              </span>
            </div>

            {/* Room Name Text Data or Placeholder */}
            <div className="flex items-center gap-1 mt-0.5">
              <span className="text-[10px] text-slate-400">الغرفة:</span>
              <span className={`text-[10px] font-bold ${user.hasActiveRoom ? 'text-emerald-400' : 'text-slate-500'}`}>
                {user.hasActiveRoom && user.roomName ? user.roomName : 'لا توجد غرفة خاصة'}
              </span>
            </div>
          </div>
        </div>

        {/* Currency Balances & Admin Button Right side */}
        <div className="flex items-center gap-2">
          {/* Gold Coin Counter (Default 0, increases with recharge) */}
          <div
            onClick={onOpenCoinStore}
            className="flex items-center gap-1.5 bg-slate-900/90 hover:bg-slate-800 border border-amber-500/40 rounded-2xl px-2.5 py-1 text-xs cursor-pointer shadow transition-all hover:border-amber-400"
            title="شحن العملات الذهبية"
          >
            <span className="text-base leading-none">🪙</span>
            <div className="flex flex-col">
              <span className="font-black text-amber-300 leading-tight font-mono">
                {user.coins.toLocaleString()}
              </span>
              <span className="text-[8px] text-slate-400 leading-none">عملة ذهبية</span>
            </div>
            <span className="bg-amber-500 text-slate-950 rounded-full w-4 h-4 flex items-center justify-center font-black text-xs ml-0.5 shadow">
              +
            </span>
          </div>

          {/* Gems Counter (Opens Cash Withdrawal & Diamond Exchange Modal) */}
          <div
            onClick={onOpenWithdrawalModal || onOpenCoinStore}
            className="flex items-center gap-1.5 bg-slate-900/90 hover:bg-slate-800 border border-cyan-500/40 rounded-2xl px-2.5 py-1 text-xs cursor-pointer shadow transition-all hover:border-cyan-400"
            title="سحب الأرباح والألماس كاش"
          >
            <span className="text-base leading-none">💎</span>
            <div className="flex flex-col">
              <span className="font-black text-cyan-300 leading-tight font-mono">
                {user.diamonds.toLocaleString()}
              </span>
              <span className="text-[8px] text-slate-400 leading-none">جواهر</span>
            </div>
          </div>

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-full bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition-colors"
              title="الإشعارات"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white font-bold text-[9px] w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            {showNotifications && (
              <div className="absolute left-0 mt-2 w-72 bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl p-3 z-50 text-right">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
                  <span className="font-bold text-sm text-amber-300">الإشعارات والتنبيهات</span>
                  {unreadCount > 0 && (
                    <button
                      onClick={markAllRead}
                      className="text-[11px] text-slate-400 hover:text-amber-400 flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3 h-3" />
                      تحديد الكل ككمقروء
                    </button>
                  )}
                </div>
                <div className="space-y-2 max-h-60 overflow-y-auto pr-1 text-xs">
                  {notifications.map(n => (
                    <div
                      key={n.id}
                      className={`p-2 rounded-xl transition-colors ${
                        n.unread ? 'bg-amber-500/10 border-r-2 border-amber-500 text-slate-200' : 'bg-slate-800/50 text-slate-400'
                      }`}
                    >
                      <p className="font-medium text-[11px] leading-snug">{n.text}</p>
                      <span className="text-[9px] text-slate-500 mt-1 block">{n.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Admin Panel Link */}
          <button
            onClick={onOpenAdminPanel}
            className="flex items-center gap-1 bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white text-xs font-bold px-2.5 py-1.5 rounded-full shadow-md transition-all border border-red-400/30"
            title="لوحة تحكم الإدارة"
          >
            <Shield className="w-3.5 h-3.5" />
            <span className="hidden md:inline">الإدارة</span>
          </button>
        </div>
      </div>
    </header>
  );
};
