import React from 'react';
import { TOP_LEADERBOARD_USERS } from '../data/mockData';
import { Trophy, Crown, X, Flame } from 'lucide-react';

interface LeaderboardModalProps {
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-amber-500/40 rounded-3xl p-5 shadow-2xl space-y-4 text-right animate-scaleUp">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Trophy className="w-6 h-6 text-amber-400" />
            <div>
              <h2 className="font-black text-base text-amber-300">ترتيب الداعمين والأساطير 🏆</h2>
              <p className="text-[11px] text-slate-400">قائمة كبار داعمي الغرف الصوتية في منصة SALEEM</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-2">
          {TOP_LEADERBOARD_USERS.map((u) => (
            <div
              key={u.id}
              className={`p-3 rounded-2xl border flex items-center justify-between ${
                u.rank === 1
                  ? 'bg-amber-500/20 border-amber-400 text-white'
                  : 'bg-slate-950 border-slate-800 text-slate-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="font-black text-sm font-mono w-6 text-center text-amber-300">
                  #{u.rank}
                </span>
                <img src={u.avatar} alt={u.name} className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-400" />
                <div>
                  <h4 className="font-bold text-xs text-white">{u.name}</h4>
                  <span className="text-[10px] text-amber-400 font-bold">{u.badge}</span>
                </div>
              </div>

              <div className="text-left font-mono">
                <span className="font-black text-xs text-emerald-400 block">
                  {u.scoreCoins.toLocaleString()} 🪙
                </span>
                <span className="text-[9px] text-slate-400">نقاط الدعم</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
