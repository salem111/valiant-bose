import React, { useState } from 'react';
import { Crown, Heart, Globe, ChevronDown, Check, Phone, UserCheck } from 'lucide-react';
import { normalizeProvider } from '../lib/firebase';

interface LoginScreenProps {
  onLoginSuccess: (provider: string) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const [selectedLanguage, setSelectedLanguage] = useState('العربية');
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState<string | null>(null);

  const handleLogin = (provider: string) => {
    setIsLoggingIn(provider);
    const normalized = normalizeProvider(provider);
    setTimeout(() => {
      setIsLoggingIn(null);
      onLoginSuccess(normalized.original || provider);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-between bg-slate-950 text-white overflow-y-auto font-sans dir-rtl select-none">
      {/* Background Gradients & Ambient Glow */}
      <div className="absolute inset-0 bg-gradient-to-b from-purple-950/80 via-slate-950 to-purple-900/90 pointer-events-none" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[360px] h-[360px] bg-purple-600/20 rounded-full blur-[110px] pointer-events-none" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[240px] h-[240px] bg-amber-500/15 rounded-full blur-[90px] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(#a855f7_1px,transparent_1px)] [background-size:24px_24px] opacity-15 pointer-events-none" />

      {/* Top Bar: Status Bar & Language Switcher */}
      <div className="relative z-20 w-full max-w-md mx-auto px-6 pt-3 flex items-center justify-between text-xs text-slate-300">
        <span className="font-mono text-slate-400">9:41</span>

        {/* Language Dropdown Selector */}
        <div className="relative">
          <button
            onClick={() => setShowLangMenu(!showLangMenu)}
            className="flex items-center gap-1.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 rounded-full px-3 py-1 text-xs text-slate-200 transition-all cursor-pointer shadow-sm"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span>{selectedLanguage}</span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {showLangMenu && (
            <div className="absolute top-full left-0 mt-1.5 w-32 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-1 z-30">
              {['العربية', 'English', 'Français', 'Türkçe'].map((lang) => (
                <button
                  key={lang}
                  onClick={() => {
                    setSelectedLanguage(lang);
                    setShowLangMenu(false);
                  }}
                  className="w-full text-right px-3 py-1.5 text-xs text-slate-300 hover:bg-purple-900/40 hover:text-amber-300 flex items-center justify-between"
                >
                  <span>{lang}</span>
                  {selectedLanguage === lang && <Check className="w-3 h-3 text-amber-400" />}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Center Branding Content */}
      <div className="relative z-10 w-full max-w-md mx-auto px-6 my-auto flex flex-col items-center text-center py-6">
        {/* Emblem with Royal Crown */}
        <div className="relative mb-4 group">
          <div className="absolute -inset-3 rounded-full bg-gradient-to-tr from-amber-500/30 via-purple-500/30 to-pink-500/30 blur-lg opacity-80" />

          <div className="relative w-36 h-36 rounded-full border-2 border-amber-400/60 bg-gradient-to-b from-slate-900/90 to-purple-950/90 shadow-[0_0_40px_rgba(217,119,6,0.3)] flex flex-col items-center justify-center p-2 backdrop-blur-md">
            {/* Top Crown */}
            <div className="absolute -top-6 flex items-center justify-center filter drop-shadow-[0_4px_8px_rgba(245,158,11,0.6)]">
              <Crown className="w-14 h-14 text-amber-300 fill-amber-400/30 stroke-[1.5]" />
            </div>

            {/* Inner Ring with Gold 'S' */}
            <div className="w-28 h-28 rounded-full border border-amber-400/40 p-2 flex items-center justify-center bg-gradient-to-br from-amber-500/10 via-purple-900/40 to-slate-950 shadow-inner">
              <span className="text-5xl font-serif font-black tracking-widest bg-gradient-to-b from-amber-200 via-amber-400 to-yellow-600 bg-clip-text text-transparent drop-shadow-[0_4px_10px_rgba(245,158,11,0.5)]">
                S
              </span>
            </div>
          </div>
        </div>

        {/* Brand Name */}
        <h1 className="text-3xl font-serif font-black tracking-[0.25em] bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-500 bg-clip-text text-transparent drop-shadow-[0_4px_12px_rgba(245,158,11,0.4)] mb-2">
          SALEEM
        </h1>

        {/* Tagline with Heart Ornament */}
        <div className="flex items-center gap-2 my-1.5 w-full max-w-[200px]">
          <div className="h-[1px] flex-1 bg-gradient-to-r from-transparent via-amber-400/60 to-purple-400/60" />
          <Heart className="w-3.5 h-3.5 text-pink-400 fill-pink-400" />
          <div className="h-[1px] flex-1 bg-gradient-to-l from-transparent via-amber-400/60 to-purple-400/60" />
        </div>
        <p className="text-xs text-slate-300 tracking-wide font-medium">
          دردشة صوتية ... تواصل بلا حدود
        </p>

        {/* Login Title Header */}
        <h2 className="text-lg font-bold text-slate-100 mt-6 mb-4">
          تسجيل الدخول
        </h2>

        {/* Requested Login Methods: Google & Facebook ONLY */}
        <div className="w-full space-y-3">
          {/* Google Login Button */}
          <button
            onClick={() => handleLogin('Google')}
            disabled={isLoggingIn !== null}
            className="w-full py-3 px-4 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 text-slate-200 font-bold text-xs shadow-md hover:shadow-lg transition-all flex items-center justify-between group cursor-pointer disabled:opacity-60"
          >
            <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center p-1 border border-white/10 group-hover:scale-105 transition-transform">
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
            </div>
            <span className="flex-1 text-center font-sans tracking-wide">
              {isLoggingIn === 'Google' ? 'جاري الاتصال بـ Google...' : 'Google'}
            </span>
            <div className="w-7" />
          </button>

          {/* Facebook Login Button */}
          <button
            onClick={() => handleLogin('Facebook')}
            disabled={isLoggingIn !== null}
            className="w-full py-3 px-4 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-blue-500/50 text-slate-200 font-bold text-xs shadow-md hover:shadow-lg transition-all flex items-center justify-between group cursor-pointer disabled:opacity-60"
          >
            <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center p-1 shadow-sm group-hover:scale-105 transition-transform">
              <svg className="w-4 h-4 fill-white" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
            </div>
            <span className="flex-1 text-center font-sans tracking-wide">
              {isLoggingIn === 'Facebook' ? 'جاري الاتصال بـ Facebook...' : 'Facebook'}
            </span>
            <div className="w-7" />
          </button>
        </div>
      </div>

      {/* Footer Terms & Account Links */}
      <div className="relative z-10 w-full max-w-md mx-auto px-6 pb-6 text-center space-y-2">
        <p className="text-[11px] text-slate-400">
          بالتسجيل، أنت توافق على{' '}
          <button className="text-amber-400 hover:underline">الشروط والأحكام</button> و{' '}
          <button className="text-amber-400 hover:underline">سياسة الخصوصية</button>
        </p>

        <p className="text-xs text-slate-300 pt-1">
          ليس لديك حساب؟{' '}
          <button
            onClick={() => handleLogin('Google')}
            className="text-amber-300 font-bold hover:underline cursor-pointer"
          >
            إنشاء حساب
          </button>
        </p>
      </div>
    </div>
  );
};
