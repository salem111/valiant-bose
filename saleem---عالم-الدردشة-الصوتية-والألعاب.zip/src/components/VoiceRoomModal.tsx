import React, { useState, useEffect } from 'react';
import { VoiceRoom, UserProfile, GiftItem, MicSeat, RoomMessage } from '../types';
import { SeatGridSettingsModal, SeatLayoutSelection } from './SeatGridSettingsModal';
import { MOCK_GIFTS } from '../data/mockData';
import { RoomInfoModal } from './RoomInfoModal';
import { GiftSelectorModal } from './GiftSelectorModal';
import {
  ChevronLeft,
  Power,
  Users,
  Flame,
  Crown,
  Plus,
  Gift,
  Gamepad2,
  Grid,
  LayoutGrid,
  Music,
  MessageSquare,
  Hand,
  Volume2,
  Mic,
  MicOff,
  Send,
  Smile,
  X,
  Lock,
  Unlock,
  UserX,
  UserMinus,
  UserPlus,
  Check,
  Heart,
  Sparkles,
  VolumeX,
  Share2,
  Megaphone,
  ZapOff,
  Maximize2,
  Calendar,
  Award,
  Copy,
  CheckCircle2,
  Shield,
  Video,
  VideoOff,
  Camera,
  RotateCcw,
  ShieldAlert,
  Inbox
} from 'lucide-react';

interface VoiceRoomModalProps {
  room: VoiceRoom;
  user: UserProfile;
  onClose: () => void;
  onOpenGames: () => void;
  onSendGift: (gift: GiftItem, recipientName: string) => void;
  onUpdateRoomAnnouncement?: (roomId: string, newAnnouncement: string) => void;
  onOpenCoinStore?: () => void;
  onUpdateUser?: (updated: Partial<UserProfile>) => void;
}

export const VoiceRoomModal: React.FC<VoiceRoomModalProps> = ({
  room,
  user,
  onClose,
  onOpenGames,
  onSendGift,
  onUpdateRoomAnnouncement,
  onOpenCoinStore,
  onUpdateUser,
}) => {
  const [currentUser, setCurrentUser] = useState<UserProfile>(user);
  const [hostLiveDiamonds, setHostLiveDiamonds] = useState<number>(25400);
  const [activeFloatingGift, setActiveFloatingGift] = useState<{
    gift: GiftItem;
    sender: string;
    amount: number;
  } | null>(null);

  useEffect(() => {
    setCurrentUser(user);
  }, [user]);

  const [currentRoom, setCurrentRoom] = useState<VoiceRoom>(() => {
    // Ensure room has 20 seats
    const existingSeats = room.seats || [];
    const seats20: MicSeat[] = Array.from({ length: 20 }, (_, index) => {
      const seatNum = index + 1;
      const existing = existingSeats.find((s) => s.seatId === seatNum);
      if (existing) {
        return {
          ...existing,
          points: existing.points ?? 0,
        };
      }
      return {
        seatId: seatNum,
        isLocked: false,
        isMuted: false,
        points: 0,
      };
    });

    return {
      ...room,
      seats: seats20,
    };
  });

  const [userOnSeat, setUserOnSeat] = useState<number | null>(() => {
    const userSeat = currentRoom.seats.find((s) => s.speakerUser?.id === user.id);
    return userSeat ? userSeat.seatId : null;
  });

  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isRoomAudioMuted, setIsRoomAudioMuted] = useState(false);
  const [isHandRaised, setIsHandRaised] = useState(false);
  const [chatMessage, setChatMessage] = useState('');
  const [showGiftSelector, setShowGiftSelector] = useState(false);
  const [selectedSeatForAction, setSelectedSeatForAction] = useState<MicSeat | null>(null);
  const [isFollowing, setIsFollowing] = useState(false);
  const [showChatBox, setShowChatBox] = useState(true);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [showRoomInfoModal, setShowRoomInfoModal] = useState(false);
  const [showSeatSettingsModal, setShowSeatSettingsModal] = useState(false);
  const [showQuickToolbar, setShowQuickToolbar] = useState(false);
  const [isPKActive, setIsPKActive] = useState(false);
  const [pkTimeLeft, setPkTimeLeft] = useState(180);
  const [isPartyMode, setIsPartyMode] = useState(false);
  const [showTaskCenter, setShowTaskCenter] = useState(false);
  const [showLuckyBag, setShowLuckyBag] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showMusicModal, setShowMusicModal] = useState(false);
  const [isAnimationsDisabled, setIsAnimationsDisabled] = useState(false);
  const [isScreenClean, setIsScreenClean] = useState(false);
  const [toolbarToast, setToolbarToast] = useState<string | null>(null);

  // Seat Administration & Mic Ascension Modes (نظام أذونات المقاعد)
  const [isMicModeLocked, setIsMicModeLocked] = useState<boolean>(false); // false = Free Mode (مفتوح), true = Request Mode (بالطلب)
  const [pendingMicRequests, setPendingMicRequests] = useState<Array<{
    id: string;
    userId: string;
    userName: string;
    userAvatar: string;
    requestedSeatId?: number;
    timestamp: string;
  }>>([]);

  const [pendingSeatInvite, setPendingSeatInvite] = useState<{
    targetUserId: string;
    targetUserName: string;
    targetUserAvatar: string;
    inviterName: string;
    seatId: number;
  } | null>(null);

  const [showAudiencePicker, setShowAudiencePicker] = useState<boolean>(false);
  const [targetSeatForInvite, setTargetSeatForInvite] = useState<number | null>(null);
  const [showMicRequestsModal, setShowMicRequestsModal] = useState<boolean>(false);

  // Video Broadcast State (بث الفيديو)
  const [isVideoBroadcasting, setIsVideoBroadcasting] = useState(false);
  const [showVideoBroadcastModal, setShowVideoBroadcastModal] = useState(false);
  const [isFrontCamera, setIsFrontCamera] = useState(true);
  const [videoFilter, setVideoFilter] = useState<'beauty' | 'neon' | 'natural' | 'vintage'>('beauty');
  const [isCameraMuted, setIsCameraMuted] = useState(false);
  const videoRef = React.useRef<HTMLVideoElement>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;
    if (isVideoBroadcasting && !isCameraMuted) {
      navigator.mediaDevices?.getUserMedia?.({
        video: { facingMode: isFrontCamera ? 'user' : 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      }).then((mediaStream) => {
        stream = mediaStream;
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
      }).catch(() => {
        // Handled gracefully with stylized live video canvas fallback
      });
    }
    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [isVideoBroadcasting, isFrontCamera, isCameraMuted]);

  const showToast = (msg: string) => {
    setToolbarToast(msg);
    setTimeout(() => setToolbarToast(null), 3500);
  };

  const handleRichGiftSend = (gift: GiftItem, recipientName: string, amount: number) => {
    const unitPrice = gift.priceCoins || gift.priceDiamonds || 10;
    const totalVal = unitPrice * amount;

    // Convert gift coins spent into Host Diamonds Net Bonus
    setHostLiveDiamonds((prev) => prev + totalVal);

    const giftMsg: RoomMessage = {
      id: `gmsg-${Date.now()}`,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      text: `أرسل ${gift.name} (x${amount}) بقيمة ${totalVal.toLocaleString()} 🪙 عملة صفراء إلى ${recipientName}! (+${totalVal.toLocaleString()} 💎 بونص المذيع)`,
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      isGiftNotice: true,
      giftInfo: {
        giftName: gift.name,
        giftIcon: gift.icon,
        amount,
      },
    };

    setCurrentRoom((prev) => {
      const updatedSeats = prev.seats.map((s) => {
        if (s.speakerUser) {
          return {
            ...s,
            points: (s.points || 0) + Math.round(totalVal / 10),
          };
        }
        return s;
      });

      return {
        ...prev,
        messages: [...prev.messages, giftMsg],
        seats: updatedSeats,
      };
    });

    setActiveFloatingGift({ gift, sender: currentUser.name, amount });
    setTimeout(() => setActiveFloatingGift(null), 4000);

    onSendGift(gift, recipientName);
  };

  // PK countdown effect
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPKActive && pkTimeLeft > 0) {
      timer = setInterval(() => {
        setPkTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (pkTimeLeft === 0) {
      setIsPKActive(false);
      setPkTimeLeft(180);
    }
    return () => clearInterval(timer);
  }, [isPKActive, pkTimeLeft]);

  const handleSaveSeatLayout = (layout: SeatLayoutSelection) => {
    setCurrentRoom((prev) => {
      const currentSeats = prev.seats || [];
      const newSeats: MicSeat[] = Array.from({ length: layout.count }, (_, index) => {
        const seatNum = index + 1;
        const existing = currentSeats.find((s) => s.seatId === seatNum);
        if (existing) {
          return {
            ...existing,
            isHostSeat: layout.type === 'boss' && seatNum === 1 ? true : existing.isHostSeat,
          };
        }
        return {
          seatId: seatNum,
          isHostSeat: layout.type === 'boss' && seatNum === 1,
          isLocked: false,
          isMuted: false,
          points: 0,
        };
      });

      return {
        ...prev,
        seats: newSeats,
        seatLayout: layout,
      };
    });

    setShowSeatSettingsModal(false);
  };

  // Treasure chest timer state
  const [boxTimer, setBoxTimer] = useState(25);
  const [isBoxClaimable, setIsBoxClaimable] = useState(false);

  // Check if current user is Host or Moderator
  const isHost = user.id === currentRoom.hostId || currentRoom.hostId === 'SALEEM-8829';
  const isMod = isHost || currentRoom.mods.includes(user.id);
  const canManageRoomLayout =
    isHost || (currentRoom.mods.includes(user.id) && (currentRoom.managerPermissions?.canManageLayout ?? true));

  // Treasure box countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setBoxTimer((prev) => {
        if (prev <= 1) {
          setIsBoxClaimable(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Simulate audio level pulse for speaking users
  useEffect(() => {
    const audioInterval = setInterval(() => {
      setCurrentRoom((prev) => ({
        ...prev,
        seats: prev.seats.map((seat) => {
          if (seat.speakerUser && !seat.isMuted) {
            const isSpeaking = Math.random() > 0.45;
            return {
              ...seat,
              speakerUser: {
                ...seat.speakerUser,
                isSpeaking,
                audioLevel: isSpeaking ? Math.floor(Math.random() * 80) + 20 : 0,
              },
            };
          }
          return seat;
        }),
      }));
    }, 1100);

    return () => clearInterval(audioInterval);
  }, []);

  // Handle seat join / click (النظام الإداري لصعود المقاعد)
  const handleSeatClick = (seat: MicSeat) => {
    if (seat.isLocked) {
      showToast('🔒 هذا المقعد مقفل بواسطة المضيف');
      return;
    }

    if (seat.speakerUser) {
      // Seat is occupied -> Open seat actions menu if Mod, Host, or self
      if (isMod || seat.speakerUser.id === user.id) {
        setSelectedSeatForAction(seat);
      } else {
        showToast(`🎙️ المتحدث على المقعد: ${seat.speakerUser.name}`);
      }
      return;
    }

    // Host or Mod clicking empty seat -> open seat control sheet (قفل / دعوة)
    if (isMod && userOnSeat !== null) {
      setSelectedSeatForAction(seat);
      return;
    }

    // Seat is empty -> check if mic mode is locked (Request Mode) vs Free Mode
    if (isMicModeLocked && !isMod) {
      // Request Mode: Send ascension request to Host
      if (!pendingMicRequests.some((r) => r.userId === user.id)) {
        setPendingMicRequests((prev) => [
          ...prev,
          {
            id: `req-${Date.now()}`,
            userId: user.id,
            userName: user.name,
            userAvatar: user.avatar,
            requestedSeatId: seat.seatId,
            timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
          },
        ]);
      }
      setIsHandRaised(true);
      showToast('✋ تم إرسال طلب الصعود، يرجى انتظار الموافقة');

      setCurrentRoom((prev) => ({
        ...prev,
        messages: [
          ...prev.messages,
          {
            id: Date.now().toString(),
            senderName: 'نظام إدارة المقاعد 🎙️',
            senderAvatar: '',
            text: `أرسل ${user.name} طلباً للصعود على المقعد #${seat.seatId}`,
            timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
            isSystemNotice: true,
          },
        ],
      }));
      return;
    }

    // Free Mode -> Sit on mic seat directly
    if (userOnSeat !== null) {
      leaveSeat();
    }

    setCurrentRoom((prev) => ({
      ...prev,
      seats: prev.seats.map((s) =>
        s.seatId === seat.seatId
          ? {
              ...s,
              speakerUser: {
                id: user.id,
                name: user.name,
                avatar: user.avatar,
                isSpeaking: true,
                audioLevel: 50,
                vipLevel: user.vipLevel,
                role: isHost ? 'مقدم' : 'عضو',
              },
            }
          : s
      ),
      messages: [
        ...prev.messages,
        {
          id: Date.now().toString(),
          senderName: 'نظام إدارة المقاعد 🎙️',
          senderAvatar: '',
          text: `صعد ${user.name} إلى المقعد رقم #${seat.seatId}`,
          timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
          isSystemNotice: true,
        },
      ],
    }));
    setUserOnSeat(seat.seatId);
    setIsHandRaised(false);
  };

  const leaveSeat = () => {
    if (userOnSeat === null) return;
    setCurrentRoom((prev) => ({
      ...prev,
      seats: prev.seats.map((s) =>
        s.seatId === userOnSeat ? { ...s, speakerUser: undefined } : s
      ),
    }));
    setUserOnSeat(null);
  };

  const handleToggleMuteSeat = (seatId: number) => {
    setCurrentRoom((prev) => ({
      ...prev,
      seats: prev.seats.map((s) =>
        s.seatId === seatId ? { ...s, isMuted: !s.isMuted } : s
      ),
    }));
    const targetSeat = currentRoom.seats.find((s) => s.seatId === seatId);
    showToast(targetSeat?.isMuted ? '🎙️ تم فتح المايك' : '🔇 تم كتم صوت المقعد إجبارياً');
    setSelectedSeatForAction(null);
  };

  const handleToggleLockSeat = (seatId: number) => {
    setCurrentRoom((prev) => ({
      ...prev,
      seats: prev.seats.map((s) =>
        s.seatId === seatId ? { ...s, isLocked: !s.isLocked } : s
      ),
    }));
    const targetSeat = currentRoom.seats.find((s) => s.seatId === seatId);
    showToast(targetSeat?.isLocked ? '🔓 تم فتح المقعد للجميع' : '🔒 تم تسكير وقفل المقعد إدارياً');
    setSelectedSeatForAction(null);
  };

  const handleKickSeatUser = (seatId: number) => {
    const targetSeat = currentRoom.seats.find((s) => s.seatId === seatId);
    const userName = targetSeat?.speakerUser?.name || 'المستخدم';

    setCurrentRoom((prev) => ({
      ...prev,
      seats: prev.seats.map((s) =>
        s.seatId === seatId ? { ...s, speakerUser: undefined } : s
      ),
      messages: [
        ...prev.messages,
        {
          id: Date.now().toString(),
          senderName: 'نظام الإدارة 🎙️',
          senderAvatar: '',
          text: `تم إنزال ${userName} من المقعد إلى قسم المستمعين`,
          timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
          isSystemNotice: true,
        },
      ],
    }));

    if (userOnSeat === seatId) setUserOnSeat(null);
    setSelectedSeatForAction(null);
    showToast(`🔽 تم إنزال ${userName} للمستمعين`);
  };

  // Ban / Kick Out User completely from room
  const handleBanUserFromRoom = (seatId: number) => {
    const targetSeat = currentRoom.seats.find((s) => s.seatId === seatId);
    const userName = targetSeat?.speakerUser?.name || 'المستخدم';

    setCurrentRoom((prev) => ({
      ...prev,
      seats: prev.seats.map((s) => (s.seatId === seatId ? { ...s, speakerUser: undefined } : s)),
      listenersCount: Math.max(1, (prev.listenersCount || 10) - 1),
      messages: [
        ...prev.messages,
        {
          id: Date.now().toString(),
          senderName: 'نظام الأمان 🛡️',
          senderAvatar: '',
          text: `تم طرد ${userName} نهائياً من الغرفة الصوتية من قبل المالك`,
          timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
          isSystemNotice: true,
        },
      ],
    }));

    if (userOnSeat === seatId) setUserOnSeat(null);
    setSelectedSeatForAction(null);
    showToast(`🚫 تم طرد ${userName} من الغرفة نهائياً`);
  };

  // Send Seat Invitation to Audience Member
  const handleSendSeatInvite = (targetUser: { id: string; name: string; avatar: string }, seatId: number) => {
    setPendingSeatInvite({
      targetUserId: targetUser.id,
      targetUserName: targetUser.name,
      targetUserAvatar: targetUser.avatar,
      inviterName: user.name,
      seatId,
    });

    setShowAudiencePicker(false);
    setSelectedSeatForAction(null);
    showToast(`✉️ تم إرسال دعوة صعود للمقعد #${seatId} إلى ${targetUser.name}!`);
  };

  // Accept Seat Invite
  const handleAcceptInvite = () => {
    if (!pendingSeatInvite) return;

    const { targetUserId, targetUserName, targetUserAvatar, seatId } = pendingSeatInvite;

    setCurrentRoom((prev) => ({
      ...prev,
      seats: prev.seats.map((s) =>
        s.seatId === seatId
          ? {
              ...s,
              speakerUser: {
                id: targetUserId,
                name: targetUserName,
                avatar: targetUserAvatar,
                isSpeaking: false,
                audioLevel: 0,
                vipLevel: 3,
                role: 'عضو',
              },
            }
          : s
      ),
      messages: [
        ...prev.messages,
        {
          id: Date.now().toString(),
          senderName: 'نظام الدعوات 🎙️',
          senderAvatar: '',
          text: `انضم ${targetUserName} إلى المقعد #${seatId} بناءً على دعوة المالك`,
          timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
          isSystemNotice: true,
        },
      ],
    }));

    if (targetUserId === user.id) {
      setUserOnSeat(seatId);
    }

    showToast(`🎉 أهلاً بك على المقعد رقم #${seatId}`);
    setPendingSeatInvite(null);
  };

  // Reject Seat Invite Scenario
  const handleRejectInvite = () => {
    if (!pendingSeatInvite) return;

    const { targetUserName } = pendingSeatInvite;

    // Server WebSockets / Event: Emit dynamic system rejection notice in chat
    setCurrentRoom((prev) => ({
      ...prev,
      messages: [
        ...prev.messages,
        {
          id: Date.now().toString(),
          senderName: 'نظام SALEEM ⚙️',
          senderAvatar: '',
          text: `رسالة النظام: تم رفض الصعود من قبل ${targetUserName}`,
          timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
          isSystemNotice: true,
        },
      ],
    }));

    showToast(`⚠️ رفض ${targetUserName} دعوة الصعود للمقعد`);
    setPendingSeatInvite(null);
  };

  // Approve Pending Mic Request
  const handleApproveMicRequest = (reqId: string) => {
    const req = pendingMicRequests.find((r) => r.id === reqId);
    if (!req) return;

    const targetSeatId = req.requestedSeatId || currentRoom.seats.find((s) => !s.speakerUser && !s.isLocked)?.seatId || 1;

    setCurrentRoom((prev) => ({
      ...prev,
      seats: prev.seats.map((s) =>
        s.seatId === targetSeatId
          ? {
              ...s,
              speakerUser: {
                id: req.userId,
                name: req.userName,
                avatar: req.userAvatar,
                isSpeaking: false,
                audioLevel: 0,
                vipLevel: 3,
                role: 'عضو',
              },
            }
          : s
      ),
      messages: [
        ...prev.messages,
        {
          id: Date.now().toString(),
          senderName: 'نظام الإدارة 🎙️',
          senderAvatar: '',
          text: `تمت الموافقة على صعود ${req.userName} إلى المقعد #${targetSeatId}`,
          timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
          isSystemNotice: true,
        },
      ],
    }));

    setPendingMicRequests((prev) => prev.filter((r) => r.id !== reqId));
    showToast(`✅ تمت الموافقة على صعود ${req.userName} للمقعد #${targetSeatId}`);
  };

  // Reject Pending Mic Request
  const handleRejectMicRequest = (reqId: string) => {
    const req = pendingMicRequests.find((r) => r.id === reqId);
    if (!req) return;

    setPendingMicRequests((prev) => prev.filter((r) => r.id !== reqId));

    setCurrentRoom((prev) => ({
      ...prev,
      messages: [
        ...prev.messages,
        {
          id: Date.now().toString(),
          senderName: 'نظام الإدارة 🎙️',
          senderAvatar: '',
          text: `رسالة النظام: تم رفض طلب صعود المايك من قبل المالك`,
          timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
          isSystemNotice: true,
        },
      ],
    }));

    showToast(`❌ تم رفض طلب صعود ${req.userName}`);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;

    const newMsg = {
      id: Date.now().toString(),
      senderName: user.name,
      senderAvatar: user.avatar,
      senderVip: user.vipLevel,
      text: chatMessage.trim(),
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
    };

    setCurrentRoom((prev) => ({
      ...prev,
      messages: [...prev.messages, newMsg],
    }));
    setChatMessage('');
  };

  const handleGiftClick = (gift: GiftItem) => {
    onSendGift(gift, currentRoom.hostName);
    
    // Add points to host seat (seat 1) or target seat
    setCurrentRoom((prev) => ({
      ...prev,
      seats: prev.seats.map((s) =>
        s.seatId === 1 ? { ...s, points: (s.points || 0) + gift.priceCoins } : s
      ),
      messages: [
        ...prev.messages,
        {
          id: Date.now().toString(),
          senderName: user.name,
          senderAvatar: user.avatar,
          senderVip: user.vipLevel,
          text: `أرسل هدية 🌹 "${gift.name}" x1 إلى الغرفة`,
          timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
          isGiftNotice: true,
          giftInfo: {
            giftName: gift.name,
            giftIcon: gift.icon,
            amount: gift.priceCoins,
          },
        },
      ],
    }));
    setShowGiftSelector(false);
  };

  const handleClaimTreasureBox = () => {
    if (!isBoxClaimable) return;
    alert('🎉 مبروك! حصلت على 500 عملة ذهبية و10 جواهر من صندوق الكنز!');
    setBoxTimer(60);
    setIsBoxClaimable(false);
  };

  // Build audience list for bottom bar from seats + mock participants
  const audienceList = [
    {
      id: currentRoom.hostId,
      name: currentRoom.hostName,
      avatar: currentRoom.hostAvatar,
      role: 'مقدم' as const,
      isMuted: false,
    },
    {
      id: 'mod-1',
      name: 'أميرة الشوق',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
      role: 'مدير' as const,
      isMuted: true,
    },
    {
      id: 'vip-1',
      name: 'سلطان VIP',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      role: 'VIP' as const,
      isMuted: false,
    },
    {
      id: 'u-3',
      name: 'جود',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      role: 'عضو' as const,
      isMuted: true,
    },
    {
      id: 'u-4',
      name: 'مالك',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
      role: 'عضو' as const,
      isMuted: false,
    },
    {
      id: 'u-5',
      name: 'نورة',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
      role: 'عضو' as const,
      isMuted: true,
    },
    {
      id: 'u-6',
      name: 'فهد',
      avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
      role: 'عضو' as const,
      isMuted: true,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-white flex flex-col justify-between font-sans overflow-hidden select-none dir-rtl h-full max-h-screen">
      {/* Dynamic Purple Stage Background with Spotlights */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <img
          src={currentRoom.backgroundUrl}
          alt="Stage BG"
          className="w-full h-full object-cover opacity-20 blur-md"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-purple-950/90 via-slate-950/95 to-purple-950/90" />
        
        {/* Animated Stage Spotlights Effect */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-lg h-64 bg-gradient-to-b from-purple-500/20 via-indigo-500/10 to-transparent blur-3xl animate-pulse" />
      </div>

      {/* 1. ROOM HEADER TOP BAR */}
      <div className="shrink-0 relative z-20 w-full max-w-md mx-auto px-3 pt-2 pb-1 flex flex-col gap-1 text-xs border-b border-purple-900/40 bg-slate-950/60 backdrop-blur-md">
        {/* Header Main Row */}
        <div className="flex items-center justify-between">
          {/* Left Controls: Back Arrow + Room Title & ID */}
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-slate-900/80 hover:bg-slate-800 text-slate-200 border border-slate-700/60 transition-transform active:scale-90"
              title="خروج من الغرفة"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <div
              onClick={() => setShowRoomInfoModal(true)}
              className="cursor-pointer group hover:opacity-90 transition-opacity"
              title="عرض معلومات الغرفة والوكالة"
            >
              <div className="flex items-center gap-1.5">
                <h2 className="font-black text-sm text-amber-200 tracking-wide line-clamp-1 group-hover:text-amber-300">
                  {currentRoom.title}
                </h2>
                <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400 shrink-0" />
              </div>
              <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono">
                <span>ID: {currentRoom.id.replace('room-', '') || '100562'}</span>
                <span className="flex items-center gap-0.5 text-amber-400 font-bold">
                  <Flame className="w-3 h-3 fill-amber-400" />
                  {currentRoom.tag || '25.6K'}
                </span>
              </div>
            </div>
          </div>

          {/* Right Controls: Attendance Badge + Power Button */}
          <div className="flex items-center gap-2">
            <div
              onClick={() => setShowRoomInfoModal(true)}
              className="flex items-center gap-1 bg-slate-900/80 border border-purple-500/30 px-2.5 py-1 rounded-full text-[11px] font-bold text-slate-200 shadow cursor-pointer hover:bg-slate-800"
              title="لوحة الحضور والوكالة"
            >
              <Users className="w-3.5 h-3.5 text-purple-300" />
              <span>{currentRoom.listenersCount || 1}</span>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-slate-900/80 hover:bg-red-600/80 text-slate-300 hover:text-white border border-slate-700 transition-colors"
              title="إغلاق الغرفة"
            >
              <Power className="w-4 h-4 text-slate-200 hover:text-red-300" />
            </button>
          </div>
        </div>

        {/* Sub Header Row: Rank Badge + Host Live Diamond Bonus Counter + Follow Button & Rewards Counter */}
        <div className="flex items-center justify-between text-[11px] pt-1">
          {/* Room Rank Badge */}
          <div
            onClick={() => setShowRoomInfoModal(true)}
            className="flex items-center gap-1 bg-purple-900/60 border border-amber-500/40 text-amber-300 px-2.5 py-0.5 rounded-full font-bold shadow-sm cursor-pointer hover:bg-purple-900/80 transition-colors"
            title="معلومات مستوى وترتيب الغرفة"
          >
            <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />
            <span>المرتبة 3</span>
            <ChevronLeft className="w-3 h-3 text-amber-400" />
          </div>

          {/* 🌟 HOST LIVE DIAMOND BONUS COUNTER (لوحة البونص المباشرة للمذيع) */}
          <div
            onClick={() => showToast(`💎 إجمالي بونص أرباح المذيع من الهدايا في هذا البث: ${hostLiveDiamonds.toLocaleString()} ماسة صافية!`)}
            className="flex items-center gap-1 bg-gradient-to-r from-purple-900/90 via-indigo-900/90 to-purple-950/90 border border-cyan-400/50 px-2.5 py-0.5 rounded-full font-black text-[10px] text-cyan-200 shadow-md cursor-pointer hover:scale-105 transition-all"
            title="عداد بونص الماسات الصافية للمذيع الحية"
          >
            <span className="text-amber-300 animate-pulse">🌟</span>
            <span className="font-mono text-cyan-300 font-bold">{hostLiveDiamonds >= 1000 ? `${(hostLiveDiamonds / 1000).toFixed(1)}K` : hostLiveDiamonds.toLocaleString()}</span>
            <span className="text-[10px]">💎</span>
          </div>

          {/* Follow Button & Reward Timer */}
          <div className="flex items-center gap-2">
            {!isHost && (
              <button
                onClick={() => setIsFollowing(!isFollowing)}
                className={`px-2.5 py-0.5 rounded-full font-bold text-[11px] transition-all flex items-center gap-1 shadow ${
                  isFollowing
                    ? 'bg-slate-800 text-slate-300 border border-slate-700'
                    : 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white border border-purple-400/40 hover:scale-105'
                }`}
              >
                <span>{isFollowing ? 'تم المتابعة' : '+ متابعة'}</span>
              </button>
            )}

            <div className="flex items-center gap-1 bg-slate-900/90 border border-amber-500/50 px-2 py-0.5 rounded-full font-bold text-[10px] text-amber-300 shadow">
              <span className="text-amber-400">🪙</span>
              <span className="font-mono tracking-wider">{boxTimer}s</span>
            </div>
          </div>
        </div>


      </div>

      {/* Toast Banner Notifications */}
      {toolbarToast && (
        <div className="relative z-30 mx-4 my-1 bg-gradient-to-r from-amber-500/90 via-purple-600/90 to-pink-600/90 border border-amber-300 text-white font-bold text-xs px-3 py-1.5 rounded-full shadow-lg flex items-center justify-between animate-in fade-in slide-in-from-top-2 duration-300">
          <span>{toolbarToast}</span>
          <button onClick={() => setToolbarToast(null)} className="text-amber-200 hover:text-white mr-1 font-mono">✕</button>
        </div>
      )}

      {/* PK Challenge Active Banner */}
      {isPKActive && (
        <div className="relative z-20 mx-3 my-1 bg-gradient-to-r from-pink-900/90 via-purple-900/90 to-cyan-900/90 border border-pink-500/60 rounded-2xl p-2 flex items-center justify-between text-white shadow-xl animate-in fade-in duration-300">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-pink-500 to-cyan-400 flex items-center justify-center font-black text-xs text-slate-950 shadow-md animate-pulse">
              PK
            </div>
            <div>
              <div className="text-[11px] font-black text-pink-200">تحدي المواجهة الشرسة 🔥</div>
              <div className="text-[9px] text-slate-300">جولة التنافس والعداد التلقائي</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="bg-slate-950/80 px-2 py-0.5 rounded-xl border border-pink-500/40 text-[11px] font-mono font-bold text-amber-300">
              ⏱️ {Math.floor(pkTimeLeft / 60)}:{(pkTimeLeft % 60).toString().padStart(2, '0')}
            </div>
            <button
              onClick={() => {
                setIsPKActive(false);
                showToast('تم إنهاء المواجهة');
              }}
              className="text-[10px] bg-red-500/30 hover:bg-red-500/50 px-2 py-0.5 rounded-lg border border-red-500/40 text-red-200"
            >
              إنهاء
            </button>
          </div>
        </div>
      )}

      {/* Clean Screen Restoration Button */}
      {isScreenClean && (
        <div className="relative z-30 flex justify-center my-1">
          <button
            onClick={() => {
              setIsScreenClean(false);
              showToast('تم إرجاع عناصر الواجهة الكاملة');
            }}
            className="bg-amber-500/90 hover:bg-amber-400 text-slate-950 px-3 py-1 rounded-full text-xs font-black shadow-lg flex items-center gap-1.5 border border-amber-300 animate-pulse"
          >
            <Maximize2 className="w-3.5 h-3.5" />
            <span>إلغاء تصفية الشاشة (إظهار العناصر)</span>
          </button>
        </div>
      )}

      {/* Active Live Video Stream Stage Frame (شاشة بث الفيديو المباشر) */}
      {isVideoBroadcasting && (
        <div className="relative z-20 mx-3 my-1.5 bg-slate-950 border-2 border-rose-500/80 rounded-2xl overflow-hidden shadow-2xl shadow-rose-950/60 animate-in fade-in zoom-in duration-300">
          <div className="relative w-full h-44 sm:h-52 bg-slate-900 flex items-center justify-center overflow-hidden">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover transform ${isFrontCamera ? 'scale-x-[-1]' : ''} ${
                videoFilter === 'beauty' ? 'brightness-110 contrast-105 saturate-110' :
                videoFilter === 'neon' ? 'hue-rotate-90 brightness-125' :
                videoFilter === 'vintage' ? 'sepia contrast-120' : ''
              } ${isCameraMuted ? 'hidden' : 'block'}`}
            />

            {/* Muted Camera / Placeholder Overlay */}
            {isCameraMuted && (
              <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center space-y-2 p-4 text-center">
                <div className="w-14 h-14 rounded-full bg-rose-950/60 border border-rose-500/50 flex items-center justify-center shadow-lg">
                  <VideoOff className="w-7 h-7 text-rose-400" />
                </div>
                <p className="text-xs font-bold text-rose-200">الكاميرا متوقفة مؤقتاً</p>
                <p className="text-[10px] text-slate-400">بث الفيديو المباشر يعمل - تم كتم الصورة</p>
              </div>
            )}

            {/* Live Video Top Control Bar */}
            <div className="absolute top-2 left-2 right-2 flex items-center justify-between z-10">
              <div className="flex items-center gap-1.5 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-full border border-rose-500/50">
                <span className="w-2.5 h-2.5 bg-rose-500 rounded-full animate-ping" />
                <span className="text-[10px] font-black text-rose-300 uppercase tracking-wider">🔴 LIVE 🎥 1080p</span>
              </div>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setIsCameraMuted(!isCameraMuted)}
                  className="p-1.5 bg-black/70 hover:bg-black rounded-full border border-white/20 text-white text-xs transition-colors"
                  title={isCameraMuted ? 'تشغيل الكاميرا' : 'كتم الكاميرا'}
                >
                  {isCameraMuted ? <VideoOff className="w-3.5 h-3.5 text-rose-400" /> : <Video className="w-3.5 h-3.5 text-emerald-400" />}
                </button>
                <button
                  type="button"
                  onClick={() => setIsFrontCamera(!isFrontCamera)}
                  className="p-1.5 bg-black/70 hover:bg-black rounded-full border border-white/20 text-white text-xs transition-colors"
                  title="تبديل الكاميرا (الأمامية / الخلفية)"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-amber-300" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsVideoBroadcasting(false);
                    showToast('تم إيقاف بث الفيديو المباشر');
                  }}
                  className="p-1.5 bg-rose-600/90 hover:bg-rose-600 rounded-full text-white text-xs transition-colors shadow"
                  title="إغلاق الفيديو"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Bottom Streamer Info Tag */}
            <div className="absolute bottom-1.5 left-2 right-2 flex items-center justify-between z-10 bg-gradient-to-t from-black/90 via-black/50 to-transparent px-2.5 py-1.5 rounded-b-xl">
              <div className="flex items-center gap-2">
                <img src={currentUser.avatar} alt={currentUser.name} className="w-7 h-7 rounded-full border border-rose-400 object-cover" />
                <div>
                  <div className="text-xs font-black text-white flex items-center gap-1">
                    <span>{currentUser.name}</span>
                    <span className="text-[9px] bg-rose-600 text-white px-1.5 py-0.2 rounded font-black tracking-wide">بث فيديو</span>
                  </div>
                  <div className="text-[9px] text-rose-200">مباشر الآن عبر الكاميرا الحية 📹</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. DYNAMIC SPEAKERS MIC GRID (10, 12, 14, 15, 20, 25, 30 Seats Layout with Responsive Internal Scroll) */}
      <div className="flex-1 min-h-0 relative z-10 w-full max-w-md mx-auto px-2 py-1 flex flex-col justify-start overflow-y-auto no-scrollbar my-auto">
        
        {/* Host/Mod Quick Layout Action Bar */}
        {canManageRoomLayout && (
          <div className="flex items-center justify-between px-2 mb-1 text-[11px] shrink-0">
            <button
              onClick={() => setShowSeatSettingsModal(true)}
              className="flex items-center gap-1.5 bg-purple-900/60 hover:bg-purple-800/80 border border-purple-500/40 text-purple-200 px-2.5 py-1 rounded-full font-bold shadow transition-all active:scale-95"
            >
              <Grid className="w-3.5 h-3.5 text-amber-400" />
              <span>تخصيص الهيكلية ({currentRoom.seatLayout?.type === 'boss' ? 'مايك البوس' : 'مايك أساسي'} - {currentRoom.seats.length} مقعد)</span>
            </button>
            <span className="text-[10px] text-slate-400 font-medium">قالب شبكة المقاعد</span>
          </div>
        )}

        {/* Dynamic Grid Layout */}
        {(() => {
          const totalSeats = currentRoom.seats.length;
          const is30Seats = totalSeats >= 21;
          const is20Seats = totalSeats >= 16 && totalSeats < 21;
          const is15Seats = totalSeats >= 11 && totalSeats < 16;

          let gridColsClass = 'grid-cols-5';
          if (totalSeats === 12 || totalSeats === 14) {
            gridColsClass = 'grid-cols-4';
          } else if (is30Seats) {
            gridColsClass = 'grid-cols-6';
          }

          let seatCircleSizeClass = 'w-11 h-11 sm:w-12 sm:h-12';
          let bossSeatSizeClass = 'w-14 h-14';
          let seatTextClass = 'text-[9px]';
          let gapClass = 'gap-y-2 gap-x-1.5';

          if (is30Seats) {
            seatCircleSizeClass = 'w-8 h-8 sm:w-9 sm:h-9';
            bossSeatSizeClass = 'w-11 h-11';
            seatTextClass = 'text-[8px]';
            gapClass = 'gap-y-1 gap-x-1';
          } else if (is20Seats) {
            seatCircleSizeClass = 'w-9 h-9 sm:w-10 sm:h-10';
            bossSeatSizeClass = 'w-12 h-12';
            seatTextClass = 'text-[8.5px]';
            gapClass = 'gap-y-1.5 gap-x-1';
          } else if (is15Seats) {
            seatCircleSizeClass = 'w-10 h-10 sm:w-11 sm:h-11';
            bossSeatSizeClass = 'w-13 h-13';
            seatTextClass = 'text-[9px]';
            gapClass = 'gap-y-1.5 gap-x-1.5';
          }

          return (
            <div className={`grid ${gridColsClass} ${gapClass} my-auto py-1`}>
              {currentRoom.seats.map((seat) => {
                const speaker = seat.speakerUser;
                const isBossMic = (currentRoom.seatLayout?.type === 'boss' || seat.isHostSeat) && seat.seatId === 1;

                return (
                  <div
                    key={seat.seatId}
                    onClick={() => handleSeatClick(seat)}
                    className={`flex flex-col items-center group cursor-pointer relative ${
                      isBossMic ? 'col-span-full py-0.5' : ''
                    }`}
                  >
                    {/* Ordered Number / Boss Badge above Mic Circle */}
                    {isBossMic ? (
                      <div className="flex items-center gap-1 bg-amber-500/20 border border-amber-400/60 px-2 py-0.5 rounded-full text-[9px] font-black text-amber-300 mb-0.5 shadow">
                        <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />
                        <span>مايك البوس #1</span>
                      </div>
                    ) : (
                      <span className={`${seatTextClass} font-bold text-slate-300/80 mb-0.5`}>
                        {seat.seatId}
                      </span>
                    )}

                    {/* Mic Seat Circle Container */}
                    <div className="relative">
                      {/* Speaker Soundwave Ripple Effect */}
                      {speaker && speaker.isSpeaking && !seat.isMuted && (
                        <div className="absolute -inset-1 rounded-full bg-purple-500/30 animate-ping border border-purple-400/60" />
                      )}

                      <div
                        className={`rounded-full flex items-center justify-center relative overflow-hidden transition-all shadow-md ${
                          isBossMic ? bossSeatSizeClass : seatCircleSizeClass
                        } ${
                          speaker
                            ? 'border-2 border-amber-400 bg-slate-900'
                            : seat.isLocked
                            ? 'border-2 border-slate-800 bg-slate-950/80'
                            : 'border-2 border-dashed border-purple-500/50 hover:border-amber-400 bg-purple-950/30'
                        }`}
                      >
                        {speaker ? (
                          <img
                            src={speaker.avatar}
                            alt={speaker.name}
                            className="w-full h-full object-cover"
                          />
                        ) : seat.isLocked ? (
                          <Lock className="w-3.5 h-3.5 text-slate-600" />
                        ) : isBossMic ? (
                          <Crown className="w-5 h-5 text-amber-400 fill-amber-400/30 group-hover:scale-110 transition-transform" />
                        ) : (
                          <Plus className="w-4 h-4 text-purple-300 group-hover:scale-110 transition-transform" />
                        )}

                        {/* Mic Muted Badge */}
                        {seat.isMuted && (
                          <div className="absolute inset-0 bg-slate-950/70 flex items-center justify-center">
                            <MicOff className="w-3 h-3 text-red-400" />
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Seat Score / Points Badge Below Circle */}
                    <div className={`mt-0.5 flex items-center gap-0.5 ${seatTextClass} font-bold text-purple-300/90`}>
                      <span>{seat.points || 0}</span>
                      <span className="text-purple-400 text-[8px]">⭐</span>
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })()}
      </div>

      {/* 3. AUDIENCE / SEAT BAR (شريط قائمة الحضور والأعضاء) */}
      <div className="shrink-0 relative z-10 w-full max-w-md mx-auto px-3 py-1 bg-slate-950/80 border-t border-b border-purple-900/40 flex items-center gap-3 overflow-x-auto no-scrollbar">
        {/* Members Count Badge */}
        <div className="flex flex-col items-center justify-center shrink-0 pr-1 text-slate-400">
          <Users className="w-4 h-4 text-purple-400" />
          <span className="text-[9px] font-bold text-slate-300">الأعضاء</span>
          <span className="text-[8px] font-mono text-slate-400">({currentRoom.listenersCount || 128})</span>
        </div>

        {/* Member Avatars with Role Badges */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5">
          {audienceList.map((member) => (
            <div key={member.id} className="relative flex flex-col items-center shrink-0 group">
              <div className="relative w-8 h-8 rounded-full p-0.5 bg-gradient-to-tr from-purple-500 via-amber-400 to-indigo-500 shadow">
                <img
                  src={member.avatar}
                  alt={member.name}
                  className="w-full h-full rounded-full object-cover"
                />
                {member.isMuted && (
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-slate-900 rounded-full border border-slate-700 flex items-center justify-center">
                    <MicOff className="w-1.5 h-1.5 text-red-400" />
                  </span>
                )}
              </div>

              {/* Role Badge under photo */}
              <span
                className={`mt-0.5 text-[8px] font-black px-1.5 py-0.2 rounded-full border shadow-sm ${
                  member.role === 'مقدم'
                    ? 'bg-amber-500 text-slate-950 border-amber-300'
                    : member.role === 'مدير'
                    ? 'bg-purple-600 text-white border-purple-400'
                    : member.role === 'VIP'
                    ? 'bg-amber-600 text-amber-100 border-amber-400'
                    : 'bg-slate-800 text-slate-300 border-slate-700'
                }`}
              >
                {member.role}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 4. LIVE CHAT LOG & REWARD TREASURE BOX AREA */}
      <div className="shrink-0 relative z-10 w-full max-w-md mx-auto px-3 py-1 flex items-end justify-between gap-2 min-h-[100px] max-h-[140px]">
        {/* Left Floating Live Events Chat Log */}
        {showChatBox && (
          <div className="flex-1 overflow-y-auto space-y-1.5 max-h-[130px] pr-1 text-xs no-scrollbar">
            {/* Default Welcome Banner */}
            <div className="bg-slate-900/80 backdrop-blur border border-purple-500/30 text-amber-200 px-3 py-1 rounded-xl text-[10px] flex items-center gap-2 shadow">
              <Volume2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>مرحباً بك في غرفة {currentRoom.title}</span>
            </div>

            {/* Simulated Live Room Messages */}
            {currentRoom.messages.map((msg) => (
              <div
                key={msg.id}
                className={`p-1.5 rounded-xl transition-all max-w-[85%] backdrop-blur text-[10px] ${
                  msg.isSystemNotice
                    ? 'bg-purple-950/70 border border-purple-500/30 text-purple-200'
                    : msg.isGiftNotice
                    ? 'bg-gradient-to-r from-amber-900/80 to-purple-900/80 border border-amber-400/50 text-amber-200 font-bold shadow-md'
                    : 'bg-slate-900/80 border border-slate-800 text-slate-200'
                }`}
              >
                {!msg.isSystemNotice && (
                  <div className="flex items-center gap-1.5 mb-0.5">
                    {msg.senderAvatar && (
                      <img
                        src={msg.senderAvatar}
                        alt={msg.senderName}
                        className="w-3.5 h-3.5 rounded-full object-cover"
                      />
                    )}
                    <span className="font-bold text-amber-300 text-[9px]">{msg.senderName}</span>
                  </div>
                )}
                <p className="leading-snug">{msg.text}</p>
              </div>
            ))}
          </div>
        )}

        {/* Right Floating Treasure Box / Reward Chest Card */}
        <div className="shrink-0 flex flex-col items-center">
          <div className="relative w-18 h-20 rounded-2xl bg-gradient-to-b from-purple-900/90 via-slate-900/90 to-purple-950/90 border border-purple-500/50 p-1.5 flex flex-col items-center justify-between shadow-[0_0_20px_rgba(168,85,247,0.3)] backdrop-blur-md">
            {/* Glowing Chest Graphic */}
            <div className="relative my-auto">
              <div className="absolute -inset-2 rounded-full bg-amber-500/30 blur-md animate-pulse" />
              <div className="text-2xl filter drop-shadow-[0_4px_8px_rgba(245,158,11,0.6)]">
                🎁
              </div>
            </div>

            {/* Timer & Open Button */}
            <div className="w-full flex flex-col items-center gap-0.5">
              <span className="text-[9px] font-mono font-bold text-amber-300">
                00:{boxTimer < 10 ? `0${boxTimer}` : boxTimer}
              </span>
              <button
                onClick={handleClaimTreasureBox}
                className={`w-full py-0.5 rounded-lg text-[9px] font-black transition-all shadow ${
                  isBoxClaimable
                    ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 animate-bounce'
                    : 'bg-purple-600/80 text-white hover:bg-purple-500'
                }`}
              >
                {isBoxClaimable ? 'احصل الآن!' : 'فتح'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 5. TOOLBAR POPUP DIALOG (شريط الأدوات) - Restricted to Owner & Admins */}
      {isMod && showQuickToolbar && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
          <div
            className="w-full max-w-md bg-[#0e0c1a] border border-[#2d2545] rounded-t-3xl sm:rounded-3xl p-4 shadow-2xl space-y-4 relative overflow-hidden text-right"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Top Gold Subtle Radial Glow */}
            <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-48 h-24 bg-amber-500/10 blur-2xl pointer-events-none" />

            {/* Header */}
            <div className="relative flex items-center justify-center pt-1 pb-1">
              {/* Close Button on Left */}
              <button
                onClick={() => setShowQuickToolbar(false)}
                className="absolute left-0 w-8 h-8 rounded-full bg-[#1b162d] border border-amber-500/30 text-amber-200/80 hover:text-white flex items-center justify-center hover:bg-slate-800 transition-colors"
                title="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Center Title with Diamond Motifs */}
              <div className="flex items-center gap-2">
                <span className="text-amber-400 text-xs">❖</span>
                <h3 className="text-base font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-300 to-amber-100">
                  شريط الأدوات
                </h3>
                <span className="text-amber-400 text-xs">❖</span>
              </div>
            </div>

            {!isMod ? (
              <div className="text-center py-6 space-y-3">
                <div className="w-14 h-14 rounded-full bg-red-500/20 border border-red-500/50 text-red-400 flex items-center justify-center mx-auto text-2xl shadow-lg">
                  🔒
                </div>
                <h4 className="text-sm font-black text-red-300">وصول محمي - إدارة الغرفة</h4>
                <p className="text-xs text-slate-300 px-4 leading-relaxed">
                  شريط الأدوات والتحكم بغرفة البث حصرية لـ <span className="text-amber-300 font-bold">صاحب الغرفة (Owner)</span> و <span className="text-purple-300 font-bold">المشرفين المعينين (Admins)</span> فقط.
                </p>
                <button
                  onClick={() => setShowQuickToolbar(false)}
                  className="mt-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-6 py-2 rounded-xl border border-slate-700 active:scale-95 transition-transform"
                >
                  فهمت ذلك
                </button>
              </div>
            ) : (
              <>
                {/* Security Role Badge Header */}
                <div className="flex items-center justify-center gap-1.5 bg-amber-500/10 border border-amber-500/30 rounded-full px-3 py-0.5 text-[10px] font-bold text-amber-300 mx-auto w-fit">
                  <Shield className="w-3 h-3 text-amber-400" />
                  <span>{isHost ? 'صلاحية صاحب الغرفة (Owner) 👑' : 'صلاحية مشرف معين (Admin) 🛡️'}</span>
                </div>

                {/* Row 1: 4 Main Glowing Feature Buttons (مواجهة, حفلة, مركز المهام, حقيبة الحظ) */}
                <div className="grid grid-cols-4 gap-3 py-1">
                  {/* 1. مواجهة (PK) */}
                  <button
                    onClick={() => {
                      setIsPKActive(!isPKActive);
                      setShowQuickToolbar(false);
                      showToast(isPKActive ? 'تم إنهاء تحدي المواجهة' : 'بدأت جولة المواجهة والتنافس! 🔥');
                    }}
                    className="flex flex-col items-center gap-1.5 group cursor-pointer"
                  >
                    <div className="relative w-14 h-14 rounded-full p-[2px] bg-gradient-to-br from-pink-500 via-purple-500 to-cyan-400 shadow-lg shadow-purple-900/50 group-hover:scale-105 active:scale-95 transition-all">
                      <div className="w-full h-full rounded-full bg-[#18122c] flex items-center justify-center overflow-hidden border border-purple-300/40">
                        <span className="text-lg font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-300 to-cyan-300 drop-shadow">
                          PK
                        </span>
                      </div>
                      {isPKActive && (
                        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-slate-900 animate-ping" />
                      )}
                    </div>
                    <span className="text-xs font-bold text-slate-200 group-hover:text-amber-300 transition-colors">
                      مواجهة
                    </span>
                  </button>

                  {/* 2. حفلة */}
                  <button
                    onClick={() => {
                      setIsPartyMode(!isPartyMode);
                      setShowQuickToolbar(false);
                      showToast(isPartyMode ? 'تم إيقاف وضع الحفلة' : '🎉 تم تحويل أجواء الغرفة لنمط الحفلات!');
                    }}
                    className="flex flex-col items-center gap-1.5 group cursor-pointer"
                  >
                    <div className="relative w-14 h-14 rounded-full p-[2px] bg-gradient-to-br from-purple-500 via-pink-500 to-amber-400 shadow-lg shadow-pink-900/50 group-hover:scale-105 active:scale-95 transition-all">
                      <div className="w-full h-full rounded-full bg-[#1e1333] flex items-center justify-center border border-pink-300/40">
                        <Sparkles className="w-6 h-6 text-pink-300 animate-pulse" />
                      </div>
                      {isPartyMode && (
                        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-400 rounded-full border-2 border-slate-900" />
                      )}
                    </div>
                    <span className="text-xs font-bold text-slate-200 group-hover:text-amber-300 transition-colors">
                      حفلة
                    </span>
                  </button>

                  {/* 3. مركز المهام */}
                  <button
                    onClick={() => {
                      setShowTaskCenter(true);
                      setShowQuickToolbar(false);
                    }}
                    className="flex flex-col items-center gap-1.5 group cursor-pointer"
                  >
                    <div className="w-14 h-14 rounded-full p-[2px] bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 shadow-lg shadow-amber-900/50 group-hover:scale-105 active:scale-95 transition-all">
                      <div className="w-full h-full rounded-full bg-[#251b0f] flex items-center justify-center border border-amber-400/40">
                        <Calendar className="w-6 h-6 text-amber-300" />
                      </div>
                    </div>
                    <span className="text-xs font-bold text-slate-200 group-hover:text-amber-300 transition-colors">
                      مركز المهام
                    </span>
                  </button>

                  {/* 4. حقيبة الحظ */}
                  <button
                    onClick={() => {
                      setShowLuckyBag(true);
                      setShowQuickToolbar(false);
                    }}
                    className="flex flex-col items-center gap-1.5 group cursor-pointer"
                  >
                    <div className="w-14 h-14 rounded-full p-[2px] bg-gradient-to-br from-rose-500 via-purple-600 to-amber-400 shadow-lg shadow-rose-900/50 group-hover:scale-105 active:scale-95 transition-all">
                      <div className="w-full h-full rounded-full bg-[#230f1e] flex items-center justify-center border border-rose-400/40">
                        <Gift className="w-6 h-6 text-rose-300 animate-bounce" />
                      </div>
                    </div>
                    <span className="text-xs font-bold text-slate-200 group-hover:text-amber-300 transition-colors">
                      حقيبة الحظ
                    </span>
                  </button>
                </div>

                {/* Golden Diamond Divider Line */}
                <div className="relative flex items-center justify-center my-2">
                  <div className="w-full border-t border-[#292240]" />
                  <span className="absolute bg-[#0e0c1a] px-2 text-amber-400 text-[10px]">❖</span>
                </div>

                {/* Row 2: Circular Dark Buttons (مشاركة, وضع المقاعد, صوت الإغلاق, رسومية الإغلاق, موسيقى, استدعاء الجمهور) */}
                <div className="grid grid-cols-5 gap-2 pt-1">
                  {/* 1. وضع المقاعد (مفتوح / بالطلب) */}
                  <button
                    onClick={() => {
                      setIsMicModeLocked(!isMicModeLocked);
                      showToast(
                        !isMicModeLocked
                          ? '🔒 تم تحويل نظام صعود المقاعد إلى: وضع الطلب والموافقة (Request Mode)'
                          : '🔓 تم فتح نظام صعود المقاعد للجميع فوراً (Free Mode)'
                      );
                    }}
                    className={`flex flex-col items-center gap-1.5 group cursor-pointer ${
                      isMicModeLocked ? 'text-amber-400' : 'text-emerald-400'
                    }`}
                  >
                    <div className={`w-11 h-11 rounded-full border flex items-center justify-center transition-all ${
                      isMicModeLocked
                        ? 'bg-amber-950/60 border-amber-500 text-amber-300'
                        : 'bg-emerald-950/60 border-emerald-500 text-emerald-300'
                    }`}>
                      {isMicModeLocked ? <Lock className="w-5 h-5" /> : <Unlock className="w-5 h-5" />}
                    </div>
                    <span className="text-[10px] font-bold text-center leading-tight">
                      {isMicModeLocked ? 'المقاعد: بالطلب' : 'المقاعد: مفتوحة'}
                    </span>
                  </button>

                  {/* 2. مشاركة */}
                  <button
                    onClick={() => {
                      setShowShareModal(true);
                      setShowQuickToolbar(false);
                    }}
                    className="flex flex-col items-center gap-1.5 group cursor-pointer"
                  >
                    <div className="w-11 h-11 rounded-full bg-[#1a162b] border border-amber-500/20 flex items-center justify-center group-hover:border-amber-400 group-hover:bg-[#251f3b] transition-all">
                      <Share2 className="w-5 h-5 text-amber-300" />
                    </div>
                    <span className="text-[10px] font-bold text-slate-300 group-hover:text-white">
                      مشاركة
                    </span>
                  </button>

                  {/* 3. صوت الإغلاق */}
                  <button
                    onClick={() => {
                      setIsRoomAudioMuted(!isRoomAudioMuted);
                      showToast(isRoomAudioMuted ? 'تم تشغيل صوت الغرفة 🔊' : 'تم كتم الصوت العام للغرفة 🔇');
                    }}
                    className={`flex flex-col items-center gap-1.5 group cursor-pointer ${
                      isRoomAudioMuted ? 'text-red-400' : 'text-slate-300'
                    }`}
                  >
                    <div className={`w-11 h-11 rounded-full border flex items-center justify-center transition-all ${
                      isRoomAudioMuted
                        ? 'bg-red-950/60 border-red-500 text-red-400'
                        : 'bg-[#1a162b] border-amber-500/20 group-hover:border-amber-400 text-amber-300'
                    }`}>
                      <VolumeX className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold text-center leading-tight">
                      صوت الإغلاق
                    </span>
                  </button>

                  {/* 4. رسومية الإغلاق */}
                  <button
                    onClick={() => {
                      setIsAnimationsDisabled(!isAnimationsDisabled);
                      showToast(isAnimationsDisabled ? 'تم تفعيل رسوميات ومؤثرات البث 💥' : 'تم إيقاف الرسوميات الثقيلة لتسريع البث ⚡');
                    }}
                    className={`flex flex-col items-center gap-1.5 group cursor-pointer ${
                      isAnimationsDisabled ? 'text-amber-400' : 'text-slate-300'
                    }`}
                  >
                    <div className={`w-11 h-11 rounded-full border flex items-center justify-center transition-all ${
                      isAnimationsDisabled
                        ? 'bg-amber-950/60 border-amber-500 text-amber-400'
                        : 'bg-[#1a162b] border-amber-500/20 group-hover:border-amber-400 text-amber-300'
                    }`}>
                      <ZapOff className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold text-center leading-tight">
                      رسومية الإغلاق
                    </span>
                  </button>

                  {/* 4. موسيقى */}
                  <button
                    onClick={() => {
                      setShowMusicModal(true);
                      setShowQuickToolbar(false);
                    }}
                    className="flex flex-col items-center gap-1.5 group cursor-pointer"
                  >
                    <div className={`w-11 h-11 rounded-full border flex items-center justify-center transition-all ${
                      isMusicPlaying
                        ? 'bg-purple-900/60 border-purple-400 text-purple-300'
                        : 'bg-[#1a162b] border-amber-500/20 group-hover:border-amber-400 text-amber-300'
                    }`}>
                      <Music className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold text-slate-300 group-hover:text-white">
                      موسيقى
                    </span>
                  </button>

                  {/* 5. استدعاء الجمهور */}
                  <button
                    onClick={() => {
                      showToast('📣 تم إرسال نداء استدعاء عاجل واهتزاز لجميع متابعيك بالخارج!');
                      setShowQuickToolbar(false);
                    }}
                    className="flex flex-col items-center gap-1.5 group cursor-pointer"
                  >
                    <div className="w-11 h-11 rounded-full bg-[#1a162b] border border-amber-500/20 flex items-center justify-center group-hover:border-amber-400 group-hover:bg-[#251f3b] transition-all">
                      <Megaphone className="w-5 h-5 text-amber-300" />
                    </div>
                    <span className="text-[10px] font-bold text-slate-300 group-hover:text-white text-center leading-tight">
                      استدعاء الجمهور
                    </span>
                  </button>
                </div>

                {/* Row 3: Bottom Corner Buttons (تصفية الشاشة + بث فيديو) */}
                <div className="flex items-center justify-between pt-2 border-t border-[#292240]/60">
                  <button
                    onClick={() => {
                      setIsScreenClean(!isScreenClean);
                      setShowQuickToolbar(false);
                      showToast(isScreenClean ? 'تم إرجاع عناصر القائمة' : 'تم تصفية الشاشة بنقاء 🖼️');
                    }}
                    className="flex flex-col items-center gap-1 group cursor-pointer"
                  >
                    <div className={`w-11 h-11 rounded-full border flex items-center justify-center transition-all ${
                      isScreenClean
                        ? 'bg-amber-500/30 border-amber-400 text-amber-200'
                        : 'bg-[#1a162b] border-amber-500/20 group-hover:border-amber-400 text-amber-300'
                    }`}>
                      <Maximize2 className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold text-slate-300 group-hover:text-white">
                      تصفية الشاشة
                    </span>
                  </button>

                  <button
                    onClick={() => {
                      setShowQuickToolbar(false);
                      if (isVideoBroadcasting) {
                        setIsVideoBroadcasting(false);
                        showToast('📹 تم إيقاف بث الفيديو المباشر');
                      } else {
                        setShowVideoBroadcastModal(true);
                      }
                    }}
                    className="flex flex-col items-center gap-1 group cursor-pointer"
                  >
                    <div className={`w-11 h-11 rounded-full border flex items-center justify-center transition-all ${
                      isVideoBroadcasting
                        ? 'bg-rose-600 border-rose-400 text-white animate-pulse'
                        : 'bg-[#1a162b] border-rose-500/30 group-hover:border-rose-400 text-rose-400'
                    }`}>
                      <Video className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold text-slate-300 group-hover:text-white">
                      {isVideoBroadcasting ? 'إيقاف الفيديو' : 'بث فيديو'}
                    </span>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* 6. BOTTOM CONTROL BAR (شريط أدوات التحكم السفلي) */}
      <div className="shrink-0 relative z-20 w-full max-w-md mx-auto bg-[#131923]/95 border-t border-slate-800/80 px-2.5 py-2 shadow-2xl">
        <div className="flex items-center justify-between gap-1.5">
          
          {/* Gift Box Button */}
          <button
            onClick={() => setShowGiftSelector(!showGiftSelector)}
            className="w-9 h-9 shrink-0 rounded-full bg-gradient-to-tr from-purple-600 via-pink-500 to-rose-400 text-white flex items-center justify-center shadow-lg shadow-purple-900/40 border border-pink-400/30 hover:scale-105 active:scale-95 transition-all"
            title="إرسال هدية"
          >
            <Gift className="w-4 h-4 text-white" />
          </button>

          {/* Mini-Games Button */}
          <button
            onClick={onOpenGames}
            className="w-8 h-8 shrink-0 rounded-full bg-[#202836] border border-slate-700/60 text-purple-300 flex items-center justify-center hover:bg-slate-700/80 transition-all active:scale-95"
            title="الألعاب والفعاليات"
          >
            <Gamepad2 className="w-4 h-4" />
          </button>

          {/* Video Broadcast Button (زر بث فيديو) */}
          <button
            onClick={() => {
              if (isVideoBroadcasting) {
                setIsVideoBroadcasting(false);
                showToast('📹 تم إيقاف بث الفيديو المباشر');
              } else {
                setShowVideoBroadcastModal(true);
              }
            }}
            className={`w-9 h-9 shrink-0 rounded-full border flex items-center justify-center transition-all active:scale-95 relative shadow-md cursor-pointer ${
              isVideoBroadcasting
                ? 'bg-rose-600 border-rose-400 text-white animate-pulse shadow-rose-900/50'
                : 'bg-gradient-to-r from-red-600 to-rose-600 border-rose-400/40 text-white hover:scale-105'
            }`}
            title="زر بث فيديو مباشر"
          >
            {isVideoBroadcasting ? <Video className="w-4.5 h-4.5 text-white" /> : <VideoOff className="w-4.5 h-4.5 text-white/90" />}
            {isVideoBroadcasting && (
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-slate-900 animate-ping" />
            )}
          </button>

          {/* Messages / Chat Toggle Button with Badge 21 */}
          <button
            onClick={() => setShowChatBox(!showChatBox)}
            className="w-8 h-8 shrink-0 rounded-full bg-[#202836] border border-slate-700/60 text-slate-200 flex items-center justify-center hover:bg-slate-700/80 transition-all active:scale-95 relative"
            title="الدردشة والرسائل"
          >
            <MessageSquare className="w-4 h-4 text-slate-200" />
            <span className="absolute -top-1 -right-1 bg-purple-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow border border-purple-400/40">
              21
            </span>
          </button>

          {/* Queue / Mic Requests Button for Host & Mod */}
          {isMod ? (
            <button
              onClick={() => setShowMicRequestsModal(true)}
              className="w-8 h-8 shrink-0 rounded-full bg-[#202836] border border-amber-500/50 text-amber-300 flex items-center justify-center hover:bg-slate-700/80 transition-all active:scale-95 relative"
              title="طلبات صعود المايك والانتظار"
            >
              <Inbox className="w-4 h-4 text-amber-300" />
              {pendingMicRequests.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow border border-red-400 animate-pulse">
                  {pendingMicRequests.length}
                </span>
              )}
            </button>
          ) : (
            <button
              onClick={() => setShowRoomInfoModal(true)}
              className="w-8 h-8 shrink-0 rounded-full bg-[#202836] border border-slate-700/60 text-slate-200 flex items-center justify-center hover:bg-slate-700/80 transition-all active:scale-95"
              title="الأعضاء وقائمة المايك"
            >
              <Users className="w-4 h-4 text-slate-200" />
            </button>
          )}

          {/* Request Mic / Hand Raise / Mic Toggle Button */}
          <button
            onClick={() => {
              if (userOnSeat !== null) {
                // Toggle mic mute for current seat
                setIsMicMuted(!isMicMuted);
                handleToggleMuteSeat(userOnSeat);
              } else {
                // Find first available unlocked empty seat
                const emptySeat = currentRoom.seats.find((s) => !s.speakerUser && !s.isLocked);
                if (emptySeat) {
                  handleSeatClick(emptySeat);
                } else {
                  showToast('⚠️ جميع المقاعد مشغولة أو مقفلة حالياً');
                }
              }
            }}
            className={`w-8 h-8 shrink-0 rounded-full border flex items-center justify-center transition-all active:scale-95 relative ${
              userOnSeat !== null
                ? isMicMuted
                  ? 'bg-red-500/20 border-red-500 text-red-400'
                  : 'bg-emerald-500/20 border-emerald-400 text-emerald-300 animate-pulse'
                : isHandRaised
                ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                : 'bg-[#202836] border-slate-700/60 text-slate-200 hover:bg-slate-700/80'
            }`}
            title={
              userOnSeat !== null
                ? isMicMuted
                  ? 'المايك مكتوم - انقر لإلغاء الكتم'
                  : 'المايك يعمل - انقر للكتم'
                : isHandRaised
                ? 'تم طلب المايك ✋'
                : 'صعود المايك / طلب الكلمة'
            }
          >
            {userOnSeat !== null ? (
              isMicMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-emerald-400" />
            ) : (
              <Mic className="w-4 h-4" />
            )}
          </button>

          {/* Chat Input Field (Wide pill on right containing the 4-square grid icon) */}
          <form onSubmit={handleSendMessage} className="flex-1 min-w-[120px] flex items-center bg-[#202836] border border-slate-700/60 rounded-full px-2.5 py-1.5 focus-within:border-purple-500 transition-colors gap-2">
            {/* 4-Square Options Grid Icon (Visible only to Room Owner & Admins) */}
            {isMod && (
              <button
                type="button"
                onClick={() => setShowQuickToolbar(!showQuickToolbar)}
                className={`p-1 rounded flex items-center justify-center text-slate-300 hover:text-white transition-all active:scale-95 ${
                  showQuickToolbar ? 'text-amber-400 bg-amber-500/20' : 'hover:bg-slate-700/50'
                }`}
                title="شريط الأدوات والخيارات (الإدارة)"
              >
                <div className="grid grid-cols-2 gap-[2px] w-4 h-4 p-[1px] border border-current rounded-[3px]">
                  <div className="bg-current rounded-[1px]" />
                  <div className="bg-current rounded-[1px]" />
                  <div className="bg-current rounded-[1px]" />
                  <div className="bg-current rounded-[1px]" />
                </div>
              </button>
            )}

            <input
              type="text"
              value={chatMessage}
              onChange={(e) => setChatMessage(e.target.value)}
              placeholder="لنبدأ الدردشة الآن"
              className="w-full bg-transparent text-xs text-white placeholder-slate-400 focus:outline-none text-right"
            />
          </form>

        </div>
      </div>

      {/* Floating Animated Gift Banner */}
      {activeFloatingGift && (
        <div className="absolute top-20 left-4 right-4 z-50 pointer-events-none flex justify-center animate-in fade-in zoom-in duration-300">
          <div className="bg-slate-950/90 border-2 border-amber-400/80 rounded-full px-5 py-2.5 flex items-center gap-3 shadow-2xl backdrop-blur-md animate-pulse">
            <span className="text-4xl animate-bounce">{activeFloatingGift.gift.icon}</span>
            <div className="text-right">
              <p className="text-xs font-black text-amber-300">
                ✨ {activeFloatingGift.sender} أرسل {activeFloatingGift.gift.name} (x{activeFloatingGift.amount})!
              </p>
              <p className="text-[10px] text-purple-200 font-mono">
                بقيمة {((activeFloatingGift.gift.priceDiamonds || activeFloatingGift.gift.priceCoins || 100) * activeFloatingGift.amount).toLocaleString()} 💎
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Gift Selector Modal Overlay */}
      {showGiftSelector && (
        <GiftSelectorModal
          user={currentUser}
          seats={currentRoom.seats}
          onClose={() => setShowGiftSelector(false)}
          onOpenRecharge={() => {
            setShowGiftSelector(false);
            if (onOpenCoinStore) onOpenCoinStore();
          }}
          onUpdateCoins={(delta) => {
            const newCoins = Math.max(0, currentUser.coins + delta);
            setCurrentUser((prev) => ({ ...prev, coins: newCoins }));
            if (onUpdateUser) onUpdateUser({ coins: newCoins });
          }}
          onUpdateUserBalance={(newDiamonds, newXp, newLevel) => {
            const updated = { diamonds: newDiamonds, wealthXp: newXp, wealthLevel: newLevel };
            setCurrentUser((prev) => ({ ...prev, ...updated }));
            if (onUpdateUser) onUpdateUser(updated);
          }}
          onSendGift={(gift, recipient, amount) => {
            handleRichGiftSend(gift, recipient, amount);
          }}
        />
      )}

      {/* 5. SEAT MANAGEMENT POPUP MENU (لوحة التحكم بالمقاعد للمالك) */}
      {selectedSeatForAction && (
        <div className="absolute inset-0 z-40 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="w-80 bg-slate-900 border-2 border-purple-500/60 rounded-3xl p-4 space-y-3.5 text-right shadow-2xl relative overflow-hidden">
            {/* Top Bar */}
            <div className="flex items-center justify-between border-b border-purple-900/50 pb-2.5">
              <div className="flex items-center gap-1.5">
                <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span className="font-black text-xs text-amber-300">
                  لوحة إشراف المقعد رقم #{selectedSeatForAction.seatId}
                </span>
              </div>
              <button
                onClick={() => setSelectedSeatForAction(null)}
                className="text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {selectedSeatForAction.speakerUser ? (
              /* Occupied Seat Actions (خارات الكرسي المشغول) */
              <div className="space-y-2.5">
                <div className="flex items-center gap-2.5 p-2.5 bg-slate-800/90 border border-slate-700/60 rounded-2xl">
                  <img
                    src={selectedSeatForAction.speakerUser.avatar}
                    alt={selectedSeatForAction.speakerUser.name}
                    className="w-10 h-10 rounded-full object-cover border-2 border-amber-400"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-black text-xs text-white truncate">
                      {selectedSeatForAction.speakerUser.name}
                    </p>
                    <p className="text-[10px] text-amber-300 font-mono mt-0.5">
                      نقاط الدعم: {selectedSeatForAction.points || 0} ⭐
                    </p>
                  </div>
                </div>

                {/* Mute / Unmute Mic Button */}
                <button
                  onClick={() => handleToggleMuteSeat(selectedSeatForAction.seatId)}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 transition-colors border border-slate-700/50"
                >
                  <div className="flex items-center gap-2">
                    {selectedSeatForAction.isMuted ? <Mic className="w-4 h-4 text-emerald-400" /> : <MicOff className="w-4 h-4 text-amber-400" />}
                    <span>{selectedSeatForAction.isMuted ? 'إلغاء كتم المايك' : 'كتم صوت المايك (Mute Mic)'}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">إجباري</span>
                </button>

                {/* Kick to Audience Button */}
                <button
                  onClick={() => handleKickSeatUser(selectedSeatForAction.seatId)}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-xs font-bold text-amber-300 border border-amber-500/30 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <UserX className="w-4 h-4" />
                    <span>إنزال إلى المستمعين (Kick to Audience)</span>
                  </div>
                </button>

                {/* Ban / Kick Out Room Button */}
                <button
                  onClick={() => handleBanUserFromRoom(selectedSeatForAction.seatId)}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-rose-950/60 hover:bg-rose-900/80 text-xs font-bold text-rose-300 border border-rose-500/40 transition-colors shadow"
                >
                  <div className="flex items-center gap-2">
                    <UserMinus className="w-4 h-4 text-rose-400" />
                    <span>طرد نهائي من الغرفة (Ban / Kick Out)</span>
                  </div>
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                </button>
              </div>
            ) : (
              /* Empty Seat Actions (خيارات الكرسي الفارغ) */
              <div className="space-y-2.5">
                <p className="text-[11px] text-slate-300 font-medium">هذا المقعد شاغر حالياً. اختر إجراءً للتحكم:</p>

                {/* Lock / Unlock Seat Button */}
                <button
                  onClick={() => handleToggleLockSeat(selectedSeatForAction.seatId)}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl border text-xs font-bold transition-all ${
                    selectedSeatForAction.isLocked
                      ? 'bg-purple-950/80 border-purple-400 text-purple-200 hover:bg-purple-900'
                      : 'bg-slate-800/90 border-slate-700 text-slate-200 hover:bg-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {selectedSeatForAction.isLocked ? <Unlock className="w-4 h-4 text-purple-300" /> : <Lock className="w-4 h-4 text-amber-400" />}
                    <span>{selectedSeatForAction.isLocked ? 'فتح المقعد للجمهور (Unlock)' : 'تسكير / قفل المقعد (Lock Seat)'}</span>
                  </div>
                  <span className="text-[10px] opacity-70">
                    {selectedSeatForAction.isLocked ? '🔒 مقفل' : '🔓 مفتوح'}
                  </span>
                </button>

                {/* Invite Audience User to Seat Button */}
                <button
                  onClick={() => {
                    setTargetSeatForInvite(selectedSeatForAction.seatId);
                    setShowAudiencePicker(true);
                    setSelectedSeatForAction(null);
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg transition-all active:scale-95"
                >
                  <div className="flex items-center gap-2">
                    <UserPlus className="w-4 h-4" />
                    <span>دعوة مستخدم للمقعد (Invite User)</span>
                  </div>
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 6. AUDIENCE PICKER MODAL (قائمة اختيار المستمعين لإرسال دعوة) */}
      {showAudiencePicker && targetSeatForInvite !== null && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-slate-900 border-2 border-purple-500/60 rounded-3xl p-4 space-y-3 text-right shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-purple-900/50 pb-2.5">
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-amber-400" />
                <h3 className="font-black text-sm text-amber-200">
                  دعوة صعود للمقعد #{targetSeatForInvite}
                </h3>
              </div>
              <button
                onClick={() => setShowAudiencePicker(false)}
                className="text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-[11px] text-slate-300">اختر أحـد المستمعين لإرسال إشعار تنبيه صعود مباشر لشاشته:</p>

            <div className="max-h-64 overflow-y-auto space-y-2 pr-1 no-scrollbar">
              {audienceList.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center justify-between bg-slate-800/80 border border-slate-700/60 p-2.5 rounded-2xl hover:bg-slate-700/80 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <img
                      src={member.avatar}
                      alt={member.name}
                      className="w-9 h-9 rounded-full object-cover border border-amber-400/60"
                    />
                    <div>
                      <p className="text-xs font-bold text-white">{member.name}</p>
                      <span className="text-[9px] text-amber-300 font-mono">رتبة: {member.role}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleSendSeatInvite(member, targetSeatForInvite)}
                    className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-[11px] px-3 py-1.5 rounded-xl shadow active:scale-95 transition-transform flex items-center gap-1"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>إرسال دعوة</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 7. INVITATION POP-UP MODAL (تنبيه دعوة الصعود المنبثق في منتصف شاشة المستخدم) */}
      {pendingSeatInvite && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in zoom-in duration-300">
          <div className="w-full max-w-xs bg-gradient-to-b from-slate-900 via-purple-950 to-slate-950 border-2 border-amber-400 rounded-3xl p-5 text-center space-y-4 shadow-2xl relative overflow-hidden">
            {/* Ambient Spotlight */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-32 bg-amber-400/20 rounded-full blur-2xl pointer-events-none" />

            <div className="w-14 h-14 mx-auto rounded-full bg-gradient-to-tr from-amber-400 to-amber-200 text-slate-950 flex items-center justify-center shadow-xl ring-4 ring-amber-400/30 animate-bounce">
              <Mic className="w-7 h-7" />
            </div>

            <div className="space-y-1.5">
              <h3 className="font-black text-base text-amber-300 flex items-center justify-center gap-1.5">
                <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span>دعوة صعود للمقعد 🎙️</span>
              </h3>
              <p className="text-xs text-slate-200 leading-relaxed font-medium">
                يدعوك المضيف <span className="font-bold text-amber-300">{pendingSeatInvite.inviterName}</span> للصعود والتحدث على المقعد رقم <span className="font-mono text-cyan-300 font-bold">#{pendingSeatInvite.seatId}</span>
              </p>
            </div>

            {/* Accept / Reject Action Buttons */}
            <div className="grid grid-cols-2 gap-2.5 pt-2">
              <button
                onClick={handleAcceptInvite}
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-black text-xs py-2.5 rounded-xl shadow-lg active:scale-95 transition-all border border-emerald-400/40 flex items-center justify-center gap-1"
              >
                <Check className="w-4 h-4" />
                <span>قبول الدعوة</span>
              </button>

              <button
                onClick={handleRejectInvite}
                className="w-full bg-slate-800/80 hover:bg-rose-950/80 text-rose-300 border border-rose-500/50 font-bold text-xs py-2.5 rounded-xl shadow active:scale-95 transition-all flex items-center justify-center gap-1"
              >
                <X className="w-4 h-4" />
                <span>رفض الدعوة</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. PENDING MIC REQUESTS MODAL (قائمة الانتظار والطلبات للمالك) */}
      {showMicRequestsModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-slate-900 border-2 border-purple-500/60 rounded-3xl p-4 space-y-3 text-right shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-purple-900/50 pb-2.5">
              <div className="flex items-center gap-2">
                <Inbox className="w-5 h-5 text-amber-400" />
                <h3 className="font-black text-sm text-amber-200">
                  طلبات صعود المايك المعلقة ({pendingMicRequests.length})
                </h3>
              </div>
              <button
                onClick={() => setShowMicRequestsModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {pendingMicRequests.length === 0 ? (
              <div className="py-8 text-center text-slate-400 space-y-2">
                <Hand className="w-8 h-8 mx-auto text-slate-600" />
                <p className="text-xs font-bold">لا توجد طلبات صعود معلقة حالياً</p>
              </div>
            ) : (
              <div className="max-h-64 overflow-y-auto space-y-2 pr-1 no-scrollbar">
                {pendingMicRequests.map((req) => (
                  <div
                    key={req.id}
                    className="flex items-center justify-between bg-slate-800/80 border border-slate-700/60 p-2.5 rounded-2xl"
                  >
                    <div className="flex items-center gap-2.5">
                      <img
                        src={req.userAvatar}
                        alt={req.userName}
                        className="w-9 h-9 rounded-full object-cover border border-amber-400/60"
                      />
                      <div>
                        <p className="text-xs font-bold text-white">{req.userName}</p>
                        <p className="text-[10px] text-amber-300">يرغب بالصعود للمقعد #{req.requestedSeatId || 'أي مقعد'}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleApproveMicRequest(req.id)}
                        className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] px-2.5 py-1 rounded-lg shadow active:scale-95"
                      >
                        قبول
                      </button>
                      <button
                        onClick={() => handleRejectMicRequest(req.id)}
                        className="bg-rose-950 hover:bg-rose-900 border border-rose-500/50 text-rose-300 font-bold text-[10px] px-2.5 py-1 rounded-lg shadow active:scale-95"
                      >
                        رفض
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
      {/* Room Info BottomSheet Dialog */}
      {showRoomInfoModal && (
        <RoomInfoModal
          room={currentRoom}
          user={user}
          onClose={() => setShowRoomInfoModal(false)}
          onUpdateAnnouncement={(newAnn) => {
            setCurrentRoom((prev) => ({ ...prev, announcement: newAnn }));
            if (onUpdateRoomAnnouncement) {
              onUpdateRoomAnnouncement(currentRoom.id, newAnn);
            }
          }}
          onUpdateRoom={(updatedRoom) => {
            setCurrentRoom((prev) => ({ ...prev, ...updatedRoom }));
          }}
        />
      )}

      {/* Seat Layout Customization Modal (activity_seat_settings.xml) */}
      {showSeatSettingsModal && (
        <SeatGridSettingsModal
          currentLayout={currentRoom.seatLayout || { type: 'basic', count: currentRoom.seats.length }}
          userLevel={user.vipLevel || 5}
          onSave={handleSaveSeatLayout}
          onClose={() => setShowSeatSettingsModal(false)}
        />
      )}

      {/* Task Center Modal (مركز المهام) */}
      {showTaskCenter && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-[#120f24] border border-amber-500/40 rounded-3xl p-4 space-y-3 text-right shadow-2xl relative overflow-hidden">
            <div className="flex items-center justify-between border-b border-amber-500/20 pb-2">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-amber-400" />
                <h3 className="font-black text-sm text-amber-200">مركز المهام والمكافآت اليومية</h3>
              </div>
              <button onClick={() => setShowTaskCenter(false)} className="text-slate-400 hover:text-white p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-[11px] text-slate-300">أكمل المهام الصوتية اليومية واجمع الذهب والماس لرفع مستوى حسابك!</p>

            <div className="space-y-2">
              <div className="flex items-center justify-between bg-slate-900/80 border border-slate-800 p-2.5 rounded-2xl">
                <div>
                  <p className="text-xs font-bold text-white">تسجيل الدخول للغرفة</p>
                  <p className="text-[10px] text-amber-400 font-medium">مكافأة: +100 🪙 ذهب</p>
                </div>
                <button
                  onClick={() => showToast('🎉 تم استلام 100 ذهبة بنجاح!')}
                  className="bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-[11px] px-3 py-1 rounded-xl shadow active:scale-95 transition-transform"
                >
                  استلام
                </button>
              </div>

              <div className="flex items-center justify-between bg-slate-900/80 border border-slate-800 p-2.5 rounded-2xl">
                <div>
                  <p className="text-xs font-bold text-white">التحدث على المايك 3 دقائق</p>
                  <p className="text-[10px] text-amber-400 font-medium">مكافأة: +250 🪙 ذهب + 5 💎 ماس</p>
                </div>
                <button
                  onClick={() => showToast('🎉 تم استلام 250 ذهبة و 5 ماسات!')}
                  className="bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-[11px] px-3 py-1 rounded-xl shadow active:scale-95 transition-transform"
                >
                  استلام
                </button>
              </div>

              <div className="flex items-center justify-between bg-slate-900/80 border border-slate-800 p-2.5 rounded-2xl">
                <div>
                  <p className="text-xs font-bold text-white">إرسال هدية لأحد المستمعين</p>
                  <p className="text-[10px] text-purple-400 font-medium">مكافأة: +500 🪙 ذهب + شارة ملكية</p>
                </div>
                <button
                  onClick={() => {
                    setShowTaskCenter(false);
                    setShowGiftSelector(true);
                  }}
                  className="bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-[11px] px-3 py-1 rounded-xl border border-amber-500/30"
                >
                  ذهاب
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Lucky Bag Modal (حقيبة الحظ) */}
      {showLuckyBag && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-[#180d1b] border border-rose-500/40 rounded-3xl p-4 space-y-3 text-right shadow-2xl relative overflow-hidden">
            <div className="flex items-center justify-between border-b border-rose-500/20 pb-2">
              <div className="flex items-center gap-2">
                <Gift className="w-5 h-5 text-rose-400" />
                <h3 className="font-black text-sm text-rose-200">حقيبة الحظ والجوائز العشوائية</h3>
              </div>
              <button onClick={() => setShowLuckyBag(false)} className="text-slate-400 hover:text-white p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-[11px] text-slate-300">أوزع حقيبة الحظ داخل الغرفة الآن ليحصل المستمعين النشطين على عملات ذهبية عشوائية!</p>

            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => {
                  setShowLuckyBag(false);
                  showToast('👛 تم رمي حقيبة الحظ الفضية (500 ذهبة) في الغرفة!');
                }}
                className="bg-slate-900 border border-slate-700 hover:border-amber-400 p-2.5 rounded-2xl flex flex-col items-center gap-1 active:scale-95 transition-all cursor-pointer"
              >
                <span className="text-2xl">👛</span>
                <span className="text-xs font-bold text-white">حقيبة فضية</span>
                <span className="text-[10px] text-amber-300 font-mono">500 🪙</span>
              </button>

              <button
                onClick={() => {
                  setShowLuckyBag(false);
                  showToast('🎁 تم رمي حقيبة الحظ الذهبية (2000 ذهبة) في الغرفة!');
                }}
                className="bg-slate-900 border border-amber-500/50 hover:border-amber-400 p-2.5 rounded-2xl flex flex-col items-center gap-1 active:scale-95 transition-all cursor-pointer"
              >
                <span className="text-2xl">🎁</span>
                <span className="text-xs font-bold text-amber-300">حقيبة ذهبية</span>
                <span className="text-[10px] text-amber-300 font-mono">2000 🪙</span>
              </button>

              <button
                onClick={() => {
                  setShowLuckyBag(false);
                  showToast('👑 تم رمي حقيبة الحظ الملكية (5000 ذهبة) في الغرفة!');
                }}
                className="bg-gradient-to-b from-purple-900 to-rose-950 border border-pink-400 p-2.5 rounded-2xl flex flex-col items-center gap-1 active:scale-95 transition-all cursor-pointer"
              >
                <span className="text-2xl">👑</span>
                <span className="text-xs font-black text-pink-200">حقيبة ملكية</span>
                <span className="text-[10px] text-amber-300 font-mono">5000 🪙</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Share Modal (مشاركة) */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-[#121020] border border-purple-500/40 rounded-3xl p-4 space-y-3 text-right shadow-2xl relative overflow-hidden">
            <div className="flex items-center justify-between border-b border-purple-500/20 pb-2">
              <div className="flex items-center gap-2">
                <Share2 className="w-5 h-5 text-amber-300" />
                <h3 className="font-black text-sm text-amber-200">مشاركة الغرفة والدعوة</h3>
              </div>
              <button onClick={() => setShowShareModal(false)} className="text-slate-400 hover:text-white p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-[11px] text-slate-300">ادعُ أصدقاءك للانضمام فوراً لهذه الغرفة الصوتية المميزة!</p>

            <div className="grid grid-cols-4 gap-2 pt-1">
              <button
                onClick={() => {
                  setShowShareModal(false);
                  showToast('تم فتح واتساب لمشاركة الرابط 📱');
                }}
                className="flex flex-col items-center gap-1 p-2 rounded-2xl bg-emerald-900/40 border border-emerald-500/40 text-emerald-200 hover:bg-emerald-900/60 cursor-pointer"
              >
                <span className="text-xl">💬</span>
                <span className="text-[10px] font-bold">واتساب</span>
              </button>

              <button
                onClick={() => {
                  setShowShareModal(false);
                  showToast('تم فتح تليجرام لمشاركة الرابط ✈️');
                }}
                className="flex flex-col items-center gap-1 p-2 rounded-2xl bg-sky-900/40 border border-sky-500/40 text-sky-200 hover:bg-sky-900/60 cursor-pointer"
              >
                <span className="text-xl">✈️</span>
                <span className="text-[10px] font-bold">تليجرام</span>
              </button>

              <button
                onClick={() => {
                  navigator.clipboard?.writeText(window.location.href);
                  setShowShareModal(false);
                  showToast('📋 تم نسخ رابط الغرفة بنجاح!');
                }}
                className="flex flex-col items-center gap-1 p-2 rounded-2xl bg-slate-800 border border-slate-700 text-slate-200 hover:bg-slate-700 cursor-pointer"
              >
                <Copy className="w-5 h-5 text-amber-300" />
                <span className="text-[10px] font-bold">نسخ الرابط</span>
              </button>

              <button
                onClick={() => {
                  setShowShareModal(false);
                  showToast('📣 تم إرسال دعوة للأصدقاء المتابعين بنجاح!');
                }}
                className="flex flex-col items-center gap-1 p-2 rounded-2xl bg-purple-900/40 border border-purple-500/40 text-purple-200 hover:bg-purple-900/60 cursor-pointer"
              >
                <Users className="w-5 h-5 text-pink-300" />
                <span className="text-[10px] font-bold">دعوة أصدقاء</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Music Player Modal (موسيقى) */}
      {showMusicModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-[#120f21] border border-purple-500/40 rounded-3xl p-4 space-y-3 text-right shadow-2xl relative overflow-hidden">
            <div className="flex items-center justify-between border-b border-purple-500/20 pb-2">
              <div className="flex items-center gap-2">
                <Music className="w-5 h-5 text-purple-300" />
                <h3 className="font-black text-sm text-purple-200">مستعرض الموسيقى وخلفية الصوت</h3>
              </div>
              <button onClick={() => setShowMusicModal(false)} className="text-slate-400 hover:text-white p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-[11px] text-slate-300">اختر مقطعاً صوتياً ليبث كخلفية موسيقية للأعضاء داخل الغرفة الصوتية:</p>

            <div className="space-y-2">
              {[
                { name: 'تقاسيم عود شرقي هادئ', dur: '03:45', icon: '🪕' },
                { name: 'ريمكس نغمات سهرة وطرب', dur: '04:20', icon: '🎧' },
                { name: 'موسيقى روقان واسترخاء لوفي', dur: '05:10', icon: '☕' },
              ].map((track, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    setIsMusicPlaying(true);
                    setShowMusicModal(false);
                    showToast(`🎵 تم تشغيل ${track.name} خلفية للغرفة!`);
                  }}
                  className="flex items-center justify-between bg-slate-900/80 border border-slate-800 hover:border-purple-500/50 p-2.5 rounded-2xl cursor-pointer active:scale-95 transition-all"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{track.icon}</span>
                    <span className="text-xs font-bold text-white">{track.name}</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">{track.dur}</span>
                </div>
              ))}

              <div
                onClick={() => {
                  setIsMusicPlaying(true);
                  setShowMusicModal(false);
                  showToast('📁 تم اختيار ملف الموسيقى من الهاتف وبثه للغرفة!');
                }}
                className="flex items-center justify-center gap-2 bg-purple-900/40 border border-purple-500/40 hover:bg-purple-900/60 p-2.5 rounded-2xl cursor-pointer text-purple-200 font-bold text-xs"
              >
                <span>📂 اختيار ملف صوتي من جهاز الهاتف</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Video Broadcast Setup Modal (إعدادات وبدء بث الفيديو) */}
      {showVideoBroadcastModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in zoom-in duration-200">
          <div className="w-full max-w-sm bg-[#110e1f] border border-rose-500/50 rounded-3xl p-4 space-y-4 text-right shadow-2xl relative overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-rose-500/30 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-rose-600/30 border border-rose-500 flex items-center justify-center text-rose-300">
                  <Video className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-sm text-rose-200">بث فيديو مباشر 🎥</h3>
                  <p className="text-[10px] text-slate-400">إعدادات الكاميرا وجودة الفيديو للمشاهدين</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowVideoBroadcastModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-full hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Camera Preview Box */}
            <div className="relative w-full h-44 bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-inner flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover transform ${isFrontCamera ? 'scale-x-[-1]' : ''} ${
                  videoFilter === 'beauty' ? 'brightness-110 contrast-105 saturate-110' :
                  videoFilter === 'neon' ? 'hue-rotate-90 brightness-125' :
                  videoFilter === 'vintage' ? 'sepia contrast-120' : ''
                }`}
              />

              {/* Camera Switch Floating Button */}
              <button
                type="button"
                onClick={() => setIsFrontCamera(!isFrontCamera)}
                className="absolute top-2 left-2 bg-black/70 hover:bg-black text-white px-2.5 py-1 rounded-full border border-white/20 text-[10px] font-bold flex items-center gap-1 backdrop-blur-sm cursor-pointer"
              >
                <RotateCcw className="w-3 h-3 text-amber-300" />
                <span>{isFrontCamera ? 'كاميرا أماميّة' : 'كاميرا خلفيّة'}</span>
              </button>

              <div className="absolute bottom-2 right-2 bg-rose-600/90 text-white text-[9px] font-black px-2 py-0.5 rounded-full border border-rose-400">
                HD 1080p 60FPS
              </div>
            </div>

            {/* Filter Selector */}
            <div className="space-y-1.5">
              <label className="block text-[11px] font-bold text-slate-300">فلتر وتجميل الصورة (Beauty Filters)</label>
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { id: 'beauty', label: 'تجميل ✨' },
                  { id: 'natural', label: 'طبيعي 🌿' },
                  { id: 'neon', label: 'نيون 🌆' },
                  { id: 'vintage', label: 'كلاسيك 🎞️' },
                ].map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setVideoFilter(f.id as any)}
                    className={`py-1.5 px-2 rounded-xl text-[10px] font-bold border transition-all cursor-pointer ${
                      videoFilter === f.id
                        ? 'bg-rose-600 text-white border-rose-400 shadow-md'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Start Video Button */}
            <button
              type="button"
              onClick={() => {
                setIsVideoBroadcasting(true);
                setShowVideoBroadcastModal(false);
                showToast('🎥 تم تشغيل بث الفيديو المباشر بنجاح!');
              }}
              className="w-full py-3 bg-gradient-to-r from-rose-600 via-red-500 to-amber-500 hover:from-rose-500 hover:to-amber-400 text-white font-black text-xs rounded-2xl shadow-xl shadow-rose-950/80 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Video className="w-4 h-4" />
              <span>بدء بث الفيديو الآن 🎥</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
