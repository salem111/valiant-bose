import React, { useState } from 'react';
import { UserProfile, WithdrawalPackage, WithdrawalGateway, WithdrawalRequest } from '../types';
import {
  X,
  Wallet,
  ArrowLeftRight,
  ShieldCheck,
  CheckCircle2,
  DollarSign,
  Building2,
  Smartphone,
  Globe,
  Clock,
  Sparkles,
  AlertCircle,
  Coins,
  Gem,
  Lock,
  ArrowDownLeft,
  ChevronLeft,
} from 'lucide-react';

interface WithdrawalModalProps {
  user: UserProfile;
  withdrawalRequests: WithdrawalRequest[];
  onClose: () => void;
  onUpdateDiamonds: (delta: number) => void;
  onUpdateCoins: (delta: number) => void;
  onSubmitWithdrawalRequest: (req: WithdrawalRequest) => void;
}

export const WITHDRAWAL_PACKAGES: WithdrawalPackage[] = [
  { id: 'wp-1', diamondsCount: 50000, usdAmount: 10.0, badge: 'الحد الأدنى للسحب ⚡' },
  { id: 'wp-2', diamondsCount: 100000, usdAmount: 20.0 },
  { id: 'wp-3', diamondsCount: 250000, usdAmount: 50.0, popular: true, badge: 'الأكثر طلباً 🔥' },
  { id: 'wp-4', diamondsCount: 500000, usdAmount: 100.0, badge: 'باقة المذيع VIP' },
  { id: 'wp-5', diamondsCount: 1000000, usdAmount: 200.0 },
  { id: 'wp-6', diamondsCount: 2500000, usdAmount: 500.0, badge: 'باقة الحوت 💎' },
];

export interface RegionGatewayOption {
  id: WithdrawalGateway;
  title: string;
  regionCategory: 'gulf' | 'levant_egypt' | 'global';
  regionBadge: string;
  icon: string;
  description: string;
  inputLabel: string;
  placeholder: string;
  requiresExtraDetails?: boolean;
}

export const PAYMENT_GATEWAYS: RegionGatewayOption[] = [
  // GULF COUNTRIES (0% TAX DIRECT IBAN)
  {
    id: 'bank_transfer',
    title: 'حوالة بنكية مباشرة (Bank IBAN)',
    regionCategory: 'gulf',
    regionBadge: 'دول الخليج (السعودية، الإمارات، قطر، الكويت، عمان، البحرين)',
    icon: '🏦',
    description: 'تحويل بنكي مباشر بدون أي استقطاعات ضريبية (0% ضريبة دخل شخصي)',
    inputLabel: 'رقم الـ IBAN الدولي الحقيقي (International IBAN)',
    placeholder: 'SA00 0000 0000 0000 0000 0000',
    requiresExtraDetails: true,
  },
  // LEVANT & EGYPT (MOBILE WALLETS & INSTAPAY)
  {
    id: 'zain_cash',
    title: 'زين كاش (Zain Cash JO / IQ)',
    regionCategory: 'levant_egypt',
    regionBadge: 'الأردن والعراق',
    icon: '📱',
    description: 'محفظة زين كاش الوطنية - تحويل سريع ومعفي من الضرائب',
    inputLabel: 'رقم الهاتف المربوط بمحفظة زين كاش',
    placeholder: '079XXXXXXX (الأردن) أو 078XXXXXXX (العراق)',
  },
  {
    id: 'orange_money',
    title: 'أورانج ماني (Orange Money)',
    regionCategory: 'levant_egypt',
    regionBadge: 'الأردن',
    icon: '🍊',
    description: 'سحب كاش مباشر عبر رقم محفظة أورانج ماني الأردنية',
    inputLabel: 'رقم محفظة Orange Money',
    placeholder: '077XXXXXXX',
  },
  {
    id: 'cliq',
    title: 'نظام كليك الفوري (CliQ Jordan)',
    regionCategory: 'levant_egypt',
    regionBadge: 'الأردن',
    icon: '⚡',
    description: 'تحويل فوري لحظي 24/7 عبر اسم المستخدم (Alias) أو رقم الهاتف',
    inputLabel: 'معرف كليك (CliQ Alias) أو رقم الهاتف المربوط',
    placeholder: 'اسم المستخدم أو 079XXXXXXX',
  },
  {
    id: 'vodafone_cash',
    title: 'فودافون كاش (Vodafone Cash)',
    regionCategory: 'levant_egypt',
    regionBadge: 'مصر',
    icon: '🔴',
    description: 'تحويل مباشر وسريع على محفظة فودافون كاش مصر',
    inputLabel: 'رقم محفظة فودافون كاش',
    placeholder: '010XXXXXXXX',
  },
  {
    id: 'instapay',
    title: 'انستا باي (InstaPay Egypt)',
    regionCategory: 'levant_egypt',
    regionBadge: 'مصر',
    icon: '🟢',
    description: 'تحويل لحظي مباشر للبنك أو الحساب عبر InstaPay',
    inputLabel: 'عنوان الدفع اللحظي (IPA) أو رقم الهاتف',
    placeholder: 'user@instapay أو 011XXXXXXXX',
  },
  // GLOBAL CRYPTO & E-WALLETS
  {
    id: 'usdt_trc20',
    title: 'العملة الرقمية (USDT TRC-20)',
    regionCategory: 'global',
    regionBadge: 'جميع دول العالم 🌍',
    icon: '₮',
    description: 'سحب إلكتروني مشفر عبر شبكة TRC-20 بعمولة ثابتة $1 فقط مهما بلغ المبلغ',
    inputLabel: 'عنوان المحفظة الرقمية (TRC-20 Wallet Address)',
    placeholder: 'TXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',
  },
  {
    id: 'paypal',
    title: 'بايبال (PayPal)',
    regionCategory: 'global',
    regionBadge: 'جميع دول العالم 🌍',
    icon: '🌐',
    description: 'تحويل عالمي إلكتروني لحساب PayPal الخاص بك',
    inputLabel: 'البريد الإلكتروني لحساب PayPal',
    placeholder: 'example@email.com',
  },
  {
    id: 'payoneer',
    title: 'بايونير (Payoneer)',
    regionCategory: 'global',
    regionBadge: 'جميع دول العالم 🌍',
    icon: '💳',
    description: 'سحب المبالغ الكبيرة لصناع المحتوى والمذيعين',
    inputLabel: 'بريد حساب Payoneer',
    placeholder: 'user@payoneer.com',
  },
];

export const WithdrawalModal: React.FC<WithdrawalModalProps> = ({
  user,
  withdrawalRequests,
  onClose,
  onUpdateDiamonds,
  onUpdateCoins,
  onSubmitWithdrawalRequest,
}) => {
  const [activeTab, setActiveTab] = useState<'withdraw' | 'exchange' | 'history'>('withdraw');

  // Withdrawal Selection State
  const [selectedPkg, setSelectedPkg] = useState<WithdrawalPackage | null>(null);
  const [regionFilter, setRegionFilter] = useState<'all' | 'gulf' | 'levant_egypt' | 'global'>('all');
  const [selectedGateway, setSelectedGateway] = useState<WithdrawalGateway | null>('zain_cash');
  const [accountDetailInput, setAccountDetailInput] = useState('');
  const [beneficiaryNameInput, setBeneficiaryNameInput] = useState('');
  const [bankNameInput, setBankNameInput] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState(false);

  // Diamond Exchange State
  const [exchangeDiamonds, setExchangeDiamonds] = useState<number>(100);
  const [isExchanging, setIsExchanging] = useState(false);
  const [exchangeSuccessMsg, setExchangeSuccessMsg] = useState<string | null>(null);

  // Conversion calculations
  // Exchange Rate: 5000 Diamonds = 1 USD
  const estimatedUsdValue = (user.diamonds / 5000).toFixed(2);

  const handleSelectPackage = (pkg: WithdrawalPackage) => {
    setSelectedPkg(pkg);
    setSubmissionSuccess(false);
  };

  const handleSubmitWithdrawal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPkg || !selectedGateway) return;

    if (user.diamonds < selectedPkg.diamondsCount) {
      alert(`رصيدك الحالي (${user.diamonds} ألماسة) غير كافٍ لسحب حزمة ${selectedPkg.diamondsCount.toLocaleString()} ألماسة!`);
      return;
    }

    if (!accountDetailInput.trim()) {
      alert('يرجى كتابة رقم المحفظة أو البريد الإلكتروني الخاص بجهة السحب!');
      return;
    }

    const gatewayObj = PAYMENT_GATEWAYS.find((g) => g.id === selectedGateway);

    setIsSubmitting(true);

    setTimeout(() => {
      // 1. Deduct diamonds immediately
      onUpdateDiamonds(-selectedPkg.diamondsCount);

      // 2. Create withdrawal request
      const newRequest: WithdrawalRequest = {
        id: `REQ-${Math.floor(100000 + Math.random() * 900000)}`,
        userId: user.id,
        userName: user.name,
        userAvatar: user.avatar,
        diamondsAmount: selectedPkg.diamondsCount,
        usdAmount: selectedPkg.usdAmount,
        gateway: selectedGateway,
        gatewayTitle: gatewayObj?.title || selectedGateway,
        accountDetails: {
          phoneOrEmailOrIban: accountDetailInput.trim(),
          beneficiaryName: beneficiaryNameInput.trim() || user.name,
          bankName: bankNameInput.trim() || 'المحفظة الإلكترونية',
        },
        status: 'PENDING',
        createdAt: new Date().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }),
      };

      onSubmitWithdrawalRequest(newRequest);
      setIsSubmitting(false);
      setSubmissionSuccess(true);
    }, 1500);
  };

  const handleExecuteExchange = () => {
    if (exchangeDiamonds <= 0) return;
    if (user.diamonds < exchangeDiamonds) {
      alert('رصيدك من الألماس غير كافٍ للاستبدال!');
      return;
    }

    setIsExchanging(true);

    setTimeout(() => {
      // 1 Diamond = 1 Golden Coin + 10% Bonus
      const coinsToReceive = Math.floor(exchangeDiamonds * 1.1);

      onUpdateDiamonds(-exchangeDiamonds);
      onUpdateCoins(coinsToReceive);

      setIsExchanging(false);
      setExchangeSuccessMsg(`🎉 تم استبدال ${exchangeDiamonds.toLocaleString()} ألماسة بنجاح إلى ${coinsToReceive.toLocaleString()} عملة ذهبية مع بونص 10%!`);
      setTimeout(() => setExchangeSuccessMsg(null), 4000);
    }, 1000);
  };

  const activeGatewayObj = PAYMENT_GATEWAYS.find((g) => g.id === selectedGateway);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 dir-rtl text-right select-none font-sans">
      <div className="w-full max-w-2xl bg-slate-900 border-2 border-amber-500/40 rounded-3xl p-4 sm:p-5 shadow-2xl space-y-4 text-white max-h-[92vh] overflow-y-auto animate-in zoom-in-95 duration-200">
        {/* HEADER */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-emerald-700 text-slate-950 flex items-center justify-center font-black shadow-xl">
              <DollarSign className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-black text-base sm:text-lg text-amber-300">سحب الأرباح والألماس (Cash Withdrawal) 💎💵</h2>
              <p className="text-[11px] text-slate-400">تحويل الماسات لكاش أو استبدالها بعملات مع حماية كاملة</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 1. TOP BALANCE CARD (البطاقة العلوية الملونة) */}
        <div className="bg-gradient-to-r from-cyan-950 via-slate-900 to-indigo-950 p-4 rounded-2xl border border-cyan-500/40 shadow-2xl space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center justify-center text-lg">
                💎
              </div>
              <div>
                <span className="text-[11px] text-slate-300 font-bold block">إجمالي رصيد الألماس المتاح للسحب كاش</span>
                <div className="flex items-baseline gap-2">
                  <span className="font-mono text-xl sm:text-2xl font-black text-cyan-300">
                    {user.diamonds.toLocaleString()}
                  </span>
                  <span className="text-xs text-slate-400">ألماسة</span>
                </div>
              </div>
            </div>

            {/* USD Conversion Badge */}
            <div className="bg-emerald-950/80 border border-emerald-500/50 p-2.5 rounded-xl text-center shadow-lg">
              <span className="text-[10px] text-emerald-300 font-bold block">القيمة التقديرية كاش</span>
              <span className="font-mono text-base font-black text-emerald-400">
                ${estimatedUsdValue} USD
              </span>
            </div>
          </div>

          {/* Rate & Policy Notice */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-800 text-[10px] text-slate-300 font-bold">
            <span className="text-cyan-300 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              سعر الصرف الثابت: 5,000 ألماسة = $1.00 USD (معفي تماماً من ضرائب الدخل)
            </span>
            <span className="text-amber-400 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 shrink-0" />
              معالجة وسحب الأموال خلال 24 - 48 ساعة عمل رسمية
            </span>
          </div>
        </div>

        {/* 2. CONTROL NAVIGATION TABS */}
        <div className="grid grid-cols-3 gap-1 bg-slate-950 p-1.5 rounded-2xl border border-slate-800">
          <button
            onClick={() => setActiveTab('withdraw')}
            className={`py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'withdraw'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md scale-102'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>سحب الأموال كاش</span>
          </button>

          <button
            onClick={() => setActiveTab('exchange')}
            className={`py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'exchange'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md scale-102'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ArrowLeftRight className="w-4 h-4" />
            <span>استبدال للعملات 🪙</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`py-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'history'
                ? 'bg-slate-800 text-amber-300 shadow-md scale-102 border border-amber-500/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>سجل الطلبات ({withdrawalRequests.length})</span>
          </button>
        </div>

        {/* TAB 1: CASH WITHDRAWAL */}
        {activeTab === 'withdraw' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            {submissionSuccess ? (
              <div className="bg-slate-950 p-6 rounded-2xl border-2 border-emerald-500/60 text-center space-y-3 animate-in zoom-in-95">
                <div className="w-14 h-14 bg-emerald-500 text-slate-950 rounded-full flex items-center justify-center mx-auto shadow-xl">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="font-black text-lg text-emerald-300">تم تقديم طلب السحب بنجاح! 🚀</h3>
                <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                  تم خصم قيمة الحزمة وحجزها كطلب معلق (PENDING). سيتم مراجعة رقم الحساب وتحويل مبلغ{' '}
                  <span className="font-bold text-amber-300">${selectedPkg?.usdAmount} USD</span> إلى{' '}
                  <span className="font-bold text-cyan-300">{activeGatewayObj?.title}</span> خلال أقصى حد 24 ساعة.
                </p>
                <div className="pt-2 flex justify-center gap-3">
                  <button
                    onClick={() => {
                      setSubmissionSuccess(false);
                      setSelectedPkg(null);
                    }}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl"
                  >
                    تقديم طلب سحب آخر
                  </button>
                  <button
                    onClick={() => setActiveTab('history')}
                    className="px-4 py-2 bg-emerald-500 text-slate-950 font-bold text-xs rounded-xl"
                  >
                    متابعة حالة الطلب في السجل
                  </button>
                </div>
              </div>
            ) : !selectedPkg ? (
              /* Step 1: Select Withdrawal Package Tiers */
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                  <span>اختر حزمة السحب الكاش المناسبة (Withdrawal Packages):</span>
                  <span className="text-amber-400 text-[11px]">حدود سحب ثابتة لسهولة المعالجة</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {WITHDRAWAL_PACKAGES.map((pkg) => {
                    const isAffordable = user.diamonds >= pkg.diamondsCount;

                    return (
                      <div
                        key={pkg.id}
                        onClick={() => handleSelectPackage(pkg)}
                        className={`p-3.5 rounded-2xl border-2 transition-all cursor-pointer relative overflow-hidden flex items-center justify-between ${
                          pkg.popular
                            ? 'bg-gradient-to-r from-slate-900 via-amber-950 to-slate-900 border-amber-500 shadow-xl scale-101'
                            : 'bg-slate-950 border-slate-800 hover:border-slate-600'
                        } ${!isAffordable ? 'opacity-70' : ''}`}
                      >
                        {pkg.badge && (
                          <span className="absolute top-0 left-0 bg-amber-500 text-slate-950 font-black text-[9px] px-2.5 py-0.5 rounded-br-xl shadow">
                            {pkg.badge}
                          </span>
                        )}

                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-xl shrink-0">
                            💎
                          </div>
                          <div>
                            <div className="font-black text-sm text-cyan-300">
                              {pkg.diamondsCount.toLocaleString()} ألماسة
                            </div>
                            <div className="text-[10px] text-slate-400">
                              {isAffordable ? 'رصيدك يكفي للسحب' : 'رصيدك الحالي أقل من المطلوب'}
                            </div>
                          </div>
                        </div>

                        <div className="text-left">
                          <span className="font-mono font-black text-lg text-emerald-400 block">
                            ${pkg.usdAmount.toFixed(2)}
                          </span>
                          <span className="text-[9px] text-slate-400">USD Cash</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              /* Step 2: Choose Payment Gateway & Enter Account Info */
              <form onSubmit={handleSubmitWithdrawal} className="space-y-4 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <button
                    type="button"
                    onClick={() => setSelectedPkg(null)}
                    className="text-xs font-bold text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    ← تغيير الحزمة المختارة (${selectedPkg.usdAmount} USD)
                  </button>
                  <span className="text-xs font-black text-cyan-300">
                    الحزمة: {selectedPkg.diamondsCount.toLocaleString()} 💎 تعادل ${selectedPkg.usdAmount} USD
                  </span>
                </div>

                {/* Regional Gateways Selection Header & Filter Tabs */}
                <div className="space-y-2.5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <label className="block text-xs font-bold text-slate-200">
                      اختر الوسيلة المحلية المناسبة لبلدك (0% ضريبة تحويل):
                    </label>
                    <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-[11px]">
                      <button
                        type="button"
                        onClick={() => setRegionFilter('all')}
                        className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                          regionFilter === 'all' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        الكل
                      </button>
                      <button
                        type="button"
                        onClick={() => setRegionFilter('gulf')}
                        className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                          regionFilter === 'gulf' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        دول الخليج 🌴
                      </button>
                      <button
                        type="button"
                        onClick={() => setRegionFilter('levant_egypt')}
                        className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                          regionFilter === 'levant_egypt' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        بلاد الشام ومصر 📱
                      </button>
                      <button
                        type="button"
                        onClick={() => setRegionFilter('global')}
                        className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                          regionFilter === 'global' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        USDT عالمي 🌍
                      </button>
                    </div>
                  </div>

                  {/* Filtered Gateways Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {PAYMENT_GATEWAYS.filter(
                      (gw) => regionFilter === 'all' || gw.regionCategory === regionFilter
                    ).map((gw) => (
                      <button
                        key={gw.id}
                        type="button"
                        onClick={() => {
                          setSelectedGateway(gw.id);
                          setAccountDetailInput('');
                        }}
                        className={`p-3 rounded-2xl border-2 text-right transition-all cursor-pointer relative overflow-hidden ${
                          selectedGateway === gw.id
                            ? 'bg-emerald-950/80 border-emerald-500 text-white shadow-xl ring-2 ring-emerald-500/30'
                            : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2 font-black text-xs">
                            <span className="text-lg">{gw.icon}</span>
                            <span className="truncate">{gw.title}</span>
                          </div>
                          <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-slate-950 border border-slate-800 text-amber-300">
                            {gw.regionCategory === 'gulf' ? '🌴 الخليج' : gw.regionCategory === 'levant_egypt' ? '📱 محفظة محلي' : '🌍 USDT / eBank'}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1.5 leading-tight">{gw.description}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Active Gateway Detailed Inputs */}
                {activeGatewayObj && (
                  <div className="space-y-3 bg-slate-900 p-3.5 rounded-2xl border border-slate-800 animate-in fade-in">
                    <div className="flex items-center gap-2 text-xs font-black text-amber-300 border-b border-slate-800 pb-2">
                      <span>{activeGatewayObj.icon}</span>
                      <span>{activeGatewayObj.title}</span>
                      <span className="text-[10px] text-slate-400 font-normal mr-auto">({activeGatewayObj.regionBadge})</span>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold text-slate-200 mb-1">
                        {activeGatewayObj.inputLabel} *
                      </label>
                      <input
                        type="text"
                        required
                        value={accountDetailInput}
                        onChange={(e) => setAccountDetailInput(e.target.value)}
                        placeholder={activeGatewayObj.placeholder}
                        className="w-full bg-slate-950 border border-slate-700 text-xs rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-400 font-mono"
                      />
                    </div>

                    {/* Extra details for Bank Transfer or Wallets */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-300 mb-1">اسم صاحب الحساب / المستفيد الثلاثي *</label>
                        <input
                          type="text"
                          required
                          value={beneficiaryNameInput}
                          onChange={(e) => setBeneficiaryNameInput(e.target.value)}
                          placeholder="مثال: سليم محمد أحمد"
                          className="w-full bg-slate-950 border border-slate-700 text-xs rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-400"
                        />
                      </div>

                      {activeGatewayObj.requiresExtraDetails && (
                        <div>
                          <label className="block text-[11px] font-bold text-slate-300 mb-1">اسم البنك / الفرع *</label>
                          <input
                            type="text"
                            required
                            value={bankNameInput}
                            onChange={(e) => setBankNameInput(e.target.value)}
                            placeholder="مثال: مصرف الراجحي / البنك الأهلي"
                            className="w-full bg-slate-950 border border-slate-700 text-xs rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-400"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Submit Order Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 text-slate-950 font-black text-sm rounded-xl shadow-xl hover:brightness-110 active:scale-95 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <DollarSign className="w-5 h-5" />
                  <span>
                    {isSubmitting
                      ? 'جاري تأكيد السحب وتشفير البيانات...'
                      : `تأكيد طلب السحب بقيمة $${selectedPkg.usdAmount} USD (${selectedPkg.diamondsCount.toLocaleString()} 💎)`}
                  </span>
                </button>
              </form>
            )}
          </div>
        )}

        {/* TAB 2: CURRENCY EXCHANGE (DIAMONDS -> COINS) */}
        {activeTab === 'exchange' && (
          <div className="space-y-4 bg-slate-950 p-4 rounded-2xl border border-slate-800 animate-in fade-in duration-200">
            <div className="text-center space-y-1">
              <h3 className="font-black text-base text-amber-300">إعادة تدوير واستبدال الماس للعملات (Recycling Engine) 🪙</h3>
              <p className="text-xs text-slate-400">حول أرباحك من الماس فورياً إلى عملات ذهبية لاستخدامها في الألعاب وإرسال الهدايا مع بونص 10% مجاناً!</p>
            </div>

            {exchangeSuccessMsg && (
              <div className="bg-emerald-950 border border-emerald-500 text-emerald-300 p-3 rounded-2xl text-xs font-bold text-center animate-in zoom-in">
                {exchangeSuccessMsg}
              </div>
            )}

            {/* Interactive Calculator */}
            <div className="bg-slate-900 p-4 rounded-2xl border border-amber-500/30 space-y-4">
              <div className="grid grid-cols-2 gap-3 items-center">
                {/* Input Diamonds */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1">الماس المطلوب تحويله (💎):</label>
                  <input
                    type="number"
                    min="10"
                    max={user.diamonds}
                    value={exchangeDiamonds}
                    onChange={(e) => setExchangeDiamonds(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-700 text-amber-300 font-mono font-black text-lg p-2.5 rounded-xl text-center focus:outline-none focus:border-amber-400"
                  />
                </div>

                {/* Received Coins */}
                <div className="text-center bg-slate-950 p-2.5 rounded-xl border border-amber-500/30">
                  <span className="text-[10px] text-slate-400 font-bold block">ستحصل على (مع بونص 10%):</span>
                  <span className="font-mono text-xl font-black text-amber-400 block">
                    {Math.floor(exchangeDiamonds * 1.1).toLocaleString()} 🪙
                  </span>
                </div>
              </div>

              {/* Quick Presets */}
              <div className="flex items-center gap-1.5 justify-center">
                {[10, 50, 100, 500, 1000].map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setExchangeDiamonds(val)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold ${
                      exchangeDiamonds === val ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {val} 💎
                  </button>
                ))}
              </div>

              <button
                onClick={handleExecuteExchange}
                disabled={isExchanging || exchangeDiamonds <= 0 || user.diamonds < exchangeDiamonds}
                className="w-full py-3.5 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-500 text-slate-950 font-black text-sm rounded-xl shadow-lg hover:brightness-110 active:scale-95 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <ArrowLeftRight className="w-5 h-5" />
                <span>
                  {isExchanging ? 'جاري الاستبدال المباشر...' : `استبدال ${exchangeDiamonds} ألماسة لـ ${Math.floor(exchangeDiamonds * 1.1)} عملة`}
                </span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: TRANSACTION STATUS & HISTORY */}
        {activeTab === 'history' && (
          <div className="space-y-3 animate-in fade-in duration-200">
            <h3 className="font-bold text-xs text-slate-300">دورة حياة وسجل طلبات السحب (Withdrawal Status History):</h3>

            {withdrawalRequests.length === 0 ? (
              <div className="bg-slate-950 p-8 rounded-2xl border border-slate-800 text-center text-slate-400 text-xs space-y-2">
                <Clock className="w-8 h-8 text-slate-600 mx-auto" />
                <p>لا توجد طلبات سحب سابقة لحسابك حالياً.</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-72 overflow-y-auto">
                {withdrawalRequests.map((req) => (
                  <div
                    key={req.id}
                    className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex items-center justify-between text-xs space-y-1"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-black text-white">{req.gatewayTitle}</span>
                        <span className="font-mono text-[10px] text-slate-400">({req.id})</span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        الحساب: {req.accountDetails.phoneOrEmailOrIban}
                      </div>
                      <div className="text-[10px] text-slate-500">{req.createdAt}</div>
                    </div>

                    <div className="text-left">
                      <div className="font-mono font-black text-emerald-400 text-sm">${req.usdAmount} USD</div>
                      <div className="text-[10px] text-cyan-300 font-mono">{req.diamondsAmount.toLocaleString()} 💎</div>

                      {/* Status Badges */}
                      <span
                        className={`inline-block text-[9px] font-black px-2.5 py-0.5 rounded-full mt-1 border ${
                          req.status === 'PENDING'
                            ? 'bg-amber-950 text-amber-300 border-amber-500/50 animate-pulse'
                            : req.status === 'PROCESSING'
                            ? 'bg-indigo-950 text-indigo-300 border-indigo-500/50'
                            : req.status === 'SUCCESS'
                            ? 'bg-emerald-950 text-emerald-300 border-emerald-500/50'
                            : 'bg-rose-950 text-rose-300 border-rose-500/50'
                        }`}
                      >
                        {req.status === 'PENDING'
                          ? 'قيد الانتظار (PENDING)'
                          : req.status === 'PROCESSING'
                          ? 'قيد المعالجة (PROCESSING)'
                          : req.status === 'SUCCESS'
                          ? 'تم التحويل بنجاح (SUCCESS)'
                          : 'مرفوض/تمت الإعادة (REJECTED)'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
