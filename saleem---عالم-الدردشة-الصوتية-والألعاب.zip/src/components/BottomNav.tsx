import React from 'react';
import { MainTab } from '../types';
import { Home, MessageSquare, Video, Users, User } from 'lucide-react';

interface BottomNavProps {
  activeTab: MainTab;
  onTabChange: (tab: MainTab) => void;
  onOpenLiveStream: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  onOpenLiveStream,
}) => {
  const NAV_ITEMS = [
    { id: 'home', label: 'الرئيسية', icon: Home, isCentral: false },
    { id: 'chats', label: 'الدردشات', icon: MessageSquare, isCentral: false },
    { id: 'plus', label: 'بث لايف', icon: Video, isCentral: true },
    { id: 'friends', label: 'الأصدقاء', icon: Users, isCentral: false },
    { id: 'profile', label: 'حسابي', icon: User, isCentral: false },
  ] as const;

  return (
    <nav id="saleem-bottom-navigation" className="fixed bottom-0 left-0 right-0 z-30 bg-slate-950/95 backdrop-blur-md border-t border-rose-500/20 px-2 py-2 text-white">
      <div className="max-w-md mx-auto flex items-center justify-around relative">
        {NAV_ITEMS.map((item) => {
          if (item.isCentral) {
            return (
              <div key={item.id} className="relative -top-5 flex flex-col items-center">
                <button
                  onClick={onOpenLiveStream}
                  className="w-14 h-14 rounded-full bg-gradient-to-tr from-rose-600 via-red-500 to-amber-500 text-white flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all border-4 border-slate-950 ring-2 ring-rose-500/80 animate-pulse"
                  title="بدء بث فيديو مباشر (Live Stream)"
                >
                  <Video className="w-7 h-7 font-black stroke-[2.5]" />
                </button>
                <span className="text-[10px] font-black text-rose-400 mt-0.5 tracking-wide">بث لايف 🔴</span>
              </div>
            );
          }

          const isActive = activeTab === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id as MainTab)}
              className={`flex flex-col items-center justify-center p-1.5 transition-all ${
                isActive ? 'text-amber-400 scale-105' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-amber-400 stroke-[2.5]' : ''}`} />
              <span className={`text-[10px] mt-1 ${isActive ? 'font-black' : 'font-medium'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
