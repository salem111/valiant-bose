import React, { useState, useEffect, useRef } from 'react';
import AgoraRTC, {
  IAgoraRTCClient,
  ICameraVideoTrack,
  IMicrophoneAudioTrack,
  IAgoraRTCRemoteUser
} from 'agora-rtc-sdk-ng';
import { UserProfile, GiftItem } from '../types';
import { MOCK_GIFTS } from '../data/mockData';
import {
  Video,
  VideoOff,
  Mic,
  MicOff,
  RotateCcw,
  X,
  Send,
  Gift,
  Heart,
  Users,
  Swords,
  Crown,
  Sparkles,
  Shield,
  Coins,
  MessageSquare,
  Play,
  Square,
  Sliders,
  Wand2,
  Smile,
  Check,
  Sun,
  Eye,
  Maximize2,
  ShieldCheck,
  Info,
  Radio
} from 'lucide-react';

interface LiveStreamModalProps {
  user: UserProfile;
  onClose: () => void;
  onSendGift?: (gift: GiftItem, recipientName: string) => void;
  onOpenCoinStore?: () => void;
}

interface LiveComment {
  id: string;
  senderName: string;
  senderAvatar: string;
  senderVip?: number;
  text: string;
  timestamp: string;
  isGift?: boolean;
  giftIcon?: string;
  giftName?: string;
}

interface FloatingHeart {
  id: number;
  x: number;
  color: string;
}

const AGORA_APP_ID = "2bea0d6dbd304f6c9517215542b9aec1";
const AGORA_CHANNEL = "saleem-live";

export const LiveStreamModal: React.FC<LiveStreamModalProps> = ({
  user,
  onClose,
  onSendGift,
  onOpenCoinStore
}) => {
  // Stream & Hardware States
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [isMicOn, setIsMicOn] = useState(true);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [isConnecting, setIsConnecting] = useState(false);
  const [agoraConnected, setAgoraConnected] = useState(false);

  // Face Filters, Retouching & AR Masks State
  const [showFilterSheet, setShowFilterSheet] = useState(false);
  const [filterSheetTab, setFilterSheetTab] = useState<'retouch' | 'color' | 'ar'>('retouch');

  // Retouch Sliders
  const [smoothing, setSmoothing] = useState(60); // 0-100
  const [brightening, setBrightening] = useState(40); // 0-100
  const [faceSlimming, setFaceSlimming] = useState(30); // 0-100
  const [eyeEnlarge, setEyeEnlarge] = useState(25); // 0-100

  // Color Filter Preset
  const [colorPreset, setColorPreset] = useState<'none' | 'beauty' | 'warm' | 'cool' | 'vintage' | 'bw' | 'cinematic'>('beauty');

  // AR Mask / Sticker
  const [activeArMask, setActiveArMask] = useState<'none' | 'crown' | 'glasses' | 'cat' | 'halo' | 'stars' | 'cyber'>('crown');

  // Stats & Interaction States
  const [viewerCount, setViewerCount] = useState(128);
  const [likesCount, setLikesCount] = useState(1450);
  const [earnedCoins, setEarnedCoins] = useState(3200);
  const [showGiftSelector, setShowGiftSelector] = useState(false);
  const [showPkMode, setShowPkMode] = useState(false);
  const [showInfraModal, setShowInfraModal] = useState(false);
  const [isCoHostActive, setIsCoHostActive] = useState(false);

  // PK Challenge State & Calculations
  const [pkHostPoints, setPkHostPoints] = useState(54200);
  const [pkChallengerPoints, setPkChallengerPoints] = useState(48900);
  const [pkCountdown, setPkCountdown] = useState(180);
  const [sparkImpact, setSparkImpact] = useState(false);

  useEffect(() => {
    let timer: any;
    if (showPkMode && pkCountdown > 0) {
      timer = setInterval(() => {
        setPkCountdown((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [showPkMode, pkCountdown]);

  const totalPkPoints = pkHostPoints + pkChallengerPoints;
  const pkHostPct = totalPkPoints === 0 ? 50 : Math.round((pkHostPoints / totalPkPoints) * 100);
  const pkChallengerPct = 100 - pkHostPct;

  // Comments State
  const [comments, setComments] = useState<LiveComment[]>([
    { id: 'c1', senderName: 'نظام SALEEM 👑', senderAvatar: '', text: 'أهلاً وسهلاً بك في البث المباشر لقناة saleem-live! جرب فلاتر الوجه والتجميل الجديدة ✨', timestamp: 'الآن' },
    { id: 'c2', senderName: 'الشيخ خالد', senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80', senderVip: 6, text: 'منور البث المباشر يا أسطورة 🔥🔥 التاج الذهبي روعة!', timestamp: 'منذ دقيقة' },
    { id: 'c3', senderName: 'أميرة الشوق', senderAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80', senderVip: 4, text: 'الفلاتر وجودة 1080p ممتازة جداً ما شاء الله ✨', timestamp: 'منذ دقيقة' },
  ]);
  const [inputComment, setInputComment] = useState('');
  const [floatingHearts, setFloatingHearts] = useState<FloatingHeart[]>([]);

  // Audio / Video Refs & Agora Instances
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const agoraClientRef = useRef<IAgoraRTCClient | null>(null);
  const cameraTrackRef = useRef<ICameraVideoTrack | null>(null);
  const micTrackRef = useRef<IMicrophoneAudioTrack | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const commentsEndRef = useRef<HTMLDivElement | null>(null);

  // Toast Notification State
  const [toast, setToast] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  // Scroll to bottom of comments
  useEffect(() => {
    commentsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [comments]);

  // Compute CSS filter style for video stream based on retouching + color presets
  const getVideoFilterStyle = () => {
    // Base retouch values
    const blurSmooth = (smoothing / 100) * 0.4; // subtle blur smoothing
    const brightFactor = 1 + (brightening / 100) * 0.25;
    const contrastFactor = 1 + (brightening / 100) * 0.05;

    let presetFilter = '';
    switch (colorPreset) {
      case 'beauty':
        presetFilter = 'saturate(115%) contrast(105%)';
        break;
      case 'warm':
        presetFilter = 'sepia(15%) saturate(125%) hue-rotate(-10deg)';
        break;
      case 'cool':
        presetFilter = 'saturate(120%) hue-rotate(15deg) contrast(110%)';
        break;
      case 'vintage':
        presetFilter = 'sepia(35%) contrast(115%) brightness(95%)';
        break;
      case 'bw':
        presetFilter = 'grayscale(100%) contrast(125%)';
        break;
      case 'cinematic':
        presetFilter = 'contrast(130%) saturate(130%) brightness(95%)';
        break;
      default:
        presetFilter = '';
        break;
    }

    return {
      filter: `brightness(${brightFactor}) contrast(${contrastFactor}) ${presetFilter}`,
    };
  };

  // Handle local camera preview initialization when component mounts
  useEffect(() => {
    let mounted = true;

    async function initPreview() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: facingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: true,
        });
        if (mounted) {
          mediaStreamRef.current = stream;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        }
      } catch (err) {
        console.warn('Camera preview fallback:', err);
      }
    }

    initPreview();

    return () => {
      mounted = false;
      cleanupResources();
    };
  }, []);

  // Handle Facing Mode Flip (Front / Back Camera)
  const handleToggleFacingMode = async () => {
    const newFacingMode = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(newFacingMode);

    if (cameraTrackRef.current) {
      try {
        await cameraTrackRef.current.setDevice(newFacingMode);
      } catch (e) {
        console.log('Agora camera setDevice switch notice:', e);
      }
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
    }

    try {
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: newFacingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: isMicOn,
      });
      mediaStreamRef.current = newStream;
      if (videoRef.current) {
        videoRef.current.srcObject = newStream;
      }
      showToast(`🔄 تم التبديل إلى الكاميرا ${newFacingMode === 'user' ? 'الأمامية 🤳' : 'الخلفية 📷'}`);
    } catch (err) {
      showToast('تعذر تبديل الكاميرا');
    }
  };

  // Toggle Camera State
  const handleToggleCamera = async () => {
    const nextState = !isCameraOn;
    setIsCameraOn(nextState);

    if (cameraTrackRef.current) {
      await cameraTrackRef.current.setEnabled(nextState);
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getVideoTracks().forEach((track) => {
        track.enabled = nextState;
      });
    }

    showToast(nextState ? '📹 تم تشغيل الكاميرا' : '📷 تم إيقاف الكاميرا');
  };

  // Toggle Mic State
  const handleToggleMic = async () => {
    const nextState = !isMicOn;
    setIsMicOn(nextState);

    if (micTrackRef.current) {
      await micTrackRef.current.setEnabled(nextState);
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = nextState;
      });
    }

    showToast(nextState ? '🎙️ تم تشغيل الميكروفون' : '🔇 تم كتم الميكروفون');
  };

  // Start Live Broadcast Session (Agora + WebRTC)
  const handleStartBroadcast = async () => {
    setIsConnecting(true);
    try {
      const client = AgoraRTC.createClient({ mode: 'live', codec: 'vp8' });
      agoraClientRef.current = client;

      await client.setClientRole('host');

      client.on('user-published', async (remoteUser: IAgoraRTCRemoteUser, mediaType: 'audio' | 'video') => {
        await client.subscribe(remoteUser, mediaType);
        if (mediaType === 'audio') {
          remoteUser.audioTrack?.play();
        }
      });

      client.on('user-joined', () => {
        setViewerCount((prev) => prev + 1);
      });

      client.on('user-left', () => {
        setViewerCount((prev) => Math.max(1, prev - 1));
      });

      try {
        const uid = Math.floor(Math.random() * 10000);
        await client.join(AGORA_APP_ID, AGORA_CHANNEL, null, uid);
        setAgoraConnected(true);
      } catch (err) {
        console.warn('Agora channel join warning:', err);
      }

      try {
        const [micTrack, cameraTrack] = await Promise.all([
          AgoraRTC.createMicrophoneAudioTrack(),
          AgoraRTC.createCameraVideoTrack({ encoderConfig: '720p_1' })
        ]);

        micTrackRef.current = micTrack;
        cameraTrackRef.current = cameraTrack;

        if (videoRef.current) {
          cameraTrack.play(videoRef.current);
        }

        if (agoraClientRef.current) {
          await agoraClientRef.current.publish([micTrack, cameraTrack]);
        }
      } catch (trackErr) {
        console.warn('Agora track publish fallback:', trackErr);
      }

      setIsBroadcasting(true);
      setIsConnecting(false);
      showToast('🚀 تم بدء البث المباشر الحقيقي على قناة saleem-live!');

      setComments((prev) => [
        ...prev,
        {
          id: `sys-${Date.now()}`,
          senderName: 'نظام SALEEM 👑',
          senderAvatar: '',
          text: `بدأ ${user.name} البث المباشر التفاعلي الآن! 🎉`,
          timestamp: 'الآن',
        },
      ]);
    } catch (error) {
      console.error('Failed to start broadcast:', error);
      setIsBroadcasting(true);
      setIsConnecting(false);
      showToast('🎥 بدأ البث المباشر (وضع المباشر المحلي)');
    }
  };

  // Stop Broadcast Session
  const handleStopBroadcast = async () => {
    cleanupResources();
    setIsBroadcasting(false);
    setAgoraConnected(false);
    showToast('🛑 تم إيقاف البث المباشر');
  };

  // Cleanup Resources
  const cleanupResources = () => {
    try {
      if (micTrackRef.current) {
        micTrackRef.current.stop();
        micTrackRef.current.close();
        micTrackRef.current = null;
      }
      if (cameraTrackRef.current) {
        cameraTrackRef.current.stop();
        cameraTrackRef.current.close();
        cameraTrackRef.current = null;
      }
      if (agoraClientRef.current) {
        agoraClientRef.current.leave();
        agoraClientRef.current = null;
      }
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((track) => track.stop());
        mediaStreamRef.current = null;
      }
    } catch (e) {
      console.log('Cleanup error:', e);
    }
  };

  // Send Comment
  const handleSendComment = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputComment.trim()) return;

    const newComment: LiveComment = {
      id: `comment-${Date.now()}`,
      senderName: user.name,
      senderAvatar: user.avatar,
      senderVip: user.vipLevel,
      text: inputComment.trim(),
      timestamp: 'الآن',
    };

    setComments((prev) => [...prev, newComment]);
    setInputComment('');
  };

  // Send Gift
  const handleSendGiftInStream = (gift: GiftItem) => {
    if (user.coins < gift.priceCoins) {
      showToast('⚠️ رصيد العملات غير كافٍ! جاري فتح متجر العملات...');
      if (onOpenCoinStore) onOpenCoinStore();
      return;
    }

    if (onSendGift) {
      onSendGift(gift, user.name);
    }

    setEarnedCoins((prev) => prev + gift.priceCoins);

    if (showPkMode) {
      const pts = gift.priceCoins * 10;
      setPkHostPoints((prev) => prev + pts);
      setSparkImpact(true);
      setTimeout(() => setSparkImpact(false), 900);
    }

    setComments((prev) => [
      ...prev,
      {
        id: `gift-${Date.now()}`,
        senderName: user.name,
        senderAvatar: user.avatar,
        senderVip: user.vipLevel,
        text: `أرسل هدية ${gift.name} ${gift.icon}`,
        timestamp: 'الآن',
        isGift: true,
        giftIcon: gift.icon,
        giftName: gift.name,
      },
    ]);

    triggerLikeAnimation();
    setShowGiftSelector(false);
    showToast(`🎁 تم إرسال هدية ${gift.name} بنجاح!`);
  };

  // Trigger Likes
  const triggerLikeAnimation = () => {
    setLikesCount((prev) => prev + 1);
    const newHeart: FloatingHeart = {
      id: Date.now() + Math.random(),
      x: Math.random() * 80 + 10,
      color: ['#ef4444', '#f43f5e', '#ec4899', '#a855f7', '#eab308'][Math.floor(Math.random() * 5)],
    };
    setFloatingHearts((prev) => [...prev, newHeart]);

    setTimeout(() => {
      setFloatingHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col justify-between overflow-hidden text-white font-sans dir-rtl select-none">
      {/* 1. TOP LIVE STREAM HEADER BAR */}
      <div className="relative z-20 px-3 py-2.5 bg-gradient-to-b from-black/90 via-black/50 to-transparent flex items-center justify-between">
        {/* Streamer Avatar & Channel Info */}
        <div className="flex items-center gap-2 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-rose-500/40 shadow-lg">
          <img
            src={user.avatar}
            alt={user.name}
            className="w-8 h-8 rounded-full border-2 border-rose-500 object-cover"
          />
          <div className="text-right">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black text-white">{user.name}</span>
              <span className="bg-rose-600 text-white text-[9px] font-black px-1.5 py-0.2 rounded-full uppercase tracking-wider">
                {isBroadcasting ? '🔴 لايف' : 'معاينة'}
              </span>
            </div>
            <div className="flex items-center gap-2 text-[10px] text-rose-200">
              <span className="flex items-center gap-0.5">
                <Users className="w-3 h-3 text-rose-400" />
                <span>{viewerCount} مشاهد</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-0.5 text-amber-300">
                <Coins className="w-3 h-3 text-amber-400" />
                <span>{earnedCoins} عملة</span>
              </span>
            </div>
          </div>
        </div>

        {/* Right Top Action Controls */}
        <div className="flex items-center gap-2">
          {/* Close / Exit Button */}
          <button
            onClick={() => {
              cleanupResources();
              onClose();
            }}
            className="p-2 bg-black/60 hover:bg-rose-600 rounded-full text-white border border-white/20 transition-all active:scale-95 cursor-pointer shadow-lg"
            title="إغلاق البث"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* 2. MAIN LIVE STREAM STAGE CANVAS (Stack Layout with Split-Screen 50:50 Video View) */}
      <div className="relative flex-1 bg-slate-950 flex items-center justify-center overflow-hidden">
        {/* Video Player / Camera Feed Preview with Real-time Filters & Split-Screen PK Support */}
        <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
          
          {/* DUAL SPLIT-SCREEN CANVAS (50% Host : 50% Co-Host / Challenger) */}
          {showPkMode || isCoHostActive ? (
            <div className="w-full h-full flex flex-col sm:flex-row items-center justify-center bg-slate-950 divide-y sm:divide-y-0 sm:divide-x sm:divide-x-reverse divide-rose-500/30">
              
              {/* Host Video Canvas (50% Split) */}
              <div className="relative w-full h-1/2 sm:h-full sm:w-1/2 flex items-center justify-center overflow-hidden bg-slate-900">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  style={getVideoFilterStyle()}
                  className={`w-full h-full object-cover transition-all duration-300 transform ${
                    facingMode === 'user' ? 'scale-x-[-1]' : ''
                  } ${isCameraOn ? 'block' : 'hidden'}`}
                />

                {!isCameraOn && (
                  <div className="absolute inset-0 bg-slate-950 flex flex-col items-center justify-center p-3 text-center">
                    <VideoOff className="w-8 h-8 text-rose-400 mb-1" />
                    <span className="text-xs font-bold text-rose-200">الكاميرا متوقفة</span>
                  </div>
                )}

                {/* Host Overlay Badge */}
                <div className="absolute top-2 right-2 bg-black/70 backdrop-blur border border-rose-500/60 px-2.5 py-0.5 rounded-full text-[10px] font-black text-rose-300 flex items-center gap-1 z-10 shadow">
                  <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />
                  <span>المضيف: {user.name}</span>
                </div>
              </div>

              {/* Challenger / Co-Host Video Canvas (50% Split) */}
              <div className="relative w-full h-1/2 sm:h-full sm:w-1/2 flex flex-col items-center justify-center overflow-hidden bg-slate-900/90 border-t sm:border-t-0 sm:border-r border-cyan-500/40">
                <div className="relative my-auto flex flex-col items-center">
                  {/* Co-Host Video Circle / Frame */}
                  <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-full border-4 border-cyan-400 overflow-hidden shadow-[0_0_25px_rgba(6,182,212,0.5)]">
                    <img
                      src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=250&auto=format&fit=crop&q=80"
                      alt="الشيخ خالد"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end justify-center pb-1">
                      <span className="text-[10px] font-black text-cyan-300">الشيخ خالد</span>
                    </div>
                  </div>

                  {/* Audio Pulse Visualizer */}
                  <div className="mt-2 flex items-center gap-1 bg-cyan-950/80 border border-cyan-500/50 px-2.5 py-0.5 rounded-full text-[9px] font-mono text-cyan-300 font-bold shadow">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                    <span>مذيع بث مشارك (Broadcaster)</span>
                  </div>
                </div>

                {/* Co-Host Overlay Badge */}
                <div className="absolute top-2 left-2 bg-black/70 backdrop-blur border border-cyan-500/60 px-2.5 py-0.5 rounded-full text-[10px] font-black text-cyan-300 flex items-center gap-1 z-10 shadow">
                  <Swords className="w-3 h-3 text-cyan-400" />
                  <span>مُتحدي PK #2</span>
                </div>
              </div>

            </div>
          ) : (
            /* FULL SCREEN SINGLE VIDEO CANVAS */
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              style={getVideoFilterStyle()}
              className={`w-full h-full object-cover transition-all duration-300 transform ${
                facingMode === 'user' ? 'scale-x-[-1]' : ''
              } ${isCameraOn ? 'block' : 'hidden'}`}
            />
          )}

          {/* Face Retouch Slimming / Smoothing Optical Overlay Effect */}
          {isCameraOn && (smoothing > 0 || faceSlimming > 0) && (
            <div
              className="absolute inset-0 pointer-events-none transition-all duration-300"
              style={{
                boxShadow: `inset 0 0 ${smoothing * 0.8}px rgba(255, 255, 255, ${smoothing * 0.0015})`,
                backdropFilter: smoothing > 50 ? `blur(${smoothing * 0.008}px)` : 'none',
              }}
            />
          )}

          {/* AR Masks & Stickers Layer Overlay */}
          {isCameraOn && activeArMask !== 'none' && (
            <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center z-10 transition-all duration-300">
              {activeArMask === 'crown' && (
                <div className="relative -top-24 animate-bounce">
                  <span className="text-7xl filter drop-shadow-[0_10px_20px_rgba(234,179,8,0.8)]">👑</span>
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-24 h-6 bg-yellow-400/30 rounded-full blur-md" />
                </div>
              )}
              {activeArMask === 'glasses' && (
                <div className="relative -top-8 animate-pulse">
                  <span className="text-7xl filter drop-shadow-[0_10px_20px_rgba(16,185,129,0.8)]">🕶️</span>
                </div>
              )}
              {activeArMask === 'cat' && (
                <div className="relative -top-28 flex justify-between w-48">
                  <span className="text-5xl transform -rotate-12">🐱</span>
                  <span className="text-5xl transform rotate-12">🐱</span>
                </div>
              )}
              {activeArMask === 'halo' && (
                <div className="relative -top-32 animate-spin-slow">
                  <div className="w-32 h-8 rounded-full border-4 border-amber-300 shadow-[0_0_30px_#fde047] bg-amber-200/20" />
                </div>
              )}
              {activeArMask === 'stars' && (
                <div className="absolute inset-x-8 top-12 flex justify-around">
                  <span className="text-4xl animate-pulse">✨</span>
                  <span className="text-3xl animate-bounce">⭐</span>
                  <span className="text-4xl animate-pulse">✨</span>
                </div>
              )}
              {activeArMask === 'cyber' && (
                <div className="relative -top-6">
                  <div className="px-6 py-2 bg-gradient-to-r from-cyan-500/80 via-fuchsia-500/80 to-rose-500/80 rounded-2xl border-2 border-white/60 shadow-[0_0_30px_#06b6d4] text-xs font-black tracking-widest text-white backdrop-blur-md">
                    CYBER VISION AR ⚡
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Camera Muted Placeholder Screen */}
          {!isCameraOn && (
            <div className="absolute inset-0 bg-slate-950 flex flex-col items-center justify-center p-6 text-center space-y-3">
              <div className="w-20 h-20 rounded-full bg-rose-950/60 border-2 border-rose-500/50 flex items-center justify-center shadow-2xl">
                <VideoOff className="w-10 h-10 text-rose-400" />
              </div>
              <h3 className="text-base font-black text-rose-200">الكاميرا متوقفة مؤقتاً</h3>
              <p className="text-xs text-slate-400 max-w-xs">
                البث المباشر نشط بصوتك. انقر على زر الكاميرا أسفل الشاشة لإعادة التشغيل.
              </p>
            </div>
          )}

          {/* PK Challenge Screen Layout & Progress Bar */}
          {showPkMode && (
            <div className="absolute top-4 left-3 right-3 z-30 space-y-2 animate-in fade-in zoom-in duration-300">
              {/* PK Dual Header */}
              <div className="flex items-center justify-between text-xs font-black bg-slate-950/80 backdrop-blur-md p-2 rounded-2xl border border-amber-500/40 shadow-2xl">
                {/* Host A (Blue Side) */}
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full border-2 border-cyan-400 overflow-hidden shadow-lg">
                    <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <div className="text-cyan-300 font-bold">{user.name} 🔵</div>
                    <div className="text-[10px] text-amber-300 font-mono">{pkHostPoints.toLocaleString()} نقطة ({pkHostPct}%)</div>
                  </div>
                </div>

                {/* PK Timer */}
                <div className="flex flex-col items-center">
                  <span className="text-[10px] bg-rose-600 text-white font-black px-2 py-0.5 rounded-full flex items-center gap-1 animate-pulse">
                    <span>⚔️ PK</span>
                    <span>{Math.floor(pkCountdown / 60)}:{(pkCountdown % 60).toString().padStart(2, '0')}</span>
                  </span>
                </div>

                {/* Host B (Red Side) */}
                <div className="flex items-center gap-2 text-left dir-ltr">
                  <div className="w-8 h-8 rounded-full border-2 border-rose-500 overflow-hidden shadow-lg">
                    <img
                      src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"
                      alt="الشيخ خالد"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="text-right dir-rtl">
                    <div className="text-rose-400 font-bold">الشيخ خالد 🔴</div>
                    <div className="text-[10px] text-amber-300 font-mono">{pkChallengerPoints.toLocaleString()} نقطة ({pkChallengerPct}%)</div>
                  </div>
                </div>
              </div>

              {/* Dynamic Progress Bar with Collision Spark */}
              <div className="relative h-6 bg-slate-950 rounded-full border-2 border-amber-400/80 p-0.5 shadow-[0_0_20px_rgba(245,158,11,0.5)] overflow-hidden flex">
                {/* Blue Portion */}
                <div
                  style={{ width: `${pkHostPct}%` }}
                  className="h-full bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 transition-all duration-500 ease-out flex items-center justify-start px-2 text-[10px] font-black text-white"
                >
                  {pkHostPct > 15 && <span>{pkHostPct}%</span>}
                </div>

                {/* Red Portion */}
                <div
                  style={{ width: `${pkChallengerPct}%` }}
                  className="h-full bg-gradient-to-r from-rose-600 via-red-500 to-amber-500 transition-all duration-500 ease-out flex items-center justify-end px-2 text-[10px] font-black text-white"
                >
                  {pkChallengerPct > 15 && <span>{pkChallengerPct}%</span>}
                </div>

                {/* Spark / Collision Effect Indicator */}
                <div
                  style={{ left: `${pkHostPct}%` }}
                  className={`absolute top-0 bottom-0 -translate-x-1/2 w-4 flex items-center justify-center transition-all duration-500 z-10 ${
                    sparkImpact ? 'scale-150 animate-ping' : ''
                  }`}
                >
                  <div className="w-6 h-6 bg-yellow-300 rounded-full border-2 border-white shadow-[0_0_25px_#fde047] flex items-center justify-center text-[11px] animate-bounce">
                    💥
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Floating Hearts Animation Container */}
          <div className="absolute bottom-28 left-4 z-20 pointer-events-none h-64 w-24">
            {floatingHearts.map((h) => (
              <div
                key={h.id}
                style={{ left: `${h.x}%`, color: h.color }}
                className="absolute bottom-0 animate-bounce text-2xl transition-all duration-1000 opacity-90"
              >
                ❤️
              </div>
            ))}
          </div>
        </div>

        {/* Floating Right Controls Toolbar */}
        <div className="absolute right-3 top-16 z-20 flex flex-col gap-3">
          {/* Magic Wand / Face Retouch & Filters Button */}
          <button
            onClick={() => setShowFilterSheet(!showFilterSheet)}
            className={`w-11 h-11 rounded-full border flex items-center justify-center shadow-xl active:scale-90 transition-all cursor-pointer ${
              showFilterSheet || colorPreset !== 'beauty' || activeArMask !== 'none'
                ? 'bg-gradient-to-tr from-amber-500 to-rose-500 border-amber-300 text-slate-950 font-black'
                : 'bg-black/60 border-white/20 text-rose-300 hover:text-white'
            }`}
            title="فلاتر الوجه والتجميل والواقع المعزز"
          >
            <Wand2 className="w-5 h-5 animate-pulse" />
          </button>

          {/* Flip Camera Button (Front / Back Camera) */}
          <button
            onClick={handleToggleFacingMode}
            className="w-11 h-11 rounded-full bg-black/60 hover:bg-black backdrop-blur-md border border-white/20 text-amber-400 flex items-center justify-center shadow-xl active:scale-90 transition-all cursor-pointer"
            title={`تبديل الكاميرا (الحالية: ${facingMode === 'user' ? 'الأمامية' : 'الخلفية'})`}
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          {/* Camera On/Off Toggle */}
          <button
            onClick={handleToggleCamera}
            className={`w-11 h-11 rounded-full border flex items-center justify-center shadow-xl active:scale-90 transition-all cursor-pointer ${
              isCameraOn
                ? 'bg-black/60 border-emerald-500/50 text-emerald-400'
                : 'bg-rose-600 border-rose-400 text-white'
            }`}
            title={isCameraOn ? 'كتم الكاميرا' : 'تشغيل الكاميرا'}
          >
            {isCameraOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
          </button>

          {/* Mic On/Off Toggle */}
          <button
            onClick={handleToggleMic}
            className={`w-11 h-11 rounded-full border flex items-center justify-center shadow-xl active:scale-90 transition-all cursor-pointer ${
              isMicOn
                ? 'bg-black/60 border-emerald-500/50 text-emerald-400'
                : 'bg-rose-600 border-rose-400 text-white'
            }`}
            title={isMicOn ? 'كتم الميكروفون' : 'تشغيل الميكروفون'}
          >
            {isMicOn ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
          </button>

          {/* PK Challenge Toggle */}
          <button
            onClick={() => {
              setShowPkMode(!showPkMode);
              showToast(showPkMode ? 'إغلاق نمط التحدي PK' : '⚔️ تفعيل نمط التحدي المباشر PK');
            }}
            className={`w-11 h-11 rounded-full border flex items-center justify-center shadow-xl active:scale-90 transition-all cursor-pointer ${
              showPkMode ? 'bg-amber-500 border-amber-300 text-slate-950 font-black' : 'bg-black/60 border-white/20 text-amber-400'
            }`}
            title="تحدي PK"
          >
            <Swords className="w-5 h-5" />
          </button>

          {/* Co-Host Dual Split Video Screen Toggle */}
          <button
            onClick={() => {
              const nextState = !isCoHostActive;
              setIsCoHostActive(nextState);
              showToast(nextState ? '📺 تفعيل انقسام الشاشة للبث المشترك (Split Screen 50:50)' : '📺 العودة لشاشة البث الفردية الكاملة');
            }}
            className={`w-11 h-11 rounded-full border flex items-center justify-center shadow-xl active:scale-90 transition-all cursor-pointer ${
              isCoHostActive ? 'bg-cyan-500 border-cyan-300 text-slate-950 font-black' : 'bg-black/60 border-white/20 text-cyan-400'
            }`}
            title="انقسام الشاشة للبث المشترك (Split Screen 50:50)"
          >
            <Users className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* 3. LIVE COMMENTS STREAM & INTERACTIVE OVERLAY */}
      <div className="relative z-20 px-3 pb-2 pt-1 bg-gradient-to-t from-slate-950 via-slate-950/90 to-transparent flex flex-col space-y-2">
        {/* Comments Box */}
        <div className="max-h-36 overflow-y-auto space-y-1.5 p-2 rounded-2xl bg-black/40 backdrop-blur-md border border-white/10 text-xs">
          {comments.map((c) => (
            <div key={c.id} className="flex items-start gap-1.5 text-right animate-in fade-in duration-200">
              {c.senderAvatar ? (
                <img src={c.senderAvatar} alt={c.senderName} className="w-5 h-5 rounded-full border border-rose-400 object-cover mt-0.5" />
              ) : (
                <div className="w-5 h-5 rounded-full bg-rose-600 text-[10px] font-bold flex items-center justify-center">👑</div>
              )}
              <div>
                <span className="font-black text-amber-300 ml-1">{c.senderName}:</span>
                <span className={c.isGift ? 'font-black text-rose-300' : 'text-slate-200'}>{c.text}</span>
              </div>
            </div>
          ))}
          <div ref={commentsEndRef} />
        </div>

        {/* 4. BOTTOM ACTION & BROADCAST BUTTON BAR */}
        <div className="flex items-center gap-2">
          {/* Main Start / Stop Live Broadcast Button */}
          {!isBroadcasting ? (
            <button
              onClick={handleStartBroadcast}
              disabled={isConnecting}
              className="flex-1 py-3 bg-gradient-to-r from-rose-600 via-red-500 to-amber-500 hover:from-rose-500 hover:to-amber-400 text-white font-black text-xs rounded-2xl shadow-xl shadow-rose-950/80 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer border border-rose-400"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>{isConnecting ? 'جاري الاتصال بقناة Agora...' : 'بدء البث المباشر الحقيقي 🔴'}</span>
            </button>
          ) : (
            <button
              onClick={handleStopBroadcast}
              className="flex-1 py-3 bg-rose-700 hover:bg-rose-800 text-white font-black text-xs rounded-2xl shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer border border-rose-500"
            >
              <Square className="w-4 h-4 fill-white" />
              <span>إيقاف البث المباشر 🛑</span>
            </button>
          )}

          {/* Comment Input Box */}
          <form onSubmit={handleSendComment} className="flex-1 flex items-center gap-1 bg-black/60 border border-white/20 rounded-2xl px-2.5 py-1.5">
            <input
              type="text"
              value={inputComment}
              onChange={(e) => setInputComment(e.target.value)}
              placeholder="اكتب تعليقاً..."
              className="w-full bg-transparent text-xs text-white placeholder-slate-400 focus:outline-none"
            />
            <button
              type="submit"
              className="p-1.5 bg-amber-500 text-slate-950 rounded-xl hover:bg-amber-400 transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Send Gift Button */}
          <button
            onClick={() => setShowGiftSelector(!showGiftSelector)}
            className="p-3 bg-gradient-to-tr from-amber-500 to-yellow-400 text-slate-950 rounded-2xl font-black shadow-lg hover:scale-105 active:scale-95 transition-all cursor-pointer"
            title="إرسال هدية"
          >
            <Gift className="w-5 h-5" />
          </button>

          {/* Send Like Heart Button */}
          <button
            onClick={triggerLikeAnimation}
            className="p-3 bg-rose-600/90 text-white rounded-2xl font-black shadow-lg hover:scale-110 active:scale-90 transition-all cursor-pointer border border-rose-400"
            title="إرسال إعجاب"
          >
            <Heart className="w-5 h-5 fill-white" />
          </button>
        </div>
      </div>

      {/* 5. FACE FILTERS & RETOUCHING BOTTOM SHEET PANEL */}
      {showFilterSheet && (
        <div className="fixed inset-x-0 bottom-0 z-50 bg-[#0f0a1c]/95 border-t-2 border-rose-500/60 rounded-t-3xl p-4 text-right animate-in slide-in-from-bottom duration-300 shadow-2xl backdrop-blur-xl max-h-[75vh] overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-rose-500/20 pb-3 mb-3">
            <div className="flex items-center gap-2">
              <Wand2 className="w-5 h-5 text-amber-400 animate-spin-slow" />
              <h3 className="font-black text-sm text-amber-200">تعديلات الوجه والفلاتر والواقع المعزز (AR)</h3>
            </div>
            <button
              onClick={() => setShowFilterSheet(false)}
              className="p-1 text-slate-400 hover:text-white rounded-full bg-white/5 hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="flex bg-slate-900/80 p-1 rounded-2xl mb-4 border border-white/10">
            <button
              onClick={() => setFilterSheetTab('retouch')}
              className={`flex-1 py-2 text-xs font-black rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                filterSheetTab === 'retouch'
                  ? 'bg-gradient-to-r from-rose-600 to-amber-500 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smile className="w-4 h-4" />
              <span>تجميل الوجه (Retouch)</span>
            </button>

            <button
              onClick={() => setFilterSheetTab('color')}
              className={`flex-1 py-2 text-xs font-black rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                filterSheetTab === 'color'
                  ? 'bg-gradient-to-r from-rose-600 to-amber-500 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>فلاتر الألوان (Color LUTs)</span>
            </button>

            <button
              onClick={() => setFilterSheetTab('ar')}
              className={`flex-1 py-2 text-xs font-black rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                filterSheetTab === 'ar'
                  ? 'bg-gradient-to-r from-rose-600 to-amber-500 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Crown className="w-4 h-4" />
              <span>الملصقات (AR Masks)</span>
            </button>
          </div>

          {/* TAB 1: RETOUCH SLIDERS */}
          {filterSheetTab === 'retouch' && (
            <div className="space-y-4 px-1 py-2">
              {/* Smoothing Slider */}
              <div className="space-y-1.5 bg-slate-900/60 p-3 rounded-2xl border border-white/5">
                <div className="flex justify-between items-center text-xs font-bold">
                  <span className="text-rose-300 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>تنعيم البشرة (Skin Smoothing)</span>
                  </span>
                  <span className="text-amber-400 font-mono font-black">{smoothing}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={smoothing}
                  onChange={(e) => setSmoothing(Number(e.target.value))}
                  className="w-full accent-rose-500 cursor-pointer h-2 bg-slate-800 rounded-lg"
                />
              </div>

              {/* Brightening Slider */}
              <div className="space-y-1.5 bg-slate-900/60 p-3 rounded-2xl border border-white/5">
                <div className="flex justify-between items-center text-xs font-bold">
                  <span className="text-rose-300 flex items-center gap-1">
                    <Sun className="w-3.5 h-3.5" />
                    <span>تبييض وإضاءة الوجه (Brightening)</span>
                  </span>
                  <span className="text-amber-400 font-mono font-black">{brightening}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={brightening}
                  onChange={(e) => setBrightening(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer h-2 bg-slate-800 rounded-lg"
                />
              </div>

              {/* Slimming Slider */}
              <div className="space-y-1.5 bg-slate-900/60 p-3 rounded-2xl border border-white/5">
                <div className="flex justify-between items-center text-xs font-bold">
                  <span className="text-rose-300 flex items-center gap-1">
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>تنحيف الوجه (Slimming)</span>
                  </span>
                  <span className="text-amber-400 font-mono font-black">{faceSlimming}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={faceSlimming}
                  onChange={(e) => setFaceSlimming(Number(e.target.value))}
                  className="w-full accent-rose-500 cursor-pointer h-2 bg-slate-800 rounded-lg"
                />
              </div>

              {/* Eye Enlargement Slider */}
              <div className="space-y-1.5 bg-slate-900/60 p-3 rounded-2xl border border-white/5">
                <div className="flex justify-between items-center text-xs font-bold">
                  <span className="text-rose-300 flex items-center gap-1">
                    <Eye className="w-3.5 h-3.5" />
                    <span>تكبير العيون (Eye Enlarging)</span>
                  </span>
                  <span className="text-amber-400 font-mono font-black">{eyeEnlarge}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={eyeEnlarge}
                  onChange={(e) => setEyeEnlarge(Number(e.target.value))}
                  className="w-full accent-indigo-500 cursor-pointer h-2 bg-slate-800 rounded-lg"
                />
              </div>

              {/* Reset Retouch Button */}
              <button
                onClick={() => {
                  setSmoothing(60);
                  setBrightening(40);
                  setFaceSlimming(30);
                  setEyeEnlarge(25);
                  showToast('تمت إعادة ضبط التجميل إلى الوضع الطبيعي المحسن');
                }}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                إعادة ضبط خيارات التجميل 🔄
              </button>
            </div>
          )}

          {/* TAB 2: COLOR FILTERS */}
          {filterSheetTab === 'color' && (
            <div className="grid grid-cols-3 gap-2.5 py-2">
              {[
                { id: 'none', label: 'طبيعي 🌿', bg: 'bg-slate-800' },
                { id: 'beauty', label: 'تجميل ناعم ✨', bg: 'bg-rose-900/60' },
                { id: 'warm', label: 'دافئ ذهبي 🌅', bg: 'bg-amber-900/60' },
                { id: 'cool', label: 'بارد سايبورغ ❄️', bg: 'bg-cyan-900/60' },
                { id: 'vintage', label: 'كلاسيك 🎞️', bg: 'bg-yellow-950/60' },
                { id: 'bw', label: 'أبيض وأسود 🎬', bg: 'bg-slate-900' },
                { id: 'cinematic', label: 'سينمائي 🍿', bg: 'bg-indigo-950/60' },
              ].map((p) => (
                <button
                  key={p.id}
                  onClick={() => setColorPreset(p.id as any)}
                  className={`p-3 rounded-2xl border flex flex-col items-center justify-center transition-all cursor-pointer ${
                    colorPreset === p.id
                      ? 'border-amber-400 bg-amber-500/20 shadow-lg scale-105'
                      : 'border-white/10 hover:border-white/30 ' + p.bg
                  }`}
                >
                  <span className="text-xs font-black text-white">{p.label}</span>
                  {colorPreset === p.id && <Check className="w-4 h-4 text-amber-400 mt-1" />}
                </button>
              ))}
            </div>
          )}

          {/* TAB 3: AR MASKS & STICKERS */}
          {filterSheetTab === 'ar' && (
            <div className="grid grid-cols-3 gap-2.5 py-2">
              {[
                { id: 'none', label: 'بدون ماسك', icon: '❌' },
                { id: 'crown', label: 'تاج ملكي', icon: '👑' },
                { id: 'glasses', label: 'نظارات نيون', icon: '🕶️' },
                { id: 'cat', label: 'أذنان قطة', icon: '🐱' },
                { id: 'halo', label: 'هالة ملائكية', icon: '😇' },
                { id: 'stars', label: 'بريق النجوم', icon: '✨' },
                { id: 'cyber', label: 'قناع السايبر', icon: '🎭' },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => setActiveArMask(m.id as any)}
                  className={`p-3 rounded-2xl border flex flex-col items-center justify-center transition-all cursor-pointer ${
                    activeArMask === m.id
                      ? 'border-rose-400 bg-rose-500/20 shadow-lg scale-105'
                      : 'border-white/10 hover:border-white/30 bg-slate-900/80'
                  }`}
                >
                  <span className="text-2xl mb-1">{m.icon}</span>
                  <span className="text-xs font-black text-white">{m.label}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 6. GIFT SELECTOR MODAL SHEET */}
      {showGiftSelector && (
        <div className="fixed inset-x-0 bottom-0 z-50 bg-[#120d24] border-t-2 border-amber-500/60 rounded-t-3xl p-4 text-right animate-in slide-in-from-bottom duration-300 shadow-2xl">
          <div className="flex items-center justify-between border-b border-amber-500/20 pb-2 mb-3">
            <div className="flex items-center gap-2">
              <Gift className="w-5 h-5 text-amber-400" />
              <h3 className="font-black text-sm text-amber-200">إرسال هدية في البث المباشر 🎁</h3>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-amber-300 font-bold">رصيدك: {user.coins} 🪙</span>
              <button
                onClick={() => setShowGiftSelector(false)}
                className="text-slate-400 hover:text-white p-1 rounded-full"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2 mb-3">
            {MOCK_GIFTS.map((g) => (
              <button
                key={g.id}
                onClick={() => handleSendGiftInStream(g)}
                className="flex flex-col items-center justify-center p-2.5 bg-slate-900/90 border border-slate-800 hover:border-amber-400 rounded-2xl transition-all hover:scale-105 active:scale-95 cursor-pointer group"
              >
                <span className="text-3xl mb-1 group-hover:scale-110 transition-transform">{g.icon}</span>
                <span className="text-[11px] font-bold text-white">{g.name}</span>
                <span className="text-[10px] font-black text-amber-400">{g.priceCoins} 🪙</span>
              </button>
            ))}
          </div>

          <button
            onClick={() => {
              setShowGiftSelector(false);
              if (onOpenCoinStore) onOpenCoinStore();
            }}
            className="w-full py-2 bg-amber-500 text-slate-950 font-black text-xs rounded-xl hover:bg-amber-400 transition-colors"
          >
            شحن المزيد من العملات 💎
          </button>
        </div>
      )}



      {/* Floating Toast Alert */}
      {toast && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 border border-amber-500/60 text-amber-200 font-bold text-xs px-4 py-2.5 rounded-full shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-top-2 duration-200">
          {toast}
        </div>
      )}
    </div>
  );
};
