import React from 'react';
import { VoiceRoom } from '../types';
import { Users, Mic, Lock, Volume2, Sparkles, Shield, Flame } from 'lucide-react';

interface RoomCardProps {
  room: VoiceRoom;
  onOpenRoom: (room: VoiceRoom) => void;
}

export const RoomCard: React.FC<RoomCardProps> = ({ room, onOpenRoom }) => {
  // Find active speakers in seats
  const activeSpeakers = room.seats.filter((s) => s.speakerUser);
  const speakingNow = activeSpeakers.some((s) => s.speakerUser?.isSpeaking);

  return (
    <div
      onClick={() => onOpenRoom(room)}
      className="group relative bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-amber-500/50 rounded-2xl overflow-hidden shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer flex flex-col"
    >
      {/* Background Banner / Wallpaper Header */}
      <div className="relative h-28 w-full overflow-hidden bg-slate-950">
        <img
          src={room.backgroundUrl}
          alt={room.title}
          className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />

        {/* Top Badges */}
        <div className="absolute top-2 right-2 left-2 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1">
            <span className="bg-amber-500 text-slate-950 font-black px-2 py-0.5 rounded-full text-[10px] shadow flex items-center gap-0.5">
              #{room.rank || 1}
            </span>
            <span className="bg-slate-950/80 backdrop-blur-md text-amber-300 font-bold px-2 py-0.5 rounded-full text-[10px] border border-amber-500/30 flex items-center gap-1">
              <Flame className="w-3 h-3 text-amber-400" />
              ليفل {room.level || 1}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 backdrop-blur-md ${
              room.isLockedWithPin
                ? 'bg-red-500/80 text-white border border-red-400/50'
                : 'bg-emerald-500/80 text-white border border-emerald-400/50'
            }`}>
              {room.isLockedWithPin ? <Lock className="w-3 h-3" /> : null}
              <span>{room.isLockedWithPin ? 'مقفلة' : 'مفتوحة'}</span>
            </span>
            <span className="bg-slate-950/80 backdrop-blur-md text-cyan-300 font-bold px-2 py-0.5 rounded-full text-[10px] border border-cyan-500/30 flex items-center gap-1">
              <Users className="w-3 h-3 text-cyan-400" />
              {room.listenersCount}
            </span>
          </div>
        </div>

        {/* Host Avatar Overlap */}
        <div className="absolute -bottom-4 right-3 flex items-center gap-2">
          <div className="relative">
            <img
              src={room.hostAvatar}
              alt={room.hostName}
              className="w-12 h-12 rounded-full object-cover border-2 border-amber-400 shadow-xl bg-slate-950"
            />
            {speakingNow && (
              <span className="absolute -top-1 -left-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-slate-900 animate-ping" />
            )}
            <span className="absolute bottom-0 right-0 bg-amber-500 text-slate-950 font-black text-[8px] px-1 rounded-full shadow">
              مضيف
            </span>
          </div>
          <div className="mb-3">
            <span className="text-xs font-bold text-amber-200 drop-shadow block">
              {room.hostName}
            </span>
          </div>
        </div>
      </div>

      {/* Room Details & Active Speakers Grid */}
      <div className="p-3 pt-5 flex-1 flex flex-col justify-between space-y-3">
        <div>
          <h3 className="font-bold text-sm text-white line-clamp-1 group-hover:text-amber-300 transition-colors">
            {room.title}
          </h3>
          <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
            {room.announcement}
          </p>
        </div>

        {/* Active Mic Speakers Thumbnails */}
        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex items-center -space-x-2 space-x-reverse">
              {activeSpeakers.slice(0, 4).map((seat) => (
                <div key={seat.seatId} className="relative group/speaker">
                  <img
                    src={seat.speakerUser?.avatar}
                    alt={seat.speakerUser?.name}
                    className={`w-7 h-7 rounded-full object-cover border-2 ${
                      seat.speakerUser?.isSpeaking
                        ? 'border-emerald-400 ring-2 ring-emerald-400/50'
                        : 'border-slate-800'
                    }`}
                    title={seat.speakerUser?.name}
                  />
                  {seat.speakerUser?.isSpeaking && (
                    <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border border-slate-900" />
                  )}
                </div>
              ))}
              {activeSpeakers.length > 4 && (
                <div className="w-7 h-7 rounded-full bg-slate-800 border-2 border-slate-700 flex items-center justify-center text-[10px] font-bold text-slate-300">
                  +{activeSpeakers.length - 4}
                </div>
              )}
            </div>
            <span className="text-[10px] text-slate-400 font-bold flex items-center gap-1 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
              <Mic className="w-3 h-3 text-amber-400" />
              {activeSpeakers.length} مايك
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-amber-400 font-bold bg-amber-500/10 px-2.5 py-1 rounded-xl border border-amber-500/20 group-hover:bg-amber-500 group-hover:text-slate-950 transition-all">
            <Volume2 className="w-3.5 h-3.5" />
            <span>دخول</span>
          </div>
        </div>
      </div>
    </div>
  );
};
