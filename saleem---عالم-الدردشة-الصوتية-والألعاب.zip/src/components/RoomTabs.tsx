import React, { useState } from 'react';
import { Search, Flame, Sparkles, Heart, Filter, X } from 'lucide-react';

interface RoomTabsProps {
  activeTab: 'غرف شائعة' | 'غرف جديدة' | 'متابعة';
  onTabChange: (tab: 'غرف شائعة' | 'غرف جديدة' | 'متابعة') => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export const RoomTabs: React.FC<RoomTabsProps> = ({
  activeTab,
  onTabChange,
  searchQuery,
  onSearchChange,
}) => {
  const [showSearchInput, setShowSearchInput] = useState(false);

  const TABS = [
    { id: 'غرف شائعة', label: 'غرف شائعة 🔥', icon: Flame },
    { id: 'غرف جديدة', label: 'غرف جديدة ✨', icon: Sparkles },
    { id: 'متابعة', label: 'متابعة ❤️', icon: Heart },
  ] as const;

  return (
    <div id="saleem-room-tabs" className="my-3 space-y-2">
      <div className="flex items-center justify-between gap-2 bg-slate-900/90 p-1.5 rounded-2xl border border-slate-800">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-none py-0.5">
          {TABS.map((tab) => {
            const isActive = activeTab === tab.id;
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-amber-500 to-yellow-600 text-slate-950 shadow-md scale-105'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-950' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Search Toggle Button */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setShowSearchInput(!showSearchInput)}
            className={`p-2 rounded-xl border transition-colors ${
              showSearchInput || searchQuery
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
            }`}
            title="بحث عن غرفة أو مضيف"
          >
            <Search className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Expandable Search Input */}
      {showSearchInput && (
        <div className="relative animate-fadeIn">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="ابحث عن اسم الغرفة، المضيف، أو رقم المعرف ID..."
            className="w-full bg-slate-900 border border-amber-500/40 rounded-xl pr-9 pl-9 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500/50"
            autoFocus
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      )}
    </div>
  );
};
