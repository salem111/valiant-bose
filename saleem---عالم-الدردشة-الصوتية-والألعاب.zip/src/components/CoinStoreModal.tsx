import React, { useState } from 'react';
import { UserProfile, CoinPackage, TransactionRecord } from '../types';
import { COIN_PACKAGES } from '../data/mockData';
import { X, Wallet, ShieldCheck, CheckCircle2, Sparkles, AlertCircle, ShoppingBag } from 'lucide-react';

interface CoinStoreModalProps {
  user: UserProfile;
  onClose: () => void;
  onPurchaseSuccess: (coinsAdded: number, tx: TransactionRecord) => void;
}

export const CoinStoreModal: React.FC<CoinStoreModalProps> = ({
  user,
  onClose,
  onPurchaseSuccess,
}) => {
  const [selectedPackage, setSelectedPackage] = useState<CoinPackage | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [purchaseStep, setPurchaseStep] = useState<'SELECT' | 'VERIFYING' | 'SUCCESS'>('SELECT');
  const [lastTx, setLastTx] = useState<TransactionRecord | null>(null);

  const handleBuyPackage = (pkg: CoinPackage) => {
    setSelectedPackage(pkg);
    setIsProcessing(true);
    setPurchaseStep('VERIFYING');

    // Simulate Google Play Billing checkout + Server-Side Developer API Verification
    setTimeout(() => {
      const generatedOrderId = `GPA.${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(10000 + Math.random() * 90000)}`;
      const generatedToken = `google_play_token_${Date.now()}_${Math.random().toString(36).substring(7)}`;

      const totalCoins = pkg.coinsAmount + pkg.bonusCoins;

      const newTx: TransactionRecord = {
        id: `tx-${Date.now()}`,
        googleOrderId: generatedOrderId,
        userId: user.id,
        userName: user.name,
        packageName: pkg.title,
        amountCoins: totalCoins,
        priceUsd: pkg.priceUsd,
        purchaseToken: generatedToken,
        status: 'SUCCESS',
        timestamp: new Date().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }),
      };

      setLastTx(newTx);
      setIsProcessing(false);
      setPurchaseStep('SUCCESS');
      onPurchaseSuccess(totalCoins, newTx);
    }, 2200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-xl bg-slate-900 border border-amber-500/40 rounded-3xl p-5 shadow-2xl space-y-4 text-right animate-scaleUp">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center font-black">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-black text-base text-amber-300">متجر عملات SALEEM (Google Play Billing)</h2>
              <p className="text-[11px] text-slate-400">شحن آمن مع التحقق الفوري عبر الخادم Developer API</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Verification Status Banner */}
        <div className="bg-slate-950 p-3 rounded-2xl border border-emerald-500/30 flex items-center justify-between text-xs text-slate-300">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <span className="font-bold text-emerald-300 block">بوابة الشحن الرسمية المشفرة</span>
              <span className="text-[10px] text-slate-400">Google Play Consumables v5.0 Integration</span>
            </div>
          </div>
          <span className="font-mono text-[11px] bg-emerald-500/10 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/20">
            رصيدك: {user.coins.toLocaleString()} 🪙
          </span>
        </div>

        {purchaseStep === 'VERIFYING' && selectedPackage && (
          <div className="p-8 text-center space-y-3 bg-slate-950 rounded-2xl border border-amber-500/30 animate-pulse">
            <div className="w-12 h-12 rounded-full border-4 border-amber-400 border-t-transparent animate-spin mx-auto" />
            <h3 className="font-bold text-amber-300 text-sm">جاري التواصل مع متجر Google Play...</h3>
            <p className="text-xs text-slate-400">
              يتم التحقق من رمز الشراء (Purchase Token) إضافة {selectedPackage.coinsAmount + selectedPackage.bonusCoins} عملة فورياً بقاعدة البيانات.
            </p>
          </div>
        )}

        {purchaseStep === 'SUCCESS' && lastTx && (
          <div className="p-6 text-center space-y-3 bg-slate-950 rounded-2xl border border-emerald-500/40 animate-fadeIn">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <h3 className="font-black text-emerald-300 text-base">تمت عملية الشراء بنجاح!</h3>
            <div className="text-xs text-slate-300 bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1 font-mono text-right">
              <p><span className="text-slate-500">رقم طلب قوقل:</span> {lastTx.googleOrderId}</p>
              <p><span className="text-slate-500">حزمة الشراء:</span> {lastTx.packageName}</p>
              <p><span className="text-slate-500">العملات المضافة:</span> +{lastTx.amountCoins.toLocaleString()} 🪙</p>
              <p><span className="text-slate-500">الحالة:</span> <span className="text-emerald-400 font-bold">متحقق منها 100%</span></p>
            </div>
            <button
              onClick={() => setPurchaseStep('SELECT')}
              className="py-2 px-6 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl"
            >
              شراء حزمة أخرى
            </button>
          </div>
        )}

        {purchaseStep === 'SELECT' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {COIN_PACKAGES.map((pkg) => (
              <div
                key={pkg.id}
                className="relative bg-slate-950 hover:bg-slate-800/80 border border-slate-800 hover:border-amber-400/50 rounded-2xl p-4 transition-all flex flex-col justify-between space-y-3 shadow-lg group"
              >
                {pkg.badge && (
                  <span className="absolute -top-2 left-3 bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-[9px] px-2 py-0.5 rounded-full shadow">
                    {pkg.badge}
                  </span>
                )}

                <div>
                  <h4 className="font-black text-sm text-amber-200">{pkg.title}</h4>
                  <div className="flex items-center gap-1.5 mt-2">
                    <span className="text-2xl font-black text-white font-mono">
                      {pkg.coinsAmount.toLocaleString()}
                    </span>
                    <span className="text-xs text-amber-400 font-bold">🪙 عملة</span>
                  </div>
                  {pkg.bonusCoins > 0 && (
                    <span className="text-[10px] text-emerald-400 font-bold block mt-0.5">
                      + {pkg.bonusCoins.toLocaleString()} عملة إضافية مجاناً 🎁
                    </span>
                  )}
                </div>

                <button
                  onClick={() => handleBuyPackage(pkg)}
                  className="w-full py-2.5 bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 font-black text-xs rounded-xl shadow group-hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-1.5"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>شراء الآن (${pkg.priceUsd})</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
