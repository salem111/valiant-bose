import React from 'react';
import { Crown, Trophy, Gift, Plus, Mic, Flame, Gamepad2 } from 'lucide-react';
import { UserProfile } from '../types';

interface QuickCategoriesProps {
  user?: UserProfile;
  onOpenVip: () => void;
  onOpenLeaderboard: () => void;
  onOpenGifts: () => void;
  onOpenAgencies: () => void;
  onOpenEvents: () => void;
  onOpenGames: () => void;
}

export const QuickCategories: React.FC<QuickCategoriesProps> = ({
  user,
  onOpenVip,
  onOpenLeaderboard,
  onOpenGifts,
  onOpenAgencies,
  onOpenEvents,
  onOpenGames,
}) => {
  const CATEGORIES = [
    {
      id: 'vip',
      label: 'VIP مميز',
      icon: Crown,
      color: 'from-amber-500 to-yellow-600',
      shadow: 'shadow-amber-500/20',
      action: onOpenVip,
    },
    {
      id: 'ranking',
      label: 'الترتيب',
      icon: Trophy,
      color: 'from-yellow-500 to-amber-700',
      shadow: 'shadow-yellow-500/20',
      action: onOpenLeaderboard,
    },
    {
      id: 'games',
      label: 'الألعاب والرهان',
      icon: Gamepad2,
      color: 'from-purple-600 to-indigo-700',
      shadow: 'shadow-purple-500/20',
      action: onOpenGames,
    },
    {
      id: 'gifts',
      label: 'متجر الهدايا',
      icon: Gift,
      color: 'from-rose-500 to-pink-700',
      shadow: 'shadow-rose-500/20',
      action: onOpenGifts,
    },
    {
      id: 'create_room',
      label: user?.hasActiveRoom ? 'غرفتي 🎙️' : 'إنشاء غرفة ➕',
      icon: user?.hasActiveRoom ? Mic : Plus,
      color: user?.hasActiveRoom ? 'from-emerald-600 to-teal-700' : 'from-amber-500 to-yellow-600',
      shadow: user?.hasActiveRoom ? 'shadow-emerald-500/20' : 'shadow-amber-500/20',
      action: onOpenAgencies,
    },
    {
      id: 'events',
      label: 'الفعاليات',
      icon: Flame,
      color: 'from-orange-500 to-red-600',
      shadow: 'shadow-orange-500/20',
      action: onOpenEvents,
    },
  ];

  return (
    <div id="saleem-quick-categories" className="my-3">
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={cat.action}
            className={`group relative flex flex-col items-center justify-center p-3 rounded-2xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/40 transition-all duration-300 shadow-md ${cat.shadow} hover:-translate-y-1 active:translate-y-0`}
          >
            <div
              className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${cat.color} flex items-center justify-center text-white mb-2 shadow-lg group-hover:scale-110 transition-transform`}
            >
              <cat.icon className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-slate-200 group-hover:text-amber-300 transition-colors">
              {cat.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};
