import React, { useState } from 'react';
import { MessageSquare, Send, CheckCheck, Sparkles } from 'lucide-react';

export const DirectChatsView: React.FC = () => {
  const [selectedChatId, setSelectedChatId] = useState<number | null>(1);
  const [messageInput, setMessageInput] = useState('');

  const CHATS = [
    { id: 1, name: 'الشيخ خالد 👑', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80', lastMsg: 'حيّاك الله يا سالم، جهّز نفسك للغرفة اليوم', time: '18:30', unread: 2 },
    { id: 2, name: 'أميرة الشوق', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80', lastMsg: 'شكراً لك على الهدية الملكية! 💖', time: '16:15', unread: 0 },
    { id: 3, name: 'الكابتن علي', avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80', lastMsg: 'طاولة الطرنيب جاهزة تحداك الجولة الجاية 🃏', time: 'أمس', unread: 0 },
  ];

  const activeChat = CHATS.find(c => c.id === selectedChatId) || CHATS[0];

  return (
    <div id="saleem-direct-chats-view" className="space-y-3 text-right">
      <div className="bg-slate-900 p-3 rounded-2xl border border-amber-500/30 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-amber-400" />
          <h2 className="font-black text-sm text-amber-300">الدردشات والمراسلات المباشرة 💬</h2>
        </div>
        <span className="text-xs text-slate-400">تواصل آمن مع أصدقائك في SALEEM</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 h-[65vh]">
        {/* Chat Conversations List */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2 space-y-2 overflow-y-auto">
          {CHATS.map((chat) => (
            <div
              key={chat.id}
              onClick={() => setSelectedChatId(chat.id)}
              className={`p-2.5 rounded-xl cursor-pointer transition-all flex items-center justify-between ${
                selectedChatId === chat.id
                  ? 'bg-amber-500/20 border border-amber-500/40 text-white'
                  : 'bg-slate-950 border border-slate-800 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <img src={chat.avatar} alt={chat.name} className="w-10 h-10 rounded-full object-cover ring-1 ring-amber-400" />
                <div>
                  <h4 className="font-bold text-xs text-white line-clamp-1">{chat.name}</h4>
                  <p className="text-[10px] text-slate-400 line-clamp-1">{chat.lastMsg}</p>
                </div>
              </div>
              <span className="text-[9px] text-slate-500 font-mono">{chat.time}</span>
            </div>
          ))}
        </div>

        {/* Active Chat Conversation Area */}
        <div className="md:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-3 flex flex-col justify-between">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
            <img src={activeChat.avatar} alt="" className="w-8 h-8 rounded-full object-cover" />
            <span className="font-bold text-xs text-amber-300">{activeChat.name}</span>
          </div>

          <div className="flex-1 my-3 space-y-2 overflow-y-auto text-xs p-2 bg-slate-950 rounded-xl">
            <div className="bg-slate-800 p-2.5 rounded-xl max-w-xs text-slate-200">
              {activeChat.lastMsg}
            </div>
            <div className="bg-amber-500 text-slate-950 p-2.5 rounded-xl max-w-xs mr-auto font-bold">
              أهلاً بك يا غالي! تسلم وإن شاء الله متواجدين في الجلسة الصوتية القادمة 🔥
            </div>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); setMessageInput(''); }} className="flex items-center gap-2">
            <input
              type="text"
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              placeholder="اكتب رسالة خاصة..."
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
            />
            <button type="submit" className="bg-amber-500 p-2 rounded-xl text-slate-950 font-bold">
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
