import React, { useState } from 'react';
import { UserProfile, TransactionRecord, WithdrawalRequest } from '../types';
import { Shield, ShieldCheck, RefreshCw, DollarSign, Users, Mic, Search, KeyRound, Check, X, Clock, Copy, CheckCircle2, AlertCircle, Award, Crown, Phone, Building2, Wallet } from 'lucide-react';

interface AdminPanelModalProps {
  user: UserProfile;
  transactions: TransactionRecord[];
  withdrawalRequests: WithdrawalRequest[];
  onClose: () => void;
  onToggleUserRoomPermission: (userId: string, allowed: boolean) => void;
  onManualAddCoins: (amount: number) => void;
  onUpdateWithdrawalStatus: (requestId: string, newStatus: 'PROCESSING' | 'SUCCESS' | 'REJECTED', rejectionReason?: string) => void;
}

interface WithdrawalRequestAdminCardProps {
  req: WithdrawalRequest;
}

const WithdrawalRequestAdminCard: React.FC<WithdrawalRequestAdminCardProps> = ({ req }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="bg-slate-950 p-4 rounded-3xl border border-slate-800 space-y-4 shadow-xl hover:border-slate-700 transition-all">
      {/* 1. User Personal Identity Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/90 p-3 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src={req.userAvatar}
              alt={req.userName}
              className="w-12 h-12 rounded-full object-cover ring-2 ring-amber-400 shadow-md"
            />
            <span className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 text-[9px] font-black p-0.5 rounded-full">
              <Crown className="w-3 h-3" />
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-sm text-white">{req.userName} (حسابك الشخصي)</span>
              <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                <Award className="w-3 h-3 text-amber-400" />
                مذيع VIP
              </span>
            </div>
            <div className="text-[10px] text-slate-400 font-mono mt-0.5 flex items-center gap-2">
              <span className="text-cyan-300 font-bold">معرف الحساب: {req.userId}</span>
              <span>•</span>
              <span>رقم العملية: {req.id}</span>
            </div>
          </div>
        </div>

        {/* 2. Financial Amount Info */}
        <div className="text-right sm:text-left bg-slate-950 px-3.5 py-2 rounded-xl border border-emerald-500/30">
          <div className="text-[10px] text-slate-400 font-bold">المبلغ المستحق تحويله كاش:</div>
          <div className="font-mono font-black text-emerald-400 text-lg">${req.usdAmount}.00 USD</div>
          <div className="text-[10px] text-amber-300 font-mono font-bold flex items-center gap-1 justify-end sm:justify-start">
            <span>الماسات المخصومة: {req.diamondsAmount.toLocaleString()} 💎</span>
          </div>
        </div>
      </div>

      {/* 3. Payment Gateway & Destination Phone/Account Info */}
      <div className="bg-slate-900 p-3.5 rounded-2xl border border-slate-800 space-y-2 text-xs">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <span className="font-bold text-slate-300 flex items-center gap-1.5">
            <Wallet className="w-4 h-4 text-amber-400" />
            وسيلة التحويل المحددة:
          </span>
          <span className="font-black text-amber-300 bg-amber-500/10 px-2.5 py-0.5 rounded-lg border border-amber-500/30">
            {req.gatewayTitle}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <div>
            <span className="text-slate-400 block text-[10px] font-bold mb-0.5">
              رقم المحفظة / الهاتف المحول إليه:
            </span>
            <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800">
              <span className="font-mono font-bold text-cyan-300 select-all text-xs truncate">
                {req.accountDetails.phoneOrEmailOrIban}
              </span>
              <button
                type="button"
                onClick={() => handleCopy(req.accountDetails.phoneOrEmailOrIban)}
                className="mr-auto px-2 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 text-[10px] font-bold rounded-lg flex items-center gap-1 cursor-pointer transition-colors shrink-0"
              >
                {copied ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'تم النسخ!' : 'نسخ'}</span>
              </button>
            </div>
          </div>

          <div>
            <span className="text-slate-400 block text-[10px] font-bold mb-0.5">
              اسم المستفيد صاحب المحفظة:
            </span>
            <div className="bg-slate-950 p-2 rounded-xl border border-slate-800 text-xs font-bold text-slate-200 truncate">
              {req.accountDetails.beneficiaryName || req.userName}
              {req.accountDetails.bankName ? ` (${req.accountDetails.bankName})` : ''}
            </div>
          </div>
        </div>

        <div className="text-[10px] text-slate-400 flex items-center gap-1 pt-1 font-mono">
          <Clock className="w-3 h-3 text-slate-500" />
          <span>تاريخ طلب التحويل: {req.createdAt}</span>
        </div>
      </div>

      {/* 4. Live Transfer Status Banner (No Approve/Reject buttons) */}
      <div className="pt-2">
        {req.status === 'SUCCESS' ? (
          <div className="bg-emerald-950/80 border border-emerald-500/60 p-3.5 rounded-2xl flex items-center gap-3 shadow-lg">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0 font-black">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-black text-emerald-300 text-xs flex items-center gap-1.5">
                <span>تم تحويل المبلغ بنجاح إلى تلفونك ووصلتك المصاري ✅</span>
              </h4>
              <p className="text-[11px] text-emerald-200/80 mt-0.5">
                تم إيداع مبلغ الكاش (${req.usdAmount} USD) بالكامل في رقم محفظتك الموضح أعلاه وإغلاق المعاملة بنجاح.
              </p>
            </div>
          </div>
        ) : req.status === 'PENDING' || req.status === 'PROCESSING' ? (
          <div className="bg-amber-950/80 border border-amber-500/60 p-3.5 rounded-2xl flex items-center gap-3 shadow-lg">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 flex items-center justify-center shrink-0 font-black relative">
              <Clock className="w-6 h-6 animate-pulse" />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-amber-400 rounded-full animate-ping" />
            </div>
            <div>
              <h4 className="font-black text-amber-300 text-xs flex items-center gap-1.5">
                <span>جاري المعالجة والإنتظار ⏳ (جاري تحويل الأموال إلى تلفونك)</span>
              </h4>
              <p className="text-[11px] text-amber-200/80 mt-0.5">
                طلبك قيد المراجعة والمعالجة، وسيتم إرسال المصاري مباشرة إلى رقم محفظتك الهاتفية خلال مواعيد العمل الرسمية.
              </p>
            </div>
          </div>
        ) : (
          <div className="bg-rose-950/80 border border-rose-500/60 p-3.5 rounded-2xl flex items-center gap-3 shadow-lg">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 flex items-center justify-center shrink-0 font-black">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-black text-rose-300 text-xs">
                تعذر التحويل - تم إعادة الماسات إلى محفظتك ❌
              </h4>
              <p className="text-[11px] text-rose-200/80 mt-0.5">
                {req.rejectionReason || 'السبب: عدم مطابقة رقم المحفظة. تم إرجاع الأرصدة لحسابك لتصحيح البيانات.'}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  user,
  transactions,
  withdrawalRequests,
  onClose,
  onToggleUserRoomPermission,
  onManualAddCoins,
  onUpdateWithdrawalStatus,
}) => {
  const [activeTab, setActiveTab] = useState<'transactions' | 'withdrawals' | 'permissions'>('withdrawals');
  const [manualAmount, setManualAmount] = useState<number>(5000);

  // Compute total sales revenue
  const totalRevenue = transactions.reduce((acc, tx) => acc + tx.priceUsd, 0);
  const totalCoinsSold = transactions.reduce((acc, tx) => acc + tx.amountCoins, 0);
  const pendingWithdrawalsCount = withdrawalRequests.filter((r) => r.status === 'PENDING').length;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 dir-rtl text-right select-none font-sans">
      <div className="w-full max-w-3xl bg-slate-900 border border-red-500/40 rounded-3xl p-5 shadow-2xl space-y-4 text-white max-h-[90vh] overflow-y-auto animate-scaleUp">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-r from-red-600 to-rose-700 text-white flex items-center justify-center font-black shadow-lg">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-black text-base text-red-400">لوحة تحكم إدارة SALEEM (Admin Panel) 👑</h2>
              <p className="text-[11px] text-slate-400">إدارة طلبات سحب الأرباح، شحن Google Play، وتصاريح الغرف</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Analytics Bar */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-slate-950 p-3 rounded-2xl border border-emerald-500/30">
            <span className="text-[10px] text-slate-400 block">إجمالي مبيعات Google</span>
            <span className="font-black text-emerald-400 text-base font-mono">${totalRevenue.toFixed(2)}</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-2xl border border-amber-500/30">
            <span className="text-[10px] text-slate-400 block">طلبات السحب المعلقة</span>
            <span className="font-black text-amber-300 text-base font-mono">{pendingWithdrawalsCount} طلبات ⏳</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-2xl border border-cyan-500/30">
            <span className="text-[10px] text-slate-400 block">صلاحية الغرفة للحساب</span>
            <span className={`font-black text-xs ${user.isAllowedToCreateRoom ? 'text-emerald-400' : 'text-red-400'}`}>
              {user.isAllowedToCreateRoom ? 'مسموح (True)' : 'مقيّد (False)'}
            </span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <button
            onClick={() => setActiveTab('withdrawals')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'withdrawals' ? 'bg-amber-500 text-slate-950 font-black' : 'bg-slate-800 text-slate-300'
            }`}
          >
            طلبات سحب الأرباح ({pendingWithdrawalsCount} معلق) 💎
          </button>
          <button
            onClick={() => setActiveTab('transactions')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'transactions' ? 'bg-red-600 text-white' : 'bg-slate-800 text-slate-300'
            }`}
          >
            سجل مبيعات Google Play
          </button>
          <button
            onClick={() => setActiveTab('permissions')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'permissions' ? 'bg-red-600 text-white' : 'bg-slate-800 text-slate-300'
            }`}
          >
            إدارة الصلاحيات الشحن
          </button>
        </div>

        {/* WITHDRAWALS MANAGEMENT TAB */}
        {activeTab === 'withdrawals' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
              <div>
                <h3 className="font-black text-xs text-amber-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  حالة تحويل الأموال والسحب لحسابك الشخصي ({user.name}):
                </h3>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  متابعة دقيقة لحالة وصول أرباحك إلى هاتفك والمحفظة الخاصة بك حصراً
                </p>
              </div>

              <div className="flex items-center gap-1.5 text-xs font-bold">
                <span className="text-[10px] text-slate-400">حالة الطلبات:</span>
                <span className="px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-black">
                  {withdrawalRequests.filter(r => r.userId === user.id || r.userName === user.name).length} طلبات خاصة بك
                </span>
              </div>
            </div>

            {withdrawalRequests.filter(r => r.userId === user.id || r.userName === user.name).length === 0 ? (
              <div className="bg-slate-950 p-10 rounded-2xl border border-slate-800 text-center text-slate-400 text-xs space-y-2">
                <div className="text-2xl">💎</div>
                <p>لا توجد طلبات سحب أرباح سابقة أو جارية خاصة بحسابك الشخصي حالياً.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {withdrawalRequests
                  .filter(r => r.userId === user.id || r.userName === user.name)
                  .map((req) => (
                    <WithdrawalRequestAdminCard
                      key={req.id}
                      req={req}
                    />
                  ))}
              </div>
            )}
          </div>
        )}

        {/* Transactions Table */}
        {activeTab === 'transactions' && (
          <div className="space-y-2">
            <h3 className="font-bold text-xs text-slate-300">سجل طلبات الشحن عبر Google Play Developer API</h3>
            <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-950">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="p-2.5">رقم الطلب (GPA Order ID)</th>
                    <th className="p-2.5">المستخدم</th>
                    <th className="p-2.5">الحزمة</th>
                    <th className="p-2.5">العملات</th>
                    <th className="p-2.5">السعر</th>
                    <th className="p-2.5">الحالة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-200">
                  {transactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-900/50">
                      <td className="p-2.5 font-mono text-amber-300">{tx.googleOrderId}</td>
                      <td className="p-2.5 font-bold">{tx.userName}</td>
                      <td className="p-2.5">{tx.packageName}</td>
                      <td className="p-2.5 font-mono text-emerald-400">+{tx.amountCoins.toLocaleString()}</td>
                      <td className="p-2.5 font-mono">${tx.priceUsd}</td>
                      <td className="p-2.5">
                        <span className="bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded text-[10px] font-bold border border-emerald-500/30">
                          {tx.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Permissions & Manual Control */}
        {activeTab === 'permissions' && (
          <div className="space-y-4">
            {/* Reset Room Permission Box */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-3">
              <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
                <KeyRound className="w-4 h-4" />
                <span>إعادة تفعيل قيد إنشاء الغرف (is_allowed_to_create_room: true)</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                وفقاً لمواصفات التطبيق، بعد إنشاء غرفة صوتية واحدة يتم تقييد الحساب تلقائياً. يمكنك هنا كمسؤول إعادة تفعيل الصلاحية فورياً للحساب الحقيقي:
              </p>
              <div className="flex items-center justify-between bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                <span className="text-xs font-bold text-white">{user.name} ({user.id})</span>
                <button
                  onClick={() => onToggleUserRoomPermission(user.id, !user.isAllowedToCreateRoom)}
                  className={`px-4 py-2 rounded-xl text-xs font-black shadow transition-all ${
                    user.isAllowedToCreateRoom
                      ? 'bg-emerald-500 text-slate-950'
                      : 'bg-red-600 text-white hover:bg-red-500'
                  }`}
                >
                  {user.isAllowedToCreateRoom ? 'الصلاحية مفعلة ✓' : 'إعادة التفعيل الآن 🔓'}
                </button>
              </div>
            </div>

            {/* Manual Balance Top-up */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-emerald-500/30 space-y-3">
              <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs">
                <DollarSign className="w-4 h-4" />
                <span>التعديل اليدوي للرصيد (الإضافة المباشرة)</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={manualAmount}
                  onChange={(e) => setManualAmount(Number(e.target.value))}
                  className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white w-full"
                />
                <button
                  onClick={() => {
                    onManualAddCoins(manualAmount);
                    alert(`تمت إضافة ${manualAmount} عملة يدوياً لقاعدة البيانات!`);
                  }}
                  className="bg-emerald-500 text-slate-950 font-black text-xs px-5 py-2 rounded-xl whitespace-nowrap"
                >
                  إضافة الرصيد
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

