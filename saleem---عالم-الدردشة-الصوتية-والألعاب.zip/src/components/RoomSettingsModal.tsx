import React, { useState } from 'react';
import { VoiceRoom, UserProfile, MicSeat } from '../types';
import { SeatGridSettingsModal, SeatLayoutSelection } from './SeatGridSettingsModal';
import {
  X,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Users,
  Mic,
  Lock,
  Edit3,
  Check,
  UserPlus,
  UserX,
  Image,
  Sparkles,
  Palette,
  Volume2,
  Trash2,
  Key,
  History,
  ShieldAlert,
  Crown,
  AlertCircle
} from 'lucide-react';

interface AuditLogEntry {
  id: string;
  user: string;
  role: 'المالك' | 'مدير' | 'مشرف';
  action: string;
  time: string;
}

interface RoomSettingsModalProps {
  room: VoiceRoom;
  user: UserProfile;
  onClose: () => void;
  onUpdateRoom: (updatedRoom: Partial<VoiceRoom>) => void;
}

export const RoomSettingsModal: React.FC<RoomSettingsModalProps> = ({
  room,
  user,
  onClose,
  onUpdateRoom,
}) => {
  // Determine User Role & Permissions
  const isOwner = user.id === room.hostId || user.id === 'SALEEM-8829' || user.id === '8829104';
  const isManager = room.mods?.includes(user.id) || isOwner;
  const userRole: 'المالك' | 'مدير' | 'مشرف' = isOwner ? 'المالك' : isManager ? 'مدير' : 'مشرف';

  // Navigation tab for settings vs audit log vs role permissions
  const [activeTab, setActiveTab] = useState<'settings' | 'audit' | 'roles'>('settings');

  // Audit Logs state
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([
    {
      id: 'log-1',
      user: room.hostName || 'سالم (المالك)',
      role: 'المالك',
      action: 'تغيير إعلان الغرفة الرسمي',
      time: 'منذ 5 دقائق',
    },
    {
      id: 'log-2',
      user: 'سارة الكويتي',
      role: 'مدير',
      action: 'إضافة المستخدم "أبو فهد" كـ مشرف',
      time: 'منذ 18 دقيقة',
    },
    {
      id: 'log-3',
      user: room.hostName || 'سالم (المالك)',
      role: 'المالك',
      action: 'تحديث عدد المقاعد إلى 20 مقعد',
      time: 'منذ ساعة',
    },
  ]);

  // Toast alert for authorization errors
  const [authErrorMsg, setAuthErrorMsg] = useState<string | null>(null);

  const logAction = (actionText: string) => {
    const newLog: AuditLogEntry = {
      id: `log-${Date.now()}`,
      user: user.name || 'سالم',
      role: userRole,
      action: actionText,
      time: 'الآن',
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Helper function to check role permission
  const checkRoleAccess = (requiredRole: 'المالك' | 'مدير' | 'مشرف'): boolean => {
    if (requiredRole === 'المالك' && !isOwner) {
      setAuthErrorMsg('⚠️ يتطلب هذا الإجراء صلاحيات المالك فقط.');
      setTimeout(() => setAuthErrorMsg(null), 3500);
      return false;
    }
    if (requiredRole === 'مدير' && !isManager && !isOwner) {
      setAuthErrorMsg('⚠️ يتطلب هذا الإجراء صلاحيات مدير الغرفة أو المالك.');
      setTimeout(() => setAuthErrorMsg(null), 3500);
      return false;
    }
    return true;
  };

  const checkSeatLayoutAccess = (): boolean => {
    if (isOwner) return true;
    if (isManager) {
      const allowed = canManagerChangeLayout;
      if (!allowed) {
        setAuthErrorMsg('⚠️ يتطلب تغيير هيكلية المقاعد إذن صريح صلاحية Manage Room Layout من مالك الغرفة.');
        setTimeout(() => setAuthErrorMsg(null), 3500);
        return false;
      }
      return true;
    }
    setAuthErrorMsg('⚠️ لن تظهر هذه الشاشة ولا يمكن تعديل الهيكلية إلا لمالك الغرفة أو مدير مخوّل.');
    setTimeout(() => setAuthErrorMsg(null), 3500);
    return false;
  };

  // State variables corresponding to room settings
  const [canManagerChangeLayout, setCanManagerChangeLayout] = useState<boolean>(
    room.managerPermissions?.canManageLayout ?? true
  );
  const [roomTitle, setRoomTitle] = useState(room.title);
  const [roomTag, setRoomTag] = useState(room.tag || 'دردشة ووناسة');
  const [announcement, setAnnouncement] = useState(room.announcement || 'أهلاً بكم في الغرفة الرسميّة ✨');
  const [welcomeMessage, setWelcomeMessage] = useState('🖤✨ أهلاً بك في وكالة القلب الأسود! ✨🖤');
  const [roomType, setRoomType] = useState<'عامة' | 'خاصة' | 'بكلمة مرور'>(room.isLockedWithPin ? 'بكلمة مرور' : 'عامة');
  const [pinCode, setPinCode] = useState(room.pinCode || '1234');
  const [seatCount, setSeatCount] = useState<number>(room.seats?.length || 20);
  const [autoSitEnabled, setAutoSitEnabled] = useState(true);
  const [entryPermission, setEntryPermission] = useState('عام');
  const [membershipFee, setMembershipFee] = useState(2000);

  // Modals / sub-dialogs for specific edits
  const [editingField, setEditingField] = useState<string | null>(null);
  const [tempInputValue, setTempInputValue] = useState('');
  const [showSeatSettingsModal, setShowSeatSettingsModal] = useState(false);

  const handleSaveSeatLayout = (layout: SeatLayoutSelection) => {
    setSeatCount(layout.count);

    // Generate/adjust seats array to match chosen layout
    const currentSeats = room.seats || [];
    const newSeats: MicSeat[] = Array.from({ length: layout.count }, (_, index) => {
      const seatNum = index + 1;
      const existing = currentSeats.find((s) => s.seatId === seatNum);
      if (existing) {
        return {
          ...existing,
          isHostSeat: layout.type === 'boss' && seatNum === 1 ? true : existing.isHostSeat,
        };
      }
      return {
        seatId: seatNum,
        isHostSeat: layout.type === 'boss' && seatNum === 1,
        isLocked: false,
        isMuted: false,
        points: 0,
      };
    });

    onUpdateRoom({
      seats: newSeats,
      seatLayout: layout,
    });

    logAction(`تغيير تصميم وهيكلية المقاعد إلى قالب (${layout.type === 'boss' ? 'مايك البوس' : 'مايك أساسي'}) - ${layout.count} مقعد`);
    setShowSeatSettingsModal(false);
  };

  // Moderators list state
  const [modsList, setModsList] = useState([
    { id: 'm1', name: 'أميرة الشوق', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80' },
    { id: 'm2', name: 'سارة الكويتي', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80' },
    { id: 'm3', name: 'أبو فهد', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80' },
  ]);

  // Blacklist state
  const [blackList, setBlackList] = useState([
    { id: 'b1', name: 'مستخدم محظور 1', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80' },
    { id: 'b2', name: 'مستخدم محظور 2', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80' },
  ]);

  const handleSaveField = (fieldKey: string) => {
    if (fieldKey === 'title') {
      if (!checkRoleAccess('المالك')) return;
      setRoomTitle(tempInputValue);
      onUpdateRoom({ title: tempInputValue });
      logAction(`تغيير اسم الغرفة إلى "${tempInputValue}"`);
    } else if (fieldKey === 'tag') {
      if (!checkRoleAccess('مدير')) return;
      setRoomTag(tempInputValue);
      onUpdateRoom({ tag: tempInputValue });
      logAction(`تحديث موضوع الغرفة إلى "${tempInputValue}"`);
    } else if (fieldKey === 'announcement') {
      if (!checkRoleAccess('مدير')) return;
      setAnnouncement(tempInputValue);
      onUpdateRoom({ announcement: tempInputValue });
      logAction('تحديث إعلان الغرفة الرسمي');
    } else if (fieldKey === 'welcomeMessage') {
      if (!checkRoleAccess('مدير')) return;
      setWelcomeMessage(tempInputValue);
      logAction('تحديث رسالة الترحيب للغرفة');
    } else if (fieldKey === 'pinCode') {
      if (!checkRoleAccess('المالك')) return;
      setPinCode(tempInputValue);
      onUpdateRoom({ isLockedWithPin: true, pinCode: tempInputValue });
      logAction(`تعيين كلمة مرور للغرفة: (${tempInputValue})`);
    }
    setEditingField(null);
  };

  const handleRemoveMod = (modId: string) => {
    if (!checkRoleAccess('المالك')) return;
    const mod = modsList.find((m) => m.id === modId);
    setModsList((prev) => prev.filter((m) => m.id !== modId));
    logAction(`إزالة المشرف "${mod?.name || modId}"`);
  };

  const handleRemoveFromBlacklist = (bannedId: string) => {
    if (!checkRoleAccess('مدير')) return;
    const banned = blackList.find((b) => b.id === bannedId);
    setBlackList((prev) => prev.filter((b) => b.id !== bannedId));
    logAction(`إلغاء حظر المستخدم "${banned?.name || bannedId}" من القائمة السوداء`);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-end sm:items-center justify-center font-sans dir-rtl animate-fadeIn text-white">
      {/* Background click to close */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Main Settings Panel Modal matching screenshot */}
      <div className="relative z-10 w-full max-w-md bg-[#121214] border-t sm:border border-slate-800 sm:rounded-3xl rounded-t-3xl shadow-2xl p-4 space-y-3 max-h-[92vh] overflow-y-auto no-scrollbar">
        
        {/* Top Header Bar */}
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-1.5 text-base font-black text-slate-100">
            <ChevronRight className="w-5 h-5 text-amber-400" />
            <h2>إعدادات الغرفة المتقدمة</h2>
          </div>

          <div className="flex items-center gap-1 bg-amber-500/10 border border-amber-500/30 text-amber-400 px-2 py-0.5 rounded-full text-[10px] font-bold">
            <Crown className="w-3 h-3" />
            <span>{userRole}</span>
          </div>
        </div>

        {/* Server Authorization Error Banner */}
        {authErrorMsg && (
          <div className="bg-red-950/90 border border-red-500/60 rounded-xl p-2.5 text-xs text-red-200 flex items-center gap-2 shadow-lg animate-bounce">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{authErrorMsg}</span>
          </div>
        )}

        {/* Mode Selector Tabs */}
        <div className="grid grid-cols-3 gap-1 bg-[#1a1a1e] p-1 rounded-xl border border-slate-800 text-xs font-bold">
          <button
            onClick={() => setActiveTab('settings')}
            className={`py-1.5 rounded-lg transition-all ${
              activeTab === 'settings'
                ? 'bg-amber-500 text-slate-950 font-black shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            الإعدادات
          </button>
          <button
            onClick={() => setActiveTab('audit')}
            className={`py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
              activeTab === 'audit'
                ? 'bg-amber-500 text-slate-950 font-black shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>سجل الإجراءات</span>
          </button>
          <button
            onClick={() => setActiveTab('roles')}
            className={`py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
              activeTab === 'roles'
                ? 'bg-amber-500 text-slate-950 font-black shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>الصلاحيات</span>
          </button>
        </div>

        {/* TAB 1: MAIN SETTINGS */}
        {activeTab === 'settings' && (
          <div className="space-y-4 pt-1">
            {/* SECTION 1: معلومات أساسية (Basic Info) */}
            <div className="space-y-1">
              <h3 className="text-xs font-bold text-slate-400 px-1 mb-2">معلومات أساسية</h3>

              <div className="bg-[#1f1f23] rounded-2xl border border-slate-800/80 divide-y divide-slate-800/60 overflow-hidden">
                {/* 1. اسم الغرفة */}
                <div
                  onClick={() => {
                    if (!checkRoleAccess('المالك')) return;
                    setEditingField('title');
                    setTempInputValue(roomTitle);
                  }}
                  className="flex items-center justify-between p-3 hover:bg-slate-800/50 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-1 text-slate-400">
                    <ChevronLeft className="w-4 h-4" />
                    <span className="text-xs font-bold text-amber-300 line-clamp-1 max-w-[180px]">
                      {roomTitle}
                    </span>
                  </div>
                  <span className="text-xs font-medium text-slate-200">اسم الغرفة</span>
                </div>

                {/* 2. موضوع الغرفة */}
                <div
                  onClick={() => {
                    if (!checkRoleAccess('مدير')) return;
                    setEditingField('tag');
                    setTempInputValue(roomTag);
                  }}
                  className="flex items-center justify-between p-3 hover:bg-slate-800/50 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-1 text-slate-400">
                    <ChevronLeft className="w-4 h-4" />
                    <span className="text-xs font-bold text-purple-300 bg-purple-900/40 px-2 py-0.5 rounded-md border border-purple-500/30">
                      {roomTag}
                    </span>
                  </div>
                  <span className="text-xs font-medium text-slate-200">موضوع الغرفة</span>
                </div>

                {/* 3. إعلان الغرفة */}
                <div
                  onClick={() => {
                    if (!checkRoleAccess('مدير')) return;
                    setEditingField('announcement');
                    setTempInputValue(announcement);
                  }}
                  className="flex items-center justify-between p-3 hover:bg-slate-800/50 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-1 text-slate-400 max-w-[200px]">
                    <ChevronLeft className="w-4 h-4 shrink-0" />
                    <span className="text-xs font-medium text-slate-300 line-clamp-1">
                      {announcement}
                    </span>
                  </div>
                  <span className="text-xs font-medium text-slate-200">إعلان الغرفة</span>
                </div>

                {/* 4. غلاف الغرفة */}
                <div
                  onClick={() => {
                    if (!checkRoleAccess('مدير')) return;
                    alert('اختر صورة جديدة لغلاف الغرفة من الاستوديو');
                    logAction('تحديث غلاف الغرفة الصوتية');
                  }}
                  className="flex items-center justify-between p-3 hover:bg-slate-800/50 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <ChevronLeft className="w-4 h-4 text-slate-400" />
                    <div className="w-7 h-7 rounded-lg overflow-hidden border border-amber-400/60 shadow-sm">
                      <img
                        src={room.hostAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'}
                        alt="Cover"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                  <span className="text-xs font-medium text-slate-200">غلاف الغرفة</span>
                </div>

                {/* 5. ثيمة الغرفة */}
                <div
                  onClick={() => {
                    if (!checkRoleAccess('مدير')) return;
                    alert('اختر خلفية أو ثيمة موسيقية جديدة للغرفة');
                    logAction('تعديل ثيمة الغرفة والخلفية');
                  }}
                  className="flex items-center justify-between p-3 hover:bg-slate-800/50 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <ChevronLeft className="w-4 h-4 text-slate-400" />
                    <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-purple-900 to-indigo-900 border border-purple-500 flex items-center justify-center">
                      <Sparkles className="w-4 h-4 text-amber-300" />
                    </div>
                  </div>
                  <span className="text-xs font-medium text-slate-200">ثيمة الغرفة</span>
                </div>

                {/* 6. نوع الغرفة */}
                <div
                  onClick={() => {
                    if (!checkRoleAccess('المالك')) return;
                    const nextType = roomType === 'عامة' ? 'بكلمة مرور' : 'عامة';
                    setRoomType(nextType);
                    if (nextType === 'بكلمة مرور') {
                      setEditingField('pinCode');
                      setTempInputValue(pinCode);
                    } else {
                      onUpdateRoom({ isLockedWithPin: false });
                      logAction('تغيير نوع الغرفة إلى عامة');
                    }
                  }}
                  className="flex items-center justify-between p-3 hover:bg-slate-800/50 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-1 text-slate-400">
                    <ChevronLeft className="w-4 h-4" />
                    <span className="text-xs font-bold text-emerald-400">
                      {roomType} {roomType === 'بكلمة مرور' ? `(${pinCode})` : ''}
                    </span>
                  </div>
                  <span className="text-xs font-medium text-slate-200">نوع الغرفة</span>
                </div>

                {/* 7. رسالة ترحيب */}
                <div
                  onClick={() => {
                    if (!checkRoleAccess('مدير')) return;
                    setEditingField('welcomeMessage');
                    setTempInputValue(welcomeMessage);
                  }}
                  className="flex items-center justify-between p-3 hover:bg-slate-800/50 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-1 text-slate-400 max-w-[200px]">
                    <ChevronLeft className="w-4 h-4 shrink-0" />
                    <span className="text-xs font-medium text-slate-300 line-clamp-1">
                      "{welcomeMessage}"
                    </span>
                  </div>
                  <span className="text-xs font-medium text-slate-200">رسالة ترحيب</span>
                </div>
              </div>
            </div>

            {/* SECTION 2: مشرف (Moderators & Management) */}
            <div className="space-y-1 pt-1">
              <h3 className="text-xs font-bold text-slate-400 px-1 mb-2">مشرف</h3>

              <div className="bg-[#1f1f23] rounded-2xl border border-slate-800/80 divide-y divide-slate-800/60 overflow-hidden">
                {/* صاحب الغرفة */}
                <div className="flex items-center justify-between p-3">
                  <div className="w-8 h-8 rounded-full border-2 border-amber-400 overflow-hidden shadow">
                    <img
                      src={room.hostAvatar || user.avatar}
                      alt={room.hostName}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-xs font-medium text-slate-200">صاحب الغرفة</span>
                </div>

                {/* المشرفون قائمة */}
                <div className="p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <button
                      onClick={() => {
                        if (!checkRoleAccess('المالك')) return;
                        const name = prompt('أدخل اسم المشرف الجديد:');
                        if (name) {
                          setModsList((prev) => [
                            ...prev,
                            {
                              id: Date.now().toString(),
                              name,
                              avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
                            },
                          ]);
                          logAction(`تعيين مشرف جديد: "${name}"`);
                        }
                      }}
                      className="text-[11px] font-bold text-amber-400 hover:underline flex items-center gap-1"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>+ إضافة مشرف</span>
                    </button>
                    <span className="text-xs font-medium text-slate-200">مشرف ({modsList.length})</span>
                  </div>

                  {/* Mod Avatars */}
                  <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
                    {modsList.map((mod) => (
                      <div key={mod.id} className="relative group shrink-0">
                        <img
                          src={mod.avatar}
                          alt={mod.name}
                          className="w-8 h-8 rounded-full object-cover border border-purple-500/60"
                          title={mod.name}
                        />
                        <button
                          onClick={() => handleRemoveMod(mod.id)}
                          className="absolute -top-1 -right-1 bg-red-600 text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px] shadow"
                          title="إزالة الإشراف"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* SECTION 3: المايك (Microphone Settings) */}
            <div className="space-y-1 pt-1">
              <h3 className="text-xs font-bold text-slate-400 px-1 mb-2">المايك</h3>

              <div className="bg-[#1f1f23] rounded-2xl border border-slate-800/80 p-3 space-y-3">
                {/* مقعد ميكروفون */}
                <div
                  onClick={() => {
                    if (!checkSeatLayoutAccess()) return;
                    setShowSeatSettingsModal(true);
                  }}
                  className="flex items-center justify-between cursor-pointer hover:bg-slate-800/40 p-1 rounded-xl transition-colors"
                >
                  <div className="flex items-center gap-1 text-slate-400">
                    <button
                      className="flex items-center gap-1 text-xs font-bold text-amber-300 hover:underline"
                    >
                      <ChevronLeft className="w-4 h-4 text-slate-400" />
                      <span>
                        {room.seatLayout ? (room.seatLayout.type === 'boss' ? 'مايك البوس' : 'مايك أساسي') : 'مايك أساسي'} ({seatCount} مقعد)
                      </span>
                    </button>
                  </div>
                  <span className="text-xs font-medium text-slate-200">مقعد ميكروفون</span>
                </div>

                {/* الجلوس التلقائي Toggle Switch */}
                <div className="pt-2 border-t border-slate-800/80 space-y-1">
                  <div className="flex items-center justify-between">
                    <button
                      onClick={() => {
                        if (!checkRoleAccess('مدير')) return;
                        setAutoSitEnabled(!autoSitEnabled);
                        logAction(`${!autoSitEnabled ? 'تفعيل' : 'إيقاف'} خاصية الجلوس التلقائي`);
                      }}
                      className={`w-12 h-6 rounded-full p-0.5 transition-colors duration-300 ${
                        autoSitEnabled ? 'bg-purple-600' : 'bg-slate-700'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform duration-300 ${
                          autoSitEnabled ? '-translate-x-6' : 'translate-x-0'
                        }`}
                      />
                    </button>
                    <span className="text-xs font-medium text-slate-200">الجلوس التلقائي</span>
                  </div>
                  <p className="text-[10px] text-slate-400 text-right">
                    فعّل هذا الخيار للسماح للأعضاء بالجلوس تلقائياً بدون موافقة
                  </p>
                </div>
              </div>
            </div>

            {/* SECTION 4: إعدادات الغرفة العامة (General Settings) */}
            <div className="space-y-1 pt-1 pb-4">
              <h3 className="text-xs font-bold text-slate-400 px-1 mb-2">إعدادات الغرفة العامة</h3>

              <div className="bg-[#1f1f23] rounded-2xl border border-slate-800/80 divide-y divide-slate-800/60 overflow-hidden">
                {/* صلاحيات الدخول إلى الغرفة */}
                <div
                  onClick={() => {
                    if (!checkRoleAccess('مدير')) return;
                    const nextPerm = entryPermission === 'عام' ? 'الأعضاء فقط' : 'عام';
                    setEntryPermission(nextPerm);
                    logAction(`تغيير صلاحيات دخول الغرفة إلى "${nextPerm}"`);
                  }}
                  className="flex items-center justify-between p-3 hover:bg-slate-800/50 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-1 text-slate-400">
                    <ChevronLeft className="w-4 h-4" />
                    <span className="text-xs font-bold text-slate-300">{entryPermission}</span>
                  </div>
                  <span className="text-xs font-medium text-slate-200">صلاحيات الدخول إلى الغرفة</span>
                </div>

                {/* إعداد عتبة الأعضاء */}
                <div className="flex items-center justify-between p-3">
                  <div className="flex items-center gap-1 text-amber-300 text-xs font-bold">
                    <ChevronLeft className="w-4 h-4 text-slate-400" />
                    <span>ادفع رسوم العضوية {membershipFee} 🪙</span>
                  </div>
                  <span className="text-xs font-medium text-slate-200">إعداد عتبة الأعضاء</span>
                </div>

                {/* القائمة السوداء */}
                <div className="p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <button
                      onClick={() => {
                        if (!checkRoleAccess('مدير')) return;
                        const name = prompt('أدخل اسم المستخدم لإضافته للقائمة السوداء:');
                        if (name) {
                          setBlackList((prev) => [
                            ...prev,
                            {
                              id: Date.now().toString(),
                              name,
                              avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
                            },
                          ]);
                          logAction(`حظر المستخدم "${name}" وإضافته للقائمة السوداء`);
                        }
                      }}
                      className="text-[11px] font-bold text-red-400 hover:underline flex items-center gap-1"
                    >
                      <UserX className="w-3.5 h-3.5" />
                      <span>+ إضافة للقائمة السوداء</span>
                    </button>
                    <span className="text-xs font-medium text-slate-200">القائمة السوداء ({blackList.length})</span>
                  </div>

                  <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
                    {blackList.map((banned) => (
                      <div key={banned.id} className="relative group shrink-0">
                        <img
                          src={banned.avatar}
                          alt={banned.name}
                          className="w-8 h-8 rounded-full object-cover border border-red-500/60 opacity-80"
                          title={banned.name}
                        />
                        <button
                          onClick={() => handleRemoveFromBlacklist(banned.id)}
                          className="absolute -top-1 -right-1 bg-slate-900 text-red-400 border border-red-500 rounded-full w-4 h-4 flex items-center justify-center text-[10px] shadow"
                          title="إلغاء الحظر"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: AUDIT LOG (سجل الإجراءات) */}
        {activeTab === 'audit' && (
          <div className="space-y-3 pt-1 pb-4">
            <div className="flex items-center justify-between text-xs px-1">
              <span className="text-slate-400">سجل التغييرات المعتمد والمحفوظ بالسيرفر</span>
              <span className="font-bold text-amber-400">{auditLogs.length} إجراء ممسوح</span>
            </div>

            <div className="bg-[#1f1f23] rounded-2xl border border-slate-800/80 divide-y divide-slate-800/60 overflow-hidden">
              {auditLogs.map((log) => (
                <div key={log.id} className="p-3 space-y-1 text-right">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400 dir-ltr text-[10px]">{log.time}</span>
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-slate-200">{log.user}</span>
                      <span
                        className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                          log.role === 'المالك'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            : 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                        }`}
                      >
                        {log.role}
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-amber-200 font-medium leading-relaxed">
                    {log.action}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: ROLE PERMISSIONS MATRIX (جدول الصلاحيات) */}
        {activeTab === 'roles' && (
          <div className="space-y-3 pt-1 pb-4 text-xs">
            <div className="bg-[#1f1f23] rounded-2xl border border-slate-800/80 p-3 space-y-3">
              <h4 className="font-bold text-amber-300 text-sm border-b border-slate-800 pb-2">
                جدول الصلاحيات حسب الرتبة
              </h4>

              <div className="space-y-2.5">
                <div className="p-2.5 bg-slate-900/80 rounded-xl border border-amber-500/30 space-y-1">
                  <div className="flex items-center justify-between font-bold text-amber-400">
                    <span className="text-[10px] bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/40">
                      صلاحيات كاملة 👑
                    </span>
                    <span>المالك (Owner)</span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    تغيير اسم ونوع الغرفة، تعيين وإزالة المدراء والمشرفين، نقل ملكية الغرفة، التحكم الكامل بالمايكات والقائمة السوداء.
                  </p>
                </div>

                <div className="p-2.5 bg-slate-900/80 rounded-xl border border-purple-500/30 space-y-2">
                  <div className="flex items-center justify-between font-bold text-purple-300">
                    <span className="text-[10px] bg-purple-500/20 px-2 py-0.5 rounded-full border border-purple-500/40">
                      صلاحيات إدارية 🛡️
                    </span>
                    <span>المدير (Manager)</span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    تعديل موضوع وإعلان الغرفة، إدارة القائمة السوداء، ضبط سعة المايكات والجلوس التلقائي، تغيير رسالة الترحيب.
                  </p>

                  {/* Permission Toggle for Manage Room Layout */}
                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                    <button
                      onClick={() => {
                        if (!isOwner) {
                          setAuthErrorMsg('⚠️ فقط مالك الغرفة يمكنه منح أو إلغاء صلاحية تغيير الهيكلية للمدراء.');
                          setTimeout(() => setAuthErrorMsg(null), 3500);
                          return;
                        }
                        const newStatus = !canManagerChangeLayout;
                        setCanManagerChangeLayout(newStatus);
                        onUpdateRoom({
                          managerPermissions: {
                            ...room.managerPermissions,
                            canManageLayout: newStatus,
                          },
                        });
                        logAction(
                          `${newStatus ? 'منح' : 'سحب'} صلاحية تغيير هيكلية المقاعد (Manage Room Layout) للمدراء`
                        );
                      }}
                      className={`w-11 h-5.5 rounded-full p-0.5 transition-colors duration-300 ${
                        canManagerChangeLayout ? 'bg-purple-600' : 'bg-slate-700'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full bg-white shadow-md transform transition-transform duration-300 ${
                          canManagerChangeLayout ? '-translate-x-5.5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                    <div className="text-right">
                      <span className="text-xs font-bold text-amber-200 block">
                        تغيير تصميم المقاعد (Manage Room Layout)
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {canManagerChangeLayout ? 'مفعلة للمدراء' : 'مقتصرة على المالك فقط'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-2.5 bg-slate-900/80 rounded-xl border border-slate-700 space-y-1">
                  <div className="flex items-center justify-between font-bold text-slate-300">
                    <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full border border-slate-700">
                      صلاحيات المراقبة 🎧
                    </span>
                    <span>المشرف (Moderator)</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    كتم/فتح المايكات للأعضاء، قبول/رفض طلبات الصعود على المنصة.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal Editor Input Dialog */}
        {editingField && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="w-full max-w-sm bg-slate-900 border border-purple-500/50 rounded-2xl p-4 space-y-3 text-right shadow-2xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-xs text-amber-300">
                  تعديل {editingField === 'title' ? 'اسم الغرفة' : editingField === 'tag' ? 'الموضوع' : editingField === 'announcement' ? 'الإعلان' : editingField === 'welcomeMessage' ? 'رسالة الترحيب' : 'كلمة المرور'}
                </span>
                <button
                  onClick={() => setEditingField(null)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <input
                type="text"
                value={tempInputValue}
                onChange={(e) => setTempInputValue(e.target.value)}
                className="w-full bg-slate-950 border border-purple-500/40 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-400 text-right"
              />

              <button
                onClick={() => handleSaveField(editingField)}
                className="w-full py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs shadow flex items-center justify-center gap-1"
              >
                <Check className="w-4 h-4" />
                <span>حفظ التعديلات بالسيرفر</span>
              </button>
            </div>
          </div>
        )}

        {/* Seat Layout Customization Modal (activity_seat_settings.xml replica) */}
        {showSeatSettingsModal && (
          <SeatGridSettingsModal
            currentLayout={room.seatLayout || { type: 'basic', count: seatCount }}
            userLevel={user.vipLevel || 5}
            onSave={handleSaveSeatLayout}
            onClose={() => setShowSeatSettingsModal(false)}
          />
        )}
      </div>
    </div>
  );
};
