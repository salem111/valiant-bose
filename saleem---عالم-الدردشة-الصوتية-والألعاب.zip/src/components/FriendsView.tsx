import React from 'react';
import { Users, UserPlus, Heart, Mic } from 'lucide-react';

export const FriendsView: React.FC = () => {
  const FRIENDS = [
    { id: 1, name: 'الشيخ خالد 👑', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80', status: 'في غرفة صوتية نشطة', roomTitle: 'ملتقى كبار VIP' },
    { id: 2, name: 'أميرة الشوق', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80', status: 'متصل الآن', roomTitle: 'في الصفحة الرئيسية' },
    { id: 3, name: 'الكابتن علي', avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80', status: 'يلعب طرنيب', roomTitle: 'طاولة الرهان 🃏' },
  ];

  return (
    <div id="saleem-friends-view" className="space-y-3 text-right">
      <div className="bg-slate-900 p-3 rounded-2xl border border-amber-500/30 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-amber-400" />
          <h2 className="font-black text-sm text-amber-300">الأصدقاء والمتابعين (Friends & Following) 👥</h2>
        </div>
        <button className="flex items-center gap-1 bg-amber-500 text-slate-950 px-3 py-1 rounded-xl text-xs font-bold">
          <UserPlus className="w-3.5 h-3.5" />
          <span>إضافة صديق</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {FRIENDS.map((f) => (
          <div key={f.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src={f.avatar} alt={f.name} className="w-12 h-12 rounded-full object-cover ring-2 ring-amber-400" />
              <div>
                <h4 className="font-bold text-xs text-white">{f.name}</h4>
                <p className="text-[10px] text-emerald-400 font-bold flex items-center gap-1 mt-0.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  {f.status}
                </p>
                <span className="text-[9px] text-slate-400">{f.roomTitle}</span>
              </div>
            </div>

            <button className="p-2 rounded-xl bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-amber-300 font-bold text-xs transition-colors">
              متابعة
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
