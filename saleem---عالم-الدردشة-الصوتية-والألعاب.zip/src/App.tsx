import React, { useState, useEffect } from 'react';
import { UserProfile, VoiceRoom, MainTab, TransactionRecord, GiftItem, WithdrawalRequest } from './types';
import { INITIAL_USER, MOCK_ROOMS, INITIAL_TRANSACTIONS, INITIAL_WITHDRAWAL_REQUESTS } from './data/mockData';
import { saveUserToFirebase, updateUserLogoutStatusInFirebase, normalizeProvider, getUserFromFirebase } from './lib/firebase';
import { Header } from './components/Header';
import { Banner } from './components/Banner';
import { QuickCategories } from './components/QuickCategories';
import { RoomTabs } from './components/RoomTabs';
import { RoomCard } from './components/RoomCard';
import { VoiceRoomModal } from './components/VoiceRoomModal';
import { CreateRoomModal } from './components/CreateRoomModal';
import { LiveStreamModal } from './components/LiveStreamModal';
import { MiniGamesModal } from './components/MiniGamesModal';
import { CoinStoreModal } from './components/CoinStoreModal';
import { WithdrawalModal } from './components/WithdrawalModal';
import { VipModal } from './components/VipModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { DirectChatsView } from './components/DirectChatsView';
import { FriendsView } from './components/FriendsView';
import { ProfileView } from './components/ProfileView';
import { SplashScreen } from './components/SplashScreen';
import { LoginScreen } from './components/LoginScreen';
import { BottomNav } from './components/BottomNav';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [showLogin, setShowLogin] = useState(false);

  // Initialize User from localStorage
  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('saleem_saved_user');
      if (saved) {
        return { ...INITIAL_USER, ...JSON.parse(saved) };
      }
    } catch (e) {
      console.error('Error parsing saved user', e);
    }
    return INITIAL_USER;
  });

  // Verify server authentication status on load: prevent automatic direct login from mock or stale local storage
  useEffect(() => {
    let isMounted = true;
    const verifyServerAuth = async () => {
      try {
        const savedRaw = localStorage.getItem('saleem_saved_user');
        if (savedRaw) {
          const parsed = JSON.parse(savedRaw);
          if (parsed && parsed.id) {
            // Verify real user account on Firebase Firestore server
            const serverUser = await getUserFromFirebase(parsed.id);
            if (serverUser && serverUser.isLoggedIn !== false && (serverUser as any).id) {
              if (isMounted) {
                setUser((prev) => ({ ...prev, ...serverUser }));
                setShowLogin(false);
                return;
              }
            }
          }
        }
      } catch (err) {
        console.error('Error verifying user auth with Firestore:', err);
      }

      // If no verified user found on the server, force open login screen
      if (isMounted) {
        localStorage.removeItem('saleem_saved_user');
        setShowLogin(true);
      }
    };

    verifyServerAuth();

    return () => {
      isMounted = false;
    };
  }, []);

  // Initialize Rooms from localStorage to persist created rooms across browser reloads
  const [rooms, setRooms] = useState<VoiceRoom[]>(() => {
    try {
      const saved = localStorage.getItem('saleem_saved_rooms');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const savedIds = new Set(parsed.map((r: VoiceRoom) => r.id));
          const mocksNotInSaved = MOCK_ROOMS.filter((m) => !savedIds.has(m.id));
          return [...parsed, ...mocksNotInSaved];
        }
      }
    } catch (e) {
      console.error('Error parsing saved rooms', e);
    }
    return MOCK_ROOMS;
  });

  const [transactions, setTransactions] = useState<TransactionRecord[]>(INITIAL_TRANSACTIONS);
  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>(INITIAL_WITHDRAWAL_REQUESTS);

  // Sync state updates to localStorage & Firebase Firestore
  useEffect(() => {
    try {
      localStorage.setItem('saleem_saved_user', JSON.stringify(user));
    } catch (e) {
      console.error('Error saving user to localStorage', e);
    }

    // Save user to Firebase Firestore whenever user changes (if user and user.id exist)
    if (user && user.id) {
      saveUserToFirebase(user);
    }
  }, [user]);

  // Update Firebase logout status when page is closed/refreshed
  useEffect(() => {
    const handleBeforeUnload = () => {
      if (user && user.id) {
        updateUserLogoutStatusInFirebase(user);
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [user]);

  useEffect(() => {
    try {
      localStorage.setItem('saleem_saved_rooms', JSON.stringify(rooms));
    } catch (e) {
      console.error('Error saving rooms', e);
    }
  }, [rooms]);

  // Navigation & Filter States
  const [mainTab, setMainTab] = useState<MainTab>('home');
  const [roomCategoryTab, setRoomCategoryTab] = useState<'غرف شائعة' | 'غرف جديدة' | 'متابعة'>('غرف شائعة');
  const [searchQuery, setSearchQuery] = useState('');

  // Active Modals States
  const [activeVoiceRoom, setActiveVoiceRoom] = useState<VoiceRoom | null>(null);
  const [showCreateRoomModal, setShowCreateRoomModal] = useState(false);
  const [showLiveStreamModal, setShowLiveStreamModal] = useState(false);
  const [showGamesModal, setShowGamesModal] = useState(false);
  const [showCoinStoreModal, setShowCoinStoreModal] = useState(false);
  const [showWithdrawalModal, setShowWithdrawalModal] = useState(false);
  const [showVipModal, setShowVipModal] = useState(false);
  const [showLeaderboardModal, setShowLeaderboardModal] = useState(false);
  const [showAdminPanelModal, setShowAdminPanelModal] = useState(false);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  // Coin & Diamond balance handlers
  const handleUpdateCoins = (delta: number) => {
    setUser((prev) => ({
      ...prev,
      coins: Math.max(0, prev.coins + delta),
    }));
  };

  const handleUpdateDiamonds = (delta: number) => {
    setUser((prev) => ({
      ...prev,
      diamonds: Math.max(0, prev.diamonds + delta),
    }));
  };

  const handleSubmitWithdrawalRequest = (newReq: WithdrawalRequest) => {
    setWithdrawalRequests((prev) => [newReq, ...prev]);
    showToast(`تم تقديم طلب السحب رقم ${newReq.id} بنجاح!`);
  };

  const handleUpdateWithdrawalStatus = (
    requestId: string,
    newStatus: 'PROCESSING' | 'SUCCESS' | 'REJECTED',
    rejectionReason?: string
  ) => {
    setWithdrawalRequests((prev) =>
      prev.map((req) => {
        if (req.id === requestId) {
          if (newStatus === 'REJECTED' && req.status !== 'REJECTED') {
            handleUpdateDiamonds(req.diamondsAmount);
            showToast(`تم رفض الطلب ${req.id} وإعادة ${req.diamondsAmount.toLocaleString()} ألماسة لحسابك!`);
          } else if (newStatus === 'SUCCESS') {
            showToast(`تمت الموافقة على طلب السحب ${req.id} وتحويل المبلغ بنجاح! 🎉`);
          }
          return { ...req, status: newStatus, rejectionReason };
        }
        return req;
      })
    );
  };

  const handlePurchaseCoinsSuccess = (coinsAdded: number, tx: TransactionRecord) => {
    handleUpdateCoins(coinsAdded);
    setTransactions((prev) => [tx, ...prev]);
  };

  // One-time Room creation handler
  const handleCreateRoomSuccess = (newRoom: VoiceRoom) => {
    setRooms((prev) => [newRoom, ...prev]);
    setUser((prev) => ({
      ...prev,
      isAllowedToCreateRoom: false, // Enforce one-time room creation constraint
      hasActiveRoom: true, // (تحتوي على غرفة == صحيح)
      roomName: newRoom.title,
      createdRoomId: newRoom.id,
      levelStatus: 'ليفل 2', // Dynamically advance membership level
    }));
    setRoomCategoryTab(newRoom.category as any);
    setShowCreateRoomModal(false);
    setActiveVoiceRoom(newRoom); // Transport user immediately inside their new room
  };

  // Logic for Agency / Create Room button click according to specifications
  const handleOpenAgencies = () => {
    if (!user.hasActiveRoom) {
      // (قيمة "تحتوي على غرفة" == خطأ أو فارغة): افتح صفحة إنشاء غرفة
      setShowCreateRoomModal(true);
    } else {
      // (قيمة "تحتوي على غرفة" == صحيح): اعرض تنبيه وحول المستخدم مباشرة لغرفته
      showToast('لا يمكنك إنشاء غرفة جديدة لأنك تمتلك غرفة بالفعل!');

      const userRoom = rooms.find(
        (r) => r.id === user.createdRoomId || r.hostId === user.id || r.hostName === user.name
      );

      if (userRoom) {
        setActiveVoiceRoom(userRoom);
      } else {
        const fallbackRoom: VoiceRoom = {
          id: user.createdRoomId || `room-${user.id}`,
          title: user.roomName || `غرفة ${user.name}`,
          announcement: 'أهلاً بك في غرفتك الصوتية المباشرة!',
          backgroundUrl: user.avatar,
          hostId: user.id,
          hostName: user.name,
          hostAvatar: user.avatar,
          category: 'غرف جديدة',
          tag: 'دردشة',
          level: 1,
          rank: 1,
          listenersCount: 1,
          isLockedWithPin: false,
          mods: [],
          messages: [],
          seats: Array.from({ length: 20 }, (_, index) => {
            const seatNum = index + 1;
            if (seatNum === 1) {
              return {
                seatId: 1,
                isHostSeat: true,
                isLocked: false,
                isMuted: false,
                points: 0,
                speakerUser: {
                  id: user.id,
                  name: user.name,
                  avatar: user.avatar,
                  isSpeaking: true,
                  role: 'مقدم',
                },
              };
            }
            return {
              seatId: seatNum,
              isHostSeat: false,
              isLocked: false,
              isMuted: false,
              points: 0,
            };
          }),
        };
        setActiveVoiceRoom(fallbackRoom);
      }
    }
  };

  // Admin permission toggle for one-time room creation
  const handleToggleUserRoomPermission = (userId: string, allowed: boolean) => {
    setUser((prev) => ({
      ...prev,
      isAllowedToCreateRoom: allowed,
    }));
  };

  const handleUpdateUser = (updatedProps: Partial<UserProfile>) => {
    setUser((prev) => {
      const updated = { ...prev, ...updatedProps };
      if (updated && updated.id) {
        saveUserToFirebase(updated);
      }
      return updated;
    });
  };

  const handleLoginSuccess = async (rawProvider: string) => {
    const normalized = normalizeProvider(rawProvider);
    const loggedInUser: UserProfile = {
      ...user,
      provider: normalized.original || rawProvider,
    };

    setUser(loggedInUser);
    setShowLogin(false);

    if (loggedInUser && loggedInUser.id) {
      await saveUserToFirebase(loggedInUser);
      showToast(`تم تسجيل الدخول بنجاح عبر ${normalized.displayName}! وحفظ البيانات في Firebase 👑`);
    } else {
      showToast(`تم تسجيل الدخول بنجاح عبر ${normalized.displayName}!`);
    }
  };

  const handleLogout = async () => {
    // CRITICAL CHECK: Always verify user and user.id exist before updating logout status in Firebase
    if (user && user.id) {
      await updateUserLogoutStatusInFirebase(user);
    } else {
      console.warn('⚠️ [App] user or user.id is missing during logout.');
    }

    localStorage.removeItem('saleem_saved_user');
    setShowLogin(true);
    showToast('تم تسجيل الخروج بنجاح وتحديث الحالة في Firebase 👋');
  };

  const handleManualAddCoins = (amount: number) => {
    handleUpdateCoins(amount);
  };

  const handleSendGift = (gift: GiftItem, recipientName: string) => {
    if (user.coins < gift.priceCoins) {
      alert('رصيد العملات غير كافٍ لإرسال هذه الهدية! يمكنك الشحن عبر المتجر.');
      setShowCoinStoreModal(true);
      return;
    }
    handleUpdateCoins(-gift.priceCoins);
  };

  // Filter rooms based on active category tab & search query
  const filteredRooms = rooms.filter((r) => {
    const matchesCategory = r.category === roomCategoryTab;
    const matchesQuery =
      searchQuery.trim() === '' ||
      r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.hostName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesQuery;
  });

  return (
    <div dir="rtl" className="min-h-screen bg-slate-950 text-white font-sans pb-24 selection:bg-amber-500 selection:text-slate-950">
      {/* Top Header */}
      <Header
        user={user}
        onOpenCoinStore={() => setShowCoinStoreModal(true)}
        onOpenAdminPanel={() => setShowAdminPanelModal(true)}
        onOpenVipModal={() => setShowVipModal(true)}
        onOpenProfile={() => setMainTab('profile')}
        onOpenWithdrawalModal={() => setShowWithdrawalModal(true)}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-3 py-2">
        {mainTab === 'home' && (
          <div className="space-y-4 animate-fadeIn">
            {/* Interactive Slogan Banner */}
            <Banner
              onOpenGames={() => setShowGamesModal(true)}
              onOpenStore={() => setShowCoinStoreModal(true)}
              onOpenVip={() => setShowVipModal(true)}
            />

            {/* Quick Action Categories Bar */}
            <QuickCategories
              user={user}
              onOpenVip={() => setShowVipModal(true)}
              onOpenLeaderboard={() => setShowLeaderboardModal(true)}
              onOpenGifts={() => setShowCoinStoreModal(true)}
              onOpenAgencies={handleOpenAgencies}
              onOpenEvents={() => setShowGamesModal(true)}
              onOpenGames={() => setShowGamesModal(true)}
            />

            {/* Room Tabs & Search */}
            <RoomTabs
              activeTab={roomCategoryTab}
              onTabChange={setRoomCategoryTab}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
            />

            {/* Voice Rooms Grid */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400 font-bold">
                <span>الغرف الصوتية المتاحة ({filteredRooms.length})</span>
                <button
                  onClick={handleOpenAgencies}
                  className="flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black rounded-xl shadow-md transition-all active:scale-95 text-xs"
                >
                  {user.hasActiveRoom ? '🎙️ غرفتي الخاصة' : '➕ إنشاء غرفة'}
                </button>
              </div>

              {filteredRooms.length === 0 ? (
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400 text-xs space-y-2">
                  <p>لا توجد غرف صوتية مطابقة للبحث في هذا القسم حالياً.</p>
                  <button
                    onClick={handleOpenAgencies}
                    className="px-4 py-2 bg-amber-500 text-slate-950 font-bold rounded-xl active:scale-95 transition-transform"
                  >
                    كن أول من ينشئ غرفة الآن 🔥
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                  {filteredRooms.map((room) => (
                    <RoomCard
                      key={room.id}
                      room={room}
                      onOpenRoom={(r) => setActiveVoiceRoom(r)}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Other Main Navigation Views */}
        {mainTab === 'chats' && <DirectChatsView />}
        {mainTab === 'friends' && <FriendsView />}
        {mainTab === 'profile' && (
          <ProfileView
            user={user}
            onOpenCoinStore={() => setShowCoinStoreModal(true)}
            onOpenVipModal={() => setShowVipModal(true)}
            onOpenAdminPanel={() => setShowAdminPanelModal(true)}
            onOpenWithdrawalModal={() => setShowWithdrawalModal(true)}
            onUpdateUser={handleUpdateUser}
            onBack={() => setMainTab('home')}
            onLogout={handleLogout}
          />
        )}
      </main>

      {/* Sticky Bottom Navigation Bar */}
      <BottomNav
        activeTab={mainTab}
        onTabChange={setMainTab}
        onOpenLiveStream={() => setShowLiveStreamModal(true)}
      />

      {/* Live Stream Broadcast Modal (Agora RTC + WebRTC Camera) */}
      {showLiveStreamModal && (
        <LiveStreamModal
          user={user}
          onClose={() => setShowLiveStreamModal(false)}
          onSendGift={handleSendGift}
          onOpenCoinStore={() => setShowCoinStoreModal(true)}
        />
      )}

      {/* Active Voice Room View Modal */}
      {activeVoiceRoom && (
        <VoiceRoomModal
          room={activeVoiceRoom}
          user={user}
          onClose={() => setActiveVoiceRoom(null)}
          onOpenGames={() => setShowGamesModal(true)}
          onSendGift={handleSendGift}
          onOpenCoinStore={() => setShowCoinStoreModal(true)}
          onUpdateUser={handleUpdateUser}
        />
      )}

      {/* Create Room Modal */}
      {showCreateRoomModal && (
        <CreateRoomModal
          user={user}
          onClose={() => setShowCreateRoomModal(false)}
          onCreateRoomSuccess={handleCreateRoomSuccess}
          onOpenAdminPanel={() => setShowAdminPanelModal(true)}
        />
      )}

      {/* Mini-Games Modal */}
      {showGamesModal && (
        <MiniGamesModal
          user={user}
          onClose={() => setShowGamesModal(false)}
          onUpdateCoins={handleUpdateCoins}
          onOpenCoinStore={() => setShowCoinStoreModal(true)}
          onOpenWithdrawalModal={() => setShowWithdrawalModal(true)}
        />
      )}

      {/* Coin Store Modal */}
      {showCoinStoreModal && (
        <CoinStoreModal
          user={user}
          onClose={() => setShowCoinStoreModal(false)}
          onPurchaseSuccess={handlePurchaseCoinsSuccess}
        />
      )}

      {/* Cash Withdrawal & Diamond Exchange Modal */}
      {showWithdrawalModal && (
        <WithdrawalModal
          user={user}
          withdrawalRequests={withdrawalRequests}
          onClose={() => setShowWithdrawalModal(false)}
          onUpdateDiamonds={handleUpdateDiamonds}
          onUpdateCoins={handleUpdateCoins}
          onSubmitWithdrawalRequest={handleSubmitWithdrawalRequest}
        />
      )}

      {/* VIP Perks Modal */}
      {showVipModal && (
        <VipModal
          user={user}
          onClose={() => setShowVipModal(false)}
          onOpenCoinStore={() => {
            setShowVipModal(false);
            setShowCoinStoreModal(true);
          }}
        />
      )}

      {/* Leaderboard Modal */}
      {showLeaderboardModal && (
        <LeaderboardModal onClose={() => setShowLeaderboardModal(false)} />
      )}

      {/* Admin Panel Modal */}
      {showAdminPanelModal && (
        <AdminPanelModal
          user={user}
          transactions={transactions}
          withdrawalRequests={withdrawalRequests}
          onClose={() => setShowAdminPanelModal(false)}
          onToggleUserRoomPermission={handleToggleUserRoomPermission}
          onManualAddCoins={handleManualAddCoins}
          onUpdateWithdrawalStatus={handleUpdateWithdrawalStatus}
        />
      )}

      {/* SplashScreen overlay on app launch */}
      {showSplash && (
        <SplashScreen
          onStart={() => {
            setShowSplash(false);
            setShowLogin(true);
          }}
        />
      )}

      {/* LoginScreen overlay */}
      {showLogin && (
        <LoginScreen onLoginSuccess={handleLoginSuccess} />
      )}

      {/* Floating Toast Notification Alert */}
      {toastMessage && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] bg-[#1a0f2e]/95 border border-amber-500/60 text-amber-200 font-black text-xs px-5 py-3 rounded-2xl shadow-2xl backdrop-blur-md flex items-center gap-2.5 animate-in fade-in slide-in-from-top-4 duration-300">
          <span className="text-base">⚠️</span>
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
