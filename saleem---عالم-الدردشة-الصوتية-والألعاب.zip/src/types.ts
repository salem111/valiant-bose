export type VipRank = 'None' | 'Silver' | 'Gold' | 'Diamond' | 'Crown VIP';

export interface UserProfile {
  id: string; // user_id
  name: string; // username
  avatar: string;
  vipRank: VipRank;
  vipLevel: number;
  levelStatus: string; // level_status e.g. "ليفل 1", "ليفل 2"
  wealthLevel?: number; // مستوى الثراء e.g. 30
  wealthXp?: number; // نقاط خبرة الثراء
  coins: number;
  diamonds: number;
  isAllowedToCreateRoom: boolean;
  hasActiveRoom: boolean;
  createdRoomId?: string;
  roomName?: string; // user's owned room name
  bio?: string;
  followersCount: number;
  followingCount: number;
  provider?: string;
  isLoggedIn?: boolean;
  isOnline?: boolean;
  country?: string;
  gender?: string;
  role?: string;
}

export interface MicSeat {
  seatId: number;
  isHostSeat?: boolean;
  isLocked: boolean;
  isMuted: boolean;
  points?: number; // نقاط المقعد أو الهدايا المستلمة
  speakerUser?: {
    id: string;
    name: string;
    avatar: string;
    isSpeaking?: boolean;
    audioLevel?: number; // 0-100
    vipLevel?: number;
    role?: 'مقدم' | 'مدير' | 'VIP' | 'عضو';
  };
}

export interface RoomMessage {
  id: string;
  senderName: string;
  senderAvatar: string;
  senderVip?: number;
  text: string;
  timestamp: string;
  isGiftNotice?: boolean;
  giftInfo?: {
    giftName: string;
    giftIcon: string;
    amount: number;
  };
  isSystemNotice?: boolean;
}

export interface SeatTemplate {
  id: string;
  type: 'basic' | 'boss';
  count: number;
  minLevel: number;
  label: string;
}

export interface VoiceRoom {
  id: string;
  title: string;
  announcement: string;
  hostId: string;
  hostName: string;
  hostAvatar: string;
  category: 'غرف شائعة' | 'غرف جديدة' | 'متابعة';
  tag: string;
  level: number; // مستوى الغرفة e.g. 1, 5
  rank: number; // ترتيب الغرفة e.g. 1, 2, 3
  listenersCount: number;
  seats: MicSeat[];
  seatLayout?: {
    type: 'basic' | 'boss';
    count: number;
  };
  backgroundUrl: string;
  pinCode?: string;
  isLockedWithPin?: boolean;
  messages: RoomMessage[];
  mods: string[]; // list of user IDs who are moderators
  managerPermissions?: {
    canManageLayout?: boolean;
  };
}

export interface GiftItem {
  id: string;
  name: string;
  icon: string;
  priceCoins: number;
  priceDiamonds?: number;
  category?: 'gift' | 'lucky' | 'cp' | 'worldcup' | 'birthday' | 'svip' | 'member' | 'eid' | string;
  badge?: string; // e.g. 'CP', 'VIP', 'HOT'
  effectType: 'heart' | 'crown' | 'sports_car' | 'dragon' | 'fireworks' | 'rose_shower' | 'love_heart' | 'fireworks_boom' | 'jet_fly' | 'car_drive' | 'gold_coins' | 'castle_crown' | 'dragon_fire' | 'eid_ram' | 'bday_party' | string;
}

export interface CoinPackage {
  id: string;
  title: string;
  coinsAmount: number;
  bonusCoins: number;
  priceUsd: number;
  badge?: string;
  googlePlayProductId: string;
}

export interface TransactionRecord {
  id: string;
  googleOrderId: string;
  userId: string;
  userName: string;
  packageName: string;
  amountCoins: number;
  priceUsd: number;
  purchaseToken: string;
  status: 'SUCCESS' | 'PENDING' | 'FAILED' | 'REFUNDED';
  timestamp: string;
}

export interface LeaderboardUser {
  rank: number;
  id: string;
  name: string;
  avatar: string;
  vipLevel: number;
  scoreCoins: number;
  badge: string;
}

export type MainTab = 'home' | 'chats' | 'friends' | 'profile';

export type WithdrawalGateway = 
  | 'bank_transfer' 
  | 'zain_cash' 
  | 'orange_money' 
  | 'cliq'
  | 'vodafone_cash' 
  | 'instapay' 
  | 'usdt_trc20' 
  | 'paypal' 
  | 'payoneer';

export interface WithdrawalPackage {
  id: string;
  diamondsCount: number;
  usdAmount: number;
  badge?: string;
  popular?: boolean;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  diamondsAmount: number;
  usdAmount: number;
  gateway: WithdrawalGateway;
  gatewayTitle: string;
  accountDetails: {
    phoneOrEmailOrIban: string;
    beneficiaryName?: string;
    bankName?: string;
  };
  status: 'PENDING' | 'PROCESSING' | 'SUCCESS' | 'REJECTED';
  rejectionReason?: string;
  createdAt: string;
}
